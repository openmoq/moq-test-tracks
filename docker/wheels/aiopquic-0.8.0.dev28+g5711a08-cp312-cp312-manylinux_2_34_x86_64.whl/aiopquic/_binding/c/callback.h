/*
 * callback.h — picoquic callback function that bridges events to SPSC ring.
 *
 * This runs in the picoquic network thread. It receives all stream/connection
 * events from picoquic and writes them into the RX SPSC ring buffer for
 * consumption by the asyncio thread.
 *
 * Each event with payload owns a malloc'd buffer; ownership transfers to
 * the consumer at pop time (Python wraps it in a StreamChunk). No arena
 * memory is involved — the ring is a pure entry table.
 *
 * Copyright (c) 2026, aiopquic contributors. BSD-3-Clause license.
 */

#ifndef AIOPQUIC_CALLBACK_H
#define AIOPQUIC_CALLBACK_H

#include "spsc_ring.h"
#include "stream_buf.h"
#include "stream_ctx.h"
#include "datagram_buf.h"
#include <picoquic.h>
#include <picoquic_packet_loop.h>
#include "picoquic_internal.h"

/* =====================================================================
 * Resource defaults — single source of truth for aiopquic tunables.
 *
 * Per-stream byte rings double as peer's max in-flight window (RX) and
 * Python's local TX staging buffer. Buffer size has two effects:
 *   - max throughput (FC-limited) = buffer / RTT
 *   - max queueing latency under drain stall = buffer / drain_rate
 * For live-media workloads (MoQT) prefer buffer ≈ BDP at target RTT;
 * going larger doesn't gain throughput (network-limited) but adds
 * latency-spike potential. Override per-cnx via QuicConfiguration.
 * ===================================================================== */

/* Per-stream RX byte ring fallback. 4 MB covers 1 Gbps × 32 ms or
 * 2.5 Gbps × 13 ms cleanly. For 2.5 Gbps × 100 ms WAN set ~32 MB via
 * QuicConfiguration.rx_data_ring_cap; for 10 Gbps × 100 ms set ~128 MB.
 * Memory cost scales with concurrent stream count. Power of two. */
#define AIOPQUIC_RX_DATA_RING_CAP_DEFAULT (1u << 22)

/* Per-stream TX byte ring fallback. Holds bytes between Python's
 * send_stream_data and picoquic's worker drain. Doesn't need to
 * be BDP-sized (picoquic drains continuously); 4 MB matches RX
 * for symmetry and gives ample staging headroom. */
#define AIOPQUIC_TX_DATA_RING_CAP_DEFAULT (1u << 22)

/* Legacy shared SPSC ring default — preserved for backward-compat
 * callers (Python QuicConfiguration.event_ring_capacity fallback).
 * New code should size tx and rx independently via the two macros
 * below. */
#define AIOPQUIC_SPSC_RING_CAPACITY_DEFAULT 262144

/* TX SPSC event ring default. Carries producer→worker notifications:
 * one MARK_ACTIVE per send_stream_data call in pull-model (bytes
 * live in sc->tx, not here), plus control msgs / WT commands / push-
 * model byte-bearing entries. 2048 entries = ~20 ms of producer
 * headroom at 100k events/s — small enough to backpressure early,
 * large enough to absorb command bursts without starving the data
 * path. Drainage threshold controlled by AIOPQUIC_TX_RING_WAKE_PCT.
 * Power of two. */
#define AIOPQUIC_TX_EVENT_RING_CAP_DEFAULT 2048

/* RX SPSC event ring default. Carries worker→asyncio notifications:
 * stream_data / stream_fin / stream_open / connection events + the
 * STREAM_TX_DRAINED and TX_RING_DRAINED wake events. Worker push
 * rate is peer-paced, not producer-paced — undersizing causes
 * silent event drops on multi-Gbps stream-churn workloads (see
 * worker_rx_event_drops counter; aiopquic_rx_log_enabled stderr).
 * 16384 entries chosen as the floor at which sustained MoQT
 * subgroup churn at multi-Gbps stops triggering drops in lab.
 * Power of two. */
#define AIOPQUIC_RX_EVENT_RING_CAP_DEFAULT 16384

/* TX SPSC ring drain-wake low-water mark, as percent of ring
 * capacity. Worker fires SPSC_EVT_TX_EVENT_RING_DRAINED when count
 * drops to/below this fraction while a Python writer has armed
 * tx_event_ring_drain_pending. 50% leaves the producer half-empty
 * headroom on wake. Overridable via AIOPQUIC_TX_RING_WAKE_PCT
 * env var at ctx_create time. (Temporarily reverted from 75%
 * while investigating control-stream delivery regression.) */
#define AIOPQUIC_TX_RING_WAKE_PCT_DEFAULT 50

/* A worker that planned and slept a wait at least this long, then wakes
 * on its own and finds TX entries queued, counts a lost wake. A shorter
 * sleep can end between a producer's push and its wake check. */
#define AIOPQUIC_TX_WAKE_LOST_US 50000

#include <errno.h>
#include <fcntl.h>
#include <stdatomic.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/* O(N_connections) walk over picoquic's live-cnx list: the cnx of a TX
 * event may have been freed between the Python push and our pop, and any
 * deref into a freed cnx is a UAF. aiopquic_cnx_live() answers from
 * ctx->live_cnxs first and walks only on a miss. */
static inline int aiopquic_cnx_is_alive(picoquic_quic_t* quic,
                                         picoquic_cnx_t* cnx) {
    picoquic_cnx_t* cur = picoquic_get_first_cnx(quic);
    while (cur) {
        if (cur == cnx) {
            return 1;
        }
        cur = picoquic_get_next_cnx(cur);
    }
    return 0;
}

/* Open-addressed pointer set (linear probing), worker thread only. */
typedef struct {
    picoquic_cnx_t** slots;
    uint32_t mask;      /* capacity - 1; 0 while unallocated */
    uint32_t count;
} aiopquic_cnx_set_t;

static inline uint32_t aiopquic_cnx_set_slot(const aiopquic_cnx_set_t* s,
                                             const picoquic_cnx_t* cnx) {
    uint64_t h = (uint64_t)(uintptr_t)cnx * 0x9E3779B97F4A7C15ull;
    return (uint32_t)(h >> 32) & s->mask;
}

static inline int aiopquic_cnx_set_has(const aiopquic_cnx_set_t* s,
                                       const picoquic_cnx_t* cnx) {
    if (s->mask == 0 || cnx == NULL) return 0;
    for (uint32_t i = aiopquic_cnx_set_slot(s, cnx);; i = (i + 1) & s->mask) {
        if (s->slots[i] == cnx) return 1;
        if (s->slots[i] == NULL) return 0;
    }
}

static inline void aiopquic_cnx_set_put_slot(aiopquic_cnx_set_t* s,
                                             picoquic_cnx_t* cnx) {
    uint32_t i = aiopquic_cnx_set_slot(s, cnx);
    while (s->slots[i] != NULL) i = (i + 1) & s->mask;
    s->slots[i] = cnx;
    s->count++;
}

/* Keeps the load at or under 1/2. A failed grow leaves cnx out, which only
 * costs the walk. */
static void aiopquic_cnx_set_add(aiopquic_cnx_set_t* s, picoquic_cnx_t* cnx) {
    if (cnx == NULL || aiopquic_cnx_set_has(s, cnx)) return;
    if (s->mask == 0 || (s->count + 1) * 2 > s->mask + 1) {
        uint32_t old_cap = s->mask ? s->mask + 1 : 0;
        uint32_t cap = old_cap ? old_cap * 2 : 64;
        picoquic_cnx_t** old = s->slots;
        picoquic_cnx_t** slots = (picoquic_cnx_t**)calloc(cap, sizeof(*slots));
        if (slots == NULL) return;
        s->slots = slots;
        s->mask = cap - 1;
        s->count = 0;
        for (uint32_t i = 0; i < old_cap; i++) {
            if (old[i] != NULL) aiopquic_cnx_set_put_slot(s, old[i]);
        }
        free(old);
    }
    aiopquic_cnx_set_put_slot(s, cnx);
}

/* Backward-shift delete keeps every probe chain unbroken. */
static void aiopquic_cnx_set_del(aiopquic_cnx_set_t* s, const picoquic_cnx_t* cnx) {
    if (s->mask == 0 || cnx == NULL) return;
    uint32_t i = aiopquic_cnx_set_slot(s, cnx);
    while (s->slots[i] != cnx) {
        if (s->slots[i] == NULL) return;
        i = (i + 1) & s->mask;
    }
    s->slots[i] = NULL;
    s->count--;
    for (uint32_t j = (i + 1) & s->mask; s->slots[j] != NULL; j = (j + 1) & s->mask) {
        uint32_t home = aiopquic_cnx_set_slot(s, s->slots[j]);
        /* Move j into the hole unless its home lies cyclically in (i, j]. */
        if (((j - home) & s->mask) >= ((j - i) & s->mask)) {
            s->slots[i] = s->slots[j];
            s->slots[j] = NULL;
            i = j;
        }
    }
}

static void aiopquic_cnx_set_clear(aiopquic_cnx_set_t* s) {
    free(s->slots);
    s->slots = NULL;
    s->mask = 0;
    s->count = 0;
}

/* RFC 9000 §2.1: a unidirectional stream carries data only from its
 * initiator. RESET_STREAM on a receive-only stream (§19.4) or
 * STOP_SENDING on a send-only one (§19.5) is a connection error at the
 * peer, so each is sent only on a stream that has that direction. */
static inline int aiopquic_stream_is_local(picoquic_cnx_t* cnx,
                                           uint64_t stream_id) {
    return PICOQUIC_IS_CLIENT_STREAM_ID(stream_id)
           == (unsigned int)(picoquic_is_client(cnx) != 0);
}

static inline int aiopquic_stream_can_send(picoquic_cnx_t* cnx,
                                           uint64_t stream_id) {
    return PICOQUIC_IS_BIDIR_STREAM_ID(stream_id)
           || aiopquic_stream_is_local(cnx, stream_id);
}

static inline int aiopquic_stream_can_receive(picoquic_cnx_t* cnx,
                                              uint64_t stream_id) {
    return PICOQUIC_IS_BIDIR_STREAM_ID(stream_id)
           || !aiopquic_stream_is_local(cnx, stream_id);
}
#include <netinet/in.h>
#include <arpa/inet.h>

/* Cached AIOPQUIC_RX_LOG env flag — resolved once at first use so the
 * overflow-diagnostic fprintf paths don't repeatedly hit getenv()
 * under sustained overflow (libc env lookups are not cheap when fired
 * from inside the picoquic worker callback). 0=unset, 1=set, -1=not
 * yet probed. Atomic only to ensure the first-probe write is visible
 * across threads — there is no correctness issue if two threads race
 * the probe; both write the same value. */
static _Atomic(int) _aiopquic_rx_log_cached = -1;

static inline int aiopquic_rx_log_enabled(void) {
    int v = atomic_load_explicit(&_aiopquic_rx_log_cached,
                                  memory_order_relaxed);
    if (v < 0) {
        const char* s = getenv("AIOPQUIC_RX_LOG");
        v = (s && *s && *s != '0') ? 1 : 0;
        atomic_store_explicit(&_aiopquic_rx_log_cached, v,
                              memory_order_relaxed);
    }
    return v;
}

/* AIOPQUIC_FC_RAW=1 forces the FC handler to grant raw buf_free
 * (ignoring bytes_pending_release). Diagnostic only — disables the
 * Python-pipeline backpressure that bounds RSS. Default OFF. */
static _Atomic(int) _aiopquic_fc_raw_cached = -1;

static inline int aiopquic_fc_raw_enabled(void) {
    int v = atomic_load_explicit(&_aiopquic_fc_raw_cached,
                                  memory_order_relaxed);
    if (v < 0) {
        const char* s = getenv("AIOPQUIC_FC_RAW");
        v = (s && *s && *s != '0') ? 1 : 0;
        atomic_store_explicit(&_aiopquic_fc_raw_cached, v,
                              memory_order_relaxed);
    }
    return v;
}

#ifdef __linux__
#include <sys/eventfd.h>
#include <sys/prctl.h>
#endif

/*
 * Packed struct for SPSC_EVT_TX_CONNECT data payload.
 * Stored in the entry's data_buf as: header + sni + alpn.
 */
typedef struct {
    struct sockaddr_storage addr;
    uint32_t desired_version;           /* 0: stay in the initial version */
    uint16_t sni_len;
    uint16_t alpn_len;
    /* followed by: sni_len bytes of SNI, then alpn_len bytes of ALPN */
} aiopquic_connect_params_t;

#ifdef __cplusplus
extern "C" {
#endif

/* A datagram ring release a full TX event ring refused. */
typedef struct {
    void*                 cnx;
    aiopquic_dgram_buf_t* db;
} aiopquic_dgram_release_t;

/* Wake-protocol trace: a small ring per thread (one writer each), read
 * racily by asyncio for diagnostics only. Records the order of notify
 * flips, drains and clears so a lost wake can be reconstructed. */
#define AIOPQUIC_WAKE_TRACE_LEN 128
enum {
    AIOPQUIC_WAKE_NOTIFY = 1,   /* worker 0->1 flip; a = errno of the wake write (0 ok); b = ring count */
    AIOPQUIC_WAKE_CLEAR = 2,    /* asyncio clear_rx; a = flags below; b = ring left << 32 | counter read */
    AIOPQUIC_WAKE_DRAIN = 3,    /* asyncio drain_rx; a = events popped; b = ring count after */
};
#define AIOPQUIC_CLEAR_WAS_PENDING 1u
#define AIOPQUIC_CLEAR_REARMED     2u
#define AIOPQUIC_CLEAR_READ_EMPTY  4u
#define AIOPQUIC_CLEAR_REARM_ERR   8u

typedef struct {
    uint64_t ts_ns;
    uint32_t kind;
    uint32_t a;
    uint64_t b;
} aiopquic_wake_trace_entry_t;

typedef struct {
    uint64_t next;
    aiopquic_wake_trace_entry_t e[AIOPQUIC_WAKE_TRACE_LEN];
} aiopquic_wake_trace_t;

static inline void aiopquic_wake_trace_add(aiopquic_wake_trace_t* t,
                                           uint32_t kind, uint32_t a,
                                           uint64_t b) {
    uint64_t n = t->next;
    aiopquic_wake_trace_entry_t* e = &t->e[n % AIOPQUIC_WAKE_TRACE_LEN];
    e->ts_ns = aiopquic_now_ns();
    e->kind = kind;
    e->a = a;
    e->b = b;
    __atomic_store_n(&t->next, n + 1, __ATOMIC_RELEASE);
}

static inline uint64_t aiopquic_wake_trace_next(aiopquic_wake_trace_t* t) {
    return __atomic_load_n(&t->next, __ATOMIC_ACQUIRE);
}

typedef struct {
    spsc_ring_t*    rx_event_ring;
    spsc_ring_t*    tx_event_ring;
    spsc_overflow_t rx_overflow;    /* order-preserving spill for a full RX ring */
    int             eventfd;        /* readable fd asyncio watches (eventfd
                                       on Linux, pipe read end elsewhere) */
    int             wake_write_fd;  /* fd the network thread writes to
                                       (== eventfd on Linux; pipe write end
                                       elsewhere) */
    picoquic_quic_t* quic;
    /* Network-thread handle returned by picoquic_start_network_thread.
     * Set by Python's start() after the thread is up; used by C-side
     * helpers (aiopquic_push_fc_credit, etc.) that need to wake the
     * worker without round-tripping through Python. NULL during early
     * init and after thread teardown.
     *
     * IMPORTANT: picoquic_wake_up_network_thread takes this struct
     * pointer, NOT the picoquic_quic_t*. Passing the wrong type is
     * a UAF-class bug — the function dereferences fields that don't
     * exist at the same offsets. */
    picoquic_network_thread_ctx_t* thread_ctx;
    /* Per-stream RX byte ring capacity. Set at start() time from the
     * QuicConfiguration's max_stream_data so the ring can hold the
     * full peer-allowed in-flight window (the spec promises peer
     * never sends more before MAX_STREAM_DATA is extended). Rounded
     * up to a power of two by the Cython binding before being stored
     * here. */
    uint32_t        rx_data_ring_cap;
    /* Forensic counters — incremented from the picoquic worker thread
     * as it processes TX events. The asyncio thread reads them via
     * Cython properties to verify per-event accounting. Plain ints,
     * read with relaxed semantics (only one writer). */
    uint64_t        worker_mark_active_processed;
    uint64_t        worker_prepare_to_send_calls;
    uint64_t        worker_prepare_to_send_pulled_bytes;
    /* RX-side: events lost for want of memory. A full rx_event_ring
     * spills to rx_overflow instead, order kept. */
    uint64_t        worker_rx_event_drops;
    uint64_t        worker_rx_event_drops_stream_data;
    uint64_t        cnt_rx_data_event_coalesced;     /* data events skipped: notification already in flight */
    /* Notify-coalescing state. eventfd is level-triggered; multiple
     * write()s coalesce to one wake-up at the consumer, but each
     * write is still a syscall. At 250K events/sec on a stream-churn
     * workload that's a quarter-million unnecessary syscalls/sec on
     * the picoquic worker thread. Track whether the consumer has
     * acknowledged the last notify (= drained) and skip the syscall
     * when there's already a pending notification.
     *
     * Set to 1 by aiopquic_notify_rx (worker) on first push since
     * last drain. Cleared to 0 by aiopquic_clear_rx (consumer) when
     * it reads the eventfd. Producer-only-sets, single-writer
     * semantics — atomic exchange used to detect the 0→1 edge. */
    uint32_t        rx_notify_pending;
    /* Wake-protocol forensics. Worker-written: flips, skips, write
     * errors, worker_trace. asyncio-written: clears, empty reads,
     * re-arms, asyncio_trace. */
    uint64_t        cnt_rx_notify_flips;
    uint64_t        cnt_rx_notify_skips;
    uint64_t        cnt_rx_notify_write_errs;
    int             last_rx_notify_errno;
    uint64_t        cnt_rx_clears;
    uint64_t        cnt_rx_clear_read_empty;
    uint64_t        cnt_rx_rearms;
    aiopquic_wake_trace_t worker_trace;
    aiopquic_wake_trace_t asyncio_trace;
    /* 1 while the worker may sleep: set before a wait that can block,
     * cleared when it runs and by the producer that wakes it. Producers
     * call picoquic_wake_up_network_thread only on that 1→0. */
    uint32_t        tx_worker_idle;
    /* Per-stream RX byte ring overflow counter. Replaces the
     * fprintf(stderr,...) on full from the previous diagnostic —
     * libc stdio holds a global lock and stalls the picoquic worker
     * under load. Set AIOPQUIC_RX_LOG=1 in the env to re-enable a
     * one-shot stderr line per overflow event. */
    uint64_t        worker_rx_byte_ring_overflow;
    /* TX ring drain wakeup. Python writers blocked on a full SPSC TX
     * event ring arm tx_event_ring_drain_pending=1 (clear-arm-recheck-wait
     * pattern); worker fires SPSC_EVT_TX_EVENT_RING_DRAINED via CAS-clear
     * once spsc_ring_count(tx_event_ring) <= tx_event_ring_low_water. Default
     * low_water = 50% of ring capacity, overridable via
     * AIOPQUIC_TX_RING_WAKE_PCT env var at ctx_create time. */
    uint32_t        tx_event_ring_drain_pending;
    uint32_t        tx_event_ring_low_water;

    /* ============================================================
     * Observability counters (added without behavior change).
     * All single-writer per cell; reads from asyncio thread via
     * Cython properties. Plain uint64_t with relaxed semantics
     * because correctness doesn't depend on these — they exist to
     * answer "which side of the wake chain stalled" by inspection.
     *
     * Timestamps use CLOCK_MONOTONIC ns to align worker- and
     * asyncio-thread events on a single comparable time-base.
     * ============================================================ */
    uint64_t        cnt_tx_event_ring_pushes;            /* Python push into tx_event_ring */
    uint64_t        cnt_tx_event_ring_pops;              /* worker pop from tx_event_ring */
    uint64_t        cnt_tx_event_ring_arms;              /* Python armed tx_event_ring_drain_pending */
    uint64_t        cnt_tx_event_ring_fires;             /* worker fired SPSC_EVT_TX_EVENT_RING_DRAINED */
    uint64_t        cnt_tx_event_ring_fire_dropped;      /* fire CAS won but rx_event_ring push failed → re-armed */
    uint64_t        cnt_wake_calls;                /* picoquic_wake_up_network_thread invoked */
    uint64_t        cnt_wake_skipped_coalesced;    /* wake skipped: worker not idle */
    uint64_t        cnt_prepare_to_send_empty;     /* prepare_to_send invoked with avail==0 */
    uint64_t        cnt_loop_cb;                   /* worker loop callbacks: moves while the worker runs */
    uint64_t        last_tx_event_ring_arm_ns;           /* CLOCK_MONOTONIC of last arm */
    uint64_t        last_tx_event_ring_fire_ns;          /* CLOCK_MONOTONIC of last fire */
    /* RX flow-control observability (added 2026-05-25). Drain side
     * (asyncio) pushes OPEN_FLOW_CONTROL events; worker handles them.
     * cnt_fc_credit_pushed must equal cnt_fc_credit_handled + cnt_fc_credit_dropped
     * in steady state — otherwise events are leaking on the worker side. */
    uint64_t        cnt_fc_credit_pushed;          /* asyncio push of SPSC_EVT_TX_OPEN_FLOW_CONTROL */
    uint64_t        cnt_fc_credit_handled;         /* worker processed SPSC_EVT_TX_OPEN_FLOW_CONTROL */
    uint64_t        cnt_fc_credit_dropped;         /* push failed (tx_event_ring full) */
    /* WT-side sc/link leak diagnostic. Incremented when
     * picohttp_callback_free fires with a non-NULL link but
     * stream_ctx->path_callback_ctx no longer matches — the
     * "skipped cleanup" path that may correlate with the May-23
     * sub-side sc retention. Zero in healthy steady-state; growth
     * rate = sc leak rate per cnx. */
    uint64_t        cnt_wt_callback_free_skipped;
    /* Per-site sc create/ref/destroy counters (added 2026-06-06).
     * Invariant: Σ create + Σ ref == Σ destroy at process end.
     * Per-site imbalance localizes the May-23 sub-side retention. */
    uint64_t        cnt_sc_create_raw_quic;         /* callback.h ~803 first-touch */
    uint64_t        cnt_sc_create_wt_link;          /* h3wt_callback.h ~163 link create */
    uint64_t        cnt_sc_ref_fc_credit;           /* callback.h ~440 FC credit push ref */
    /* No total "cnt_sc_destroy_wt_link" — accessing link->session inside
     * aiopquic_wt_stream_link_destroy is a UAF on shutdown (session freed
     * before all LINK_RELEASE events drain). The split counters below are
     * incremented at call sites where session validity is guaranteed. */
    uint64_t        cnt_sc_destroy_wt_link_callback_free; /* via picohttp_callback_free cleanup */
    uint64_t        cnt_sc_destroy_wt_link_close_walker;  /* via session-close walker sweep */
    uint64_t        cnt_sc_destroy_fc_credit_pushfail; /* callback.h ~464 push-fail unref */
    uint64_t        cnt_sc_destroy_fc_credit_worker;   /* callback.h ~1114 worker unref */
    /* QUIC keep-alive interval (microseconds). 0 = disabled. Applied
     * per-cnx by the worker thread at the ready callback via
     * picoquic_enable_keep_alive — PING frames hold an otherwise-quiet
     * connection open past the idle timeout (e.g. a consumer-stalled
     * subscriber whose flow control has back-pressured the sender to
     * silence). Set once at start(); read by the worker. */
    uint64_t        keep_alive_us;
    /* Server-mode WebTransport subprotocol allowlist: a CSV in server
     * preference order (e.g. "moqt-18, moqt-16") from which the WT-Protocol
     * is selected against the client's WT-Available-Protocols. Borrowed
     * pointer owned by the Cython TransportContext (kept alive there);
     * NULL = no subprotocol negotiation. Read by the worker thread in
     * the WT server path callback. */
    char*           wt_supported_protocols;
    /* Raw-QUIC ALPN offer/allowlist as an owned array of NUL-terminated
     * strings in preference order (newest first). On a client these are
     * offered in the ClientHello via picoquic_callback_request_alpn_list;
     * picoquic_add_proposed_alpn STORES the pointers (does not copy), so
     * they must outlive the handshake — hence owned copies, not a
     * borrowed CSV. On a server the alpn_select_fn picks the highest
     * mutual. Built by aiopquic_ctx_set_alpn_list, freed in
     * aiopquic_ctx_destroy. NULL/0 = single-ALPN path (default_alpn). */
    char**          alpn_list;
    size_t          alpn_list_count;
    /* Single-port dual-stack dispatch (raw QUIC + h3/WT on one port):
     * when non-NULL, the quic ctx's default callback is
     * aiopquic_dispatch_cb (h3wt_callback.h), which routes each
     * connection by negotiated ALPN — "h3" bootstraps an h3zero
     * per-cnx context from these server parameters
     * (picohttp_server_parameters_t*); everything else re-points to
     * aiopquic_stream_cb with this bridge. */
    void*           dual_wt_params;
    /* Pull-model datagram TX: worker-owned cnx→record-ring table
     * (insert on MARK_DATAGRAM_READY, lookup on prepare_datagram,
     * remove on cnx close or ring release, sweep at destroy). Per-ring
     * counters live on the aiopquic_dgram_buf_t; these aggregate across
     * the ctx. */
    aiopquic_dgram_table_t dgram_table;
    uint64_t        worker_dgram_mark_ready_processed;
    uint64_t        worker_dgram_prepare_calls;
    uint64_t        worker_dgram_records_sent;
    uint64_t        worker_dgram_bytes_sent;
    /* Appended at the tail: the struct carries no padding or alignment
     * discipline, so splicing fields in mid-struct shifts every later
     * offset, the cross-thread tx_event_ring_drain_pending included.
     *
     * Priority outcomes. Ring drain alone cannot separate these: the
     * stale-cnx guard pops an event exactly as a successful apply does.
     * last_err holds the most recent picoquic return (0 = none seen). */
    uint64_t        worker_set_priority_applied;
    uint64_t        worker_set_priority_rejected;
    uint64_t        worker_set_priority_last_err;
    uint64_t        worker_set_dgram_priority_applied;
    /* TX events discarded because their cnx was freed between push
     * and pop. Covers every event type behind the stale-cnx guard. */
    uint64_t        cnt_tx_event_dropped_dead_cnx;
    /* App RESET_STREAM / STOP_SENDING requests dropped because the
     * stream has no such direction (aiopquic_stream_can_send /
     * aiopquic_stream_can_receive). */
    uint64_t        cnt_tx_wrong_direction_dropped;
    /* Datagram ring releases a full TX event ring refused, posted again
     * at the next drain (asyncio thread only). */
    aiopquic_dgram_release_t* dgram_release_owed;
    uint32_t        dgram_release_owed_n;
    uint32_t        dgram_release_owed_cap;
    uint64_t        worker_dgram_ring_release_processed;
    /* OPEN_FLOW_CONTROL sc references released by the stale-cnx guard. */
    uint64_t        cnt_sc_destroy_fc_credit_dead_cnx;
    /* WT CONNECT streams h3zero freed while their session lived. */
    uint64_t        cnt_wt_control_released;
    /* Borrowed sc not attached because the cnx was already closing. */
    uint64_t        cnt_tx_reattach_after_close;
    /* Stream callbacks ignored because the cnx was already closing. */
    uint64_t        cnt_stream_cb_after_close;
    /* Resets waiting for their reliable bytes to be sent (worker only). */
    struct aiopquic_deferred_reset* deferred_resets;
    uint64_t        deferred_resets_swept;  /* last liveness sweep, us */
    uint64_t        tx_worker_armed_at;     /* worker only: arm time of a long wait, else 0 */
    uint64_t        cnt_tx_wake_lost;       /* TX entries found after a long sleep no producer woke */
    /* Reasons lent to picoquic_close_ex (worker only). */
    struct aiopquic_close_reason* close_reasons;
    /* Cnxs a liveness walk confirmed, until picoquic deletes them (worker
     * only; unused unless live_cnxs_hooked). */
    aiopquic_cnx_set_t live_cnxs;
    uint8_t         live_cnxs_hooked;
    uint64_t        cnt_cnx_live_walks;     /* liveness checks that missed live_cnxs */
    uint64_t        cnt_tx_park_kept_active; /* parks a racing commit kept active */
    uint64_t        cnt_tx_mark_active_skipped; /* commits that needed no MARK_ACTIVE (Python) */
} aiopquic_ctx_t;

typedef struct aiopquic_close_reason {
    struct aiopquic_close_reason* next;
    picoquic_cnx_t* cnx;
    char text[];
} aiopquic_close_reason_t;

/* A RESET_STREAM_AT held until its reliable bytes are sent: picoquic
 * takes no reliable size beyond the bytes it has sent. */
typedef struct aiopquic_deferred_reset {
    struct aiopquic_deferred_reset* next;
    picoquic_cnx_t*        cnx;
    aiopquic_stream_ctx_t* sc;          /* referenced */
    uint64_t               stream_id;
    uint64_t               error_code;  /* as sent */
    uint64_t               preamble;    /* WT stream header bytes */
    uint8_t                is_wt;
} aiopquic_deferred_reset_t;

/* Both ends advertised reset_stream_at. Worker only. */
static inline int aiopquic_reset_stream_at_negotiated(picoquic_cnx_t* cnx) {
    const picoquic_tp_t* lt = picoquic_get_transport_parameters(cnx, 1);
    const picoquic_tp_t* rt = picoquic_get_transport_parameters(cnx, 0);
    return lt && rt && lt->is_reset_stream_at_enabled
           && rt->is_reset_stream_at_enabled;
}

/* Reliable bytes a reset of sc keeps: the requested size capped at what
 * was written, or 0 when reset_stream_at was not negotiated. */
static inline uint64_t aiopquic_reset_reliable_size(
        picoquic_cnx_t* cnx, aiopquic_stream_ctx_t* sc, uint64_t requested) {
    if (requested == 0 || !sc || !sc->tx
            || !aiopquic_reset_stream_at_negotiated(cnx)) {
        return 0;
    }
    uint64_t written = atomic_load_explicit(&sc->tx->tail, memory_order_acquire);
    return requested < written ? requested : written;
}

/* RESET_STREAM_AT keeping the first `reliable` bytes on the wire (stream
 * offsets); RESET_STREAM when reliable is 0 or picoquic refuses it. */
static inline int aiopquic_reset_stream_reliable(picoquic_cnx_t* cnx,
        uint64_t stream_id, uint64_t code, uint64_t reliable) {
    if (reliable > 0) {
        int rr = picoquic_reset_stream_at(cnx, stream_id, code, reliable);
        if (rr != PICOQUIC_ERROR_OFFSET_TOO_BIG
                && rr != PICOQUIC_ERROR_ILLEGAL_TRANSPORT_EXTENSION) {
            return rr;
        }
    }
    return picoquic_reset_stream(cnx, stream_id, code);
}

static inline void aiopquic_deferred_reset_free(aiopquic_deferred_reset_t* d) {
    d->sc->tx_reset_pending = 0;
    aiopquic_stream_ctx_destroy(d->sc);
    free(d);
}

/* Forget the held resets of a closing cnx. Worker only. */
static inline void aiopquic_deferred_resets_drop_cnx(aiopquic_ctx_t* ctx,
                                                     picoquic_cnx_t* cnx) {
    aiopquic_deferred_reset_t** pp = &ctx->deferred_resets;
    while (*pp) {
        aiopquic_deferred_reset_t* d = *pp;
        if (d->cnx == cnx) {
            *pp = d->next;
            aiopquic_deferred_reset_free(d);
        } else {
            pp = &d->next;
        }
    }
}

/* cnx's close reason, held until its final callback; NULL for none. */
static inline const char* aiopquic_close_reason_hold(aiopquic_ctx_t* ctx,
        picoquic_cnx_t* cnx, const void* data, uint32_t len) {
    if (len == 0 || data == NULL) {
        return NULL;
    }
    for (aiopquic_close_reason_t* r = ctx->close_reasons; r; r = r->next) {
        if (r->cnx == cnx) {
            return r->text;
        }
    }
    aiopquic_close_reason_t* r =
        (aiopquic_close_reason_t*)malloc(sizeof(*r) + (size_t)len + 1);
    if (!r) {
        return NULL;
    }
    r->cnx = cnx;
    memcpy(r->text, data, len);
    r->text[len] = '\0';
    r->next = ctx->close_reasons;
    ctx->close_reasons = r;
    return r->text;
}

/* Only from cnx's final callback: close or stateless reset. */
static inline void aiopquic_close_reason_drop(aiopquic_ctx_t* ctx,
                                              picoquic_cnx_t* cnx) {
    aiopquic_close_reason_t** pp = &ctx->close_reasons;
    while (*pp) {
        aiopquic_close_reason_t* r = *pp;
        if (r->cnx == cnx) {
            *pp = r->next;
            free(r);
            return;
        }
        pp = &r->next;
    }
}

/* Hold the reset of sc until its first `reliable` bytes are sent; sends
 * stop there (aiopquic_stream_ctx_tx_sendable). Returns 0 when held. */
static inline int aiopquic_defer_reset(aiopquic_ctx_t* ctx,
        picoquic_cnx_t* cnx, aiopquic_stream_ctx_t* sc, uint64_t stream_id,
        uint64_t code, uint64_t reliable, uint64_t preamble, int is_wt) {
    aiopquic_deferred_reset_t* d =
        (aiopquic_deferred_reset_t*)calloc(1, sizeof(*d));
    if (!d) return -1;
    aiopquic_stream_ctx_ref(sc);
    sc->tx_reset_pending = 1;
    sc->tx_reliable_size = reliable;
    d->cnx = cnx;
    d->sc = sc;
    d->stream_id = stream_id;
    d->error_code = code;
    d->preamble = preamble;
    d->is_wt = (uint8_t)is_wt;
    d->next = ctx->deferred_resets;
    ctx->deferred_resets = d;
    return 0;
}

/* aiopquic_now_ns() is defined in stream_ctx.h (included above). */

/* Create a TransportContext with independent TX and RX SPSC ring
 * sizes and an explicit drain-wake low-water percent. Pass 0 for
 * any of the three to take the compile-time default
 * (AIOPQUIC_TX_EVENT_RING_CAP_DEFAULT / AIOPQUIC_RX_EVENT_RING_CAP_DEFAULT /
 * AIOPQUIC_TX_RING_WAKE_PCT_DEFAULT). Ring caps must be powers of
 * two — the caller (Cython binding) is responsible for rounding. */
static inline aiopquic_ctx_t* aiopquic_ctx_create(uint32_t tx_cap,
                                                   uint32_t rx_cap,
                                                   uint32_t low_water_pct) {
    if (tx_cap == 0) tx_cap = AIOPQUIC_TX_EVENT_RING_CAP_DEFAULT;
    if (rx_cap == 0) rx_cap = AIOPQUIC_RX_EVENT_RING_CAP_DEFAULT;
    if (low_water_pct == 0 || low_water_pct >= 100) {
        low_water_pct = AIOPQUIC_TX_RING_WAKE_PCT_DEFAULT;
    }

    aiopquic_ctx_t* ctx = (aiopquic_ctx_t*)calloc(1, sizeof(aiopquic_ctx_t));
    if (!ctx) return NULL;

    ctx->rx_event_ring = spsc_ring_create(rx_cap);
    ctx->tx_event_ring = spsc_ring_create(tx_cap);
    spsc_overflow_init(&ctx->rx_overflow);
    if (!ctx->rx_event_ring || !ctx->tx_event_ring) {
        spsc_ring_destroy(ctx->rx_event_ring);
        spsc_ring_destroy(ctx->tx_event_ring);
        aiopquic_dgram_table_destroy(&ctx->dgram_table);
        free(ctx);
        return NULL;
    }

    /* TX ring drain wake threshold: explicit param wins, then env
     * override (AIOPQUIC_TX_RING_WAKE_PCT), then the macro default.
     * Computed against tx_cap, not the legacy single-cap. */
    {
        uint32_t lw_pct = low_water_pct;
        const char* env_lw = getenv("AIOPQUIC_TX_RING_WAKE_PCT");
        if (env_lw && *env_lw) {
            int v = atoi(env_lw);
            if (v > 0 && v < 100) lw_pct = (uint32_t)v;
        }
        ctx->tx_event_ring_low_water = (tx_cap * lw_pct) / 100;
    }

#ifdef __linux__
    ctx->eventfd = eventfd(0, EFD_NONBLOCK | EFD_CLOEXEC);
    if (ctx->eventfd < 0) {
        spsc_ring_destroy(ctx->rx_event_ring);
        spsc_ring_destroy(ctx->tx_event_ring);
        aiopquic_dgram_table_destroy(&ctx->dgram_table);
        free(ctx);
        return NULL;
    }
    ctx->wake_write_fd = ctx->eventfd;
#else
    /* Self-pipe trick: pipe[0] is the read end (asyncio watches),
     * pipe[1] is the write end (network thread signals). pipe2() isn't
     * available on macOS, so set O_NONBLOCK | FD_CLOEXEC via fcntl. */
    int p[2];
    if (pipe(p) < 0) {
        spsc_ring_destroy(ctx->rx_event_ring);
        spsc_ring_destroy(ctx->tx_event_ring);
        aiopquic_dgram_table_destroy(&ctx->dgram_table);
        free(ctx);
        return NULL;
    }
    for (int i = 0; i < 2; i++) {
        int flags = fcntl(p[i], F_GETFL, 0);
        if (flags >= 0) (void)fcntl(p[i], F_SETFL, flags | O_NONBLOCK);
        int fd_flags = fcntl(p[i], F_GETFD, 0);
        if (fd_flags >= 0) (void)fcntl(p[i], F_SETFD, fd_flags | FD_CLOEXEC);
    }
    ctx->eventfd = p[0];
    ctx->wake_write_fd = p[1];
#endif

    return ctx;
}

static inline void aiopquic_ctx_destroy(aiopquic_ctx_t* ctx) {
    if (ctx) {
        if (ctx->eventfd >= 0) close(ctx->eventfd);
        if (ctx->wake_write_fd >= 0 && ctx->wake_write_fd != ctx->eventfd) {
            close(ctx->wake_write_fd);
        }
        spsc_overflow_destroy(&ctx->rx_overflow);
        spsc_ring_destroy(ctx->rx_event_ring);
        spsc_ring_destroy(ctx->tx_event_ring);
        aiopquic_dgram_table_destroy(&ctx->dgram_table);
        while (ctx->deferred_resets) {
            aiopquic_deferred_reset_t* d = ctx->deferred_resets;
            ctx->deferred_resets = d->next;
            aiopquic_deferred_reset_free(d);
        }
        while (ctx->close_reasons) {
            aiopquic_close_reason_t* r = ctx->close_reasons;
            ctx->close_reasons = r->next;
            free(r);
        }
        for (uint32_t i = 0; i < ctx->dgram_release_owed_n; i++) {
            aiopquic_dgram_buf_unref(ctx->dgram_release_owed[i].db);
        }
        free(ctx->dgram_release_owed);
        aiopquic_cnx_set_clear(&ctx->live_cnxs);
        if (ctx->alpn_list) {
            for (size_t i = 0; i < ctx->alpn_list_count; i++)
                free(ctx->alpn_list[i]);
            free(ctx->alpn_list);
        }
        free(ctx);
    }
}

/* picoquic calls perflog_fn from picoquic_delete_cnx (cnx, 0) and from
 * picoquic_free (NULL, 1), on the thread that owns the quic. */
static int aiopquic_cnx_delete_hook(picoquic_quic_t* quic, picoquic_cnx_t* cnx,
                                    int should_delete) {
    aiopquic_ctx_t* ctx = (aiopquic_ctx_t*)quic->v_perflog_ctx;
    if (ctx != NULL) {
        if (cnx != NULL) {
            aiopquic_cnx_set_del(&ctx->live_cnxs, cnx);
        }
        if (should_delete) {
            aiopquic_cnx_set_clear(&ctx->live_cnxs);
            ctx->live_cnxs_hooked = 0;
            quic->perflog_fn = NULL;
            quic->v_perflog_ctx = NULL;
        }
    }
    return 0;
}

/* Call before the quic has a cnx. A quic with its own perflog only walks. */
static inline void aiopquic_live_cnx_attach(aiopquic_ctx_t* ctx,
                                            picoquic_quic_t* quic) {
    aiopquic_cnx_set_clear(&ctx->live_cnxs);
    ctx->live_cnxs_hooked = 0;
    if (quic->perflog_fn == NULL) {
        quic->perflog_fn = aiopquic_cnx_delete_hook;
        quic->v_perflog_ctx = ctx;
        ctx->live_cnxs_hooked = 1;
    }
}

/* A cnx joins live_cnxs on its first confirmed walk and leaves it when
 * picoquic deletes it, so a hit is live. A perflog set after attach (e.g.
 * picoquic_perflog_setup) stops the delete hook, so the set is dropped. */
static inline int aiopquic_cnx_live(aiopquic_ctx_t* ctx, picoquic_quic_t* quic,
                                    picoquic_cnx_t* cnx) {
    if (ctx->live_cnxs_hooked && quic->perflog_fn != aiopquic_cnx_delete_hook) {
        aiopquic_cnx_set_clear(&ctx->live_cnxs);
        ctx->live_cnxs_hooked = 0;
    }
    if (aiopquic_cnx_set_has(&ctx->live_cnxs, cnx)) {
        return 1;
    }
    ctx->cnt_cnx_live_walks++;
    if (!aiopquic_cnx_is_alive(quic, cnx)) {
        return 0;
    }
    if (ctx->live_cnxs_hooked) {
        aiopquic_cnx_set_add(&ctx->live_cnxs, cnx);
    }
    return 1;
}

/* Usable datagram payload ceiling for this cnx: min(local TP, remote
 * TP, PICOQUIC_ENFORCED_INITIAL_MTU). The MTU term is the GUARANTEED
 * floor — picoquic admits any payload <= 1200 without consulting the
 * live path MTU (PICOQUIC_DATAGRAM_QUEUE_CAUTIOUS_LENGTH); larger may
 * work after PMTUD but there is no public send_mtu getter to promise
 * it. Returns 0 when the peer did not negotiate datagrams — doubling
 * as the capability check. Worker thread only: asyncio reads it from
 * aiopquic_cnx_snapshot_t. */
static inline uint32_t aiopquic_datagram_payload_ceiling(picoquic_cnx_t* cnx) {
    if (!cnx) return 0;
    const picoquic_tp_t* lt = picoquic_get_transport_parameters(cnx, 1);
    const picoquic_tp_t* rt = picoquic_get_transport_parameters(cnx, 0);
    if (!lt || !rt) return 0;
    uint32_t cap = lt->max_datagram_frame_size;
    if (rt->max_datagram_frame_size < cap) cap = rt->max_datagram_frame_size;
    if (cap == 0) return 0;
    if (cap > 1200) cap = 1200;
    return cap;
}

/* Receive window our transport parameters granted this stream at the
 * handshake (RFC 9000 §18.2). Bit 1 of the id: unidirectional; bit 0:
 * server-initiated. Worker thread only. */
static inline uint64_t aiopquic_initial_rx_window(picoquic_cnx_t* cnx,
                                                  uint64_t stream_id) {
    const picoquic_tp_t* tp = picoquic_get_transport_parameters(cnx, 1);
    if (!tp) return 0;
    if (stream_id & 2) return tp->initial_max_stream_data_uni;
    int local = (int)(stream_id & 1) == (picoquic_is_client(cnx) ? 0 : 1);
    return local ? tp->initial_max_stream_data_bidi_local
                 : tp->initial_max_stream_data_bidi_remote;
}

/* An IP address and port: family 4 or 6, 0 when unknown; addr in
 * network order (IPv4 in the first 4 bytes); port in host order. */
typedef struct {
    uint8_t family;
    uint8_t reserved;
    uint16_t port;
    uint8_t addr[16];
} aiopquic_addr_t;

static inline void aiopquic_addr_fill(const struct sockaddr* sa,
                                      aiopquic_addr_t* a) {
    if (sa == NULL) return;
    if (sa->sa_family == AF_INET) {
        const struct sockaddr_in* v4 = (const struct sockaddr_in*)sa;
        a->family = 4;
        a->port = ntohs(v4->sin_port);
        memcpy(a->addr, &v4->sin_addr, 4);
    } else if (sa->sa_family == AF_INET6) {
        const struct sockaddr_in6* v6 = (const struct sockaddr_in6*)sa;
        a->family = 6;
        a->port = ntohs(v6->sin6_port);
        memcpy(a->addr, &v6->sin6_addr, 16);
    }
}

/* A copy of a connection's picoquic state, taken on the worker thread and
 * delivered to asyncio as an event payload. asyncio reads the copy and
 * never touches picoquic memory, which the worker owns and frees. Sent
 * with READY (raw stack), with a server's ALMOST_READY, with
 * SPSC_EVT_WT_SESSION_READY (WebTransport client), with SPSC_EVT_CNX_STACK
 * (single-port dispatch), ahead of SPSC_EVT_WT_NEW_SESSION and in answer
 * to SPSC_EVT_TX_CNX_REFRESH. */
typedef struct {
    char alpn[32];                      /* NUL-terminated; empty if unknown */
    uint8_t has_tp_local;
    uint8_t has_tp_remote;
    uint32_t dgram_ceiling;
    picoquic_tp_t tp_local;
    picoquic_tp_t tp_remote;
    picoquic_connection_id_t cid_local;
    picoquic_connection_id_t cid_remote;
    picoquic_connection_id_t cid_initial;
    picoquic_path_quality_t path_quality;
    uint64_t data_sent;
    uint64_t data_received;
    aiopquic_addr_t peer_addr;
    aiopquic_addr_t local_addr;
    uint8_t session_resumed;            /* TLS resumed with a PSK */
} aiopquic_cnx_snapshot_t;

/* Worker thread only. */
static inline void aiopquic_cnx_snapshot_fill(picoquic_cnx_t* cnx,
                                              aiopquic_cnx_snapshot_t* s) {
    memset(s, 0, sizeof(*s));
    const char* alpn = picoquic_tls_get_negotiated_alpn(cnx);
    if (alpn) {
        strncpy(s->alpn, alpn, sizeof(s->alpn) - 1);
    }
    const picoquic_tp_t* lt = picoquic_get_transport_parameters(cnx, 1);
    const picoquic_tp_t* rt = picoquic_get_transport_parameters(cnx, 0);
    if (lt) {
        s->tp_local = *lt;
        s->has_tp_local = 1;
    }
    if (rt) {
        s->tp_remote = *rt;
        s->has_tp_remote = 1;
    }
    s->dgram_ceiling = aiopquic_datagram_payload_ceiling(cnx);
    s->cid_local = picoquic_get_local_cnxid(cnx);
    s->cid_remote = picoquic_get_remote_cnxid(cnx);
    s->cid_initial = picoquic_get_initial_cnxid(cnx);
    picoquic_get_default_path_quality(cnx, &s->path_quality);
    s->data_sent = picoquic_get_data_sent(cnx);
    s->data_received = picoquic_get_data_received(cnx);
    s->session_resumed = picoquic_tls_is_psk_handshake(cnx) ? 1 : 0;
    struct sockaddr* sa = NULL;
    picoquic_get_peer_addr(cnx, &sa);
    aiopquic_addr_fill(sa, &s->peer_addr);
    sa = NULL;
    picoquic_get_local_addr(cnx, &sa);
    aiopquic_addr_fill(sa, &s->local_addr);
}

/* Producer, after a TX event ring push: 1 if the caller must wake the
 * worker. A running worker drains the ring before it waits, so only an
 * idle one needs the syscall. The fence pairs with the one in
 * aiopquic_tx_worker_idle_arm: the worker sees the entry or this sees idle. */
static inline int aiopquic_tx_wake_needed(aiopquic_ctx_t* ctx) {
    __atomic_thread_fence(__ATOMIC_SEQ_CST);
    if (__atomic_load_n(&ctx->tx_worker_idle, __ATOMIC_RELAXED) == 0 ||
            __atomic_exchange_n(&ctx->tx_worker_idle, 0, __ATOMIC_ACQ_REL) == 0) {
        ctx->cnt_wake_skipped_coalesced++;
        return 0;
    }
    ctx->cnt_wake_calls++;
    return 1;
}

/* Worker, before a wait that can block: mark idle, then re-check the TX
 * ring. Returns 1, idle cleared, if entries are queued. */
static inline int aiopquic_tx_worker_idle_arm(aiopquic_ctx_t* ctx) {
    __atomic_store_n(&ctx->tx_worker_idle, 1, __ATOMIC_RELAXED);
    __atomic_thread_fence(__ATOMIC_SEQ_CST);
    if (spsc_ring_peek(ctx->tx_event_ring) == NULL) return 0;
    __atomic_store_n(&ctx->tx_worker_idle, 0, __ATOMIC_RELAXED);
    return 1;
}

/* Forward decl: aiopquic_maybe_fire_tx_event_ring_drained pushes
 * SPSC_EVT_TX_EVENT_RING_DRAINED into rx_event_ring and calls aiopquic_notify_rx
 * which is defined further down in this header. */
static inline void aiopquic_notify_rx(aiopquic_ctx_t* ctx);

/* RX event push that never drops an event: the ring while it has room,
 * else the order-preserving overflow. Wakes asyncio either way. Returns
 * 0, or -2 when out of memory, the one case still counted as a drop. */
static inline int aiopquic_rx_push(aiopquic_ctx_t* ctx,
                                   const spsc_entry_t* entry,
                                   const uint8_t* data, uint32_t data_len) {
    int rc = spsc_ring_push_or_overflow(ctx->rx_event_ring, &ctx->rx_overflow,
                                        entry, data, data_len);
    if (rc < 0) {
        ctx->worker_rx_event_drops++;
        return rc;
    }
    aiopquic_notify_rx(ctx);
    return 0;
}

/* RX events whose stream_ctx is a raw-QUIC sc. Each one queued holds a
 * reference to it, dropped once the drain is done with the entry. */
static inline int aiopquic_rx_event_owns_sc(uint32_t event_type) {
    return event_type == SPSC_EVT_STREAM_DATA ||
           event_type == SPSC_EVT_STREAM_FIN ||
           event_type == SPSC_EVT_STREAM_RESET ||
           event_type == SPSC_EVT_STOP_SENDING;
}

/* TX events whose stream_ctx is an sc. Each one queued holds a reference
 * to it, dropped by the worker on every path, dead-cnx drop included. */
static inline int aiopquic_tx_event_owns_sc(uint32_t event_type) {
    return event_type == SPSC_EVT_TX_STREAM_RESET ||
           event_type == SPSC_EVT_TX_STOP_SENDING ||
           event_type == SPSC_EVT_TX_MARK_ACTIVE ||
           event_type == SPSC_EVT_TX_OPEN_FLOW_CONTROL;
}

static inline void aiopquic_rx_event_release(const spsc_entry_t* e) {
    if (e->stream_ctx != NULL && aiopquic_rx_event_owns_sc(e->event_type)) {
        aiopquic_stream_ctx_destroy((aiopquic_stream_ctx_t*)e->stream_ctx);
    }
}

static inline void aiopquic_tx_event_release(const spsc_entry_t* e) {
    if (e->stream_ctx != NULL && aiopquic_tx_event_owns_sc(e->event_type)) {
        aiopquic_stream_ctx_destroy((aiopquic_stream_ctx_t*)e->stream_ctx);
    }
}

/* aiopquic_rx_push for an entry that may carry an sc: the queued entry
 * holds a reference, returned if the push fails. */
static inline int aiopquic_rx_push_sc(aiopquic_ctx_t* ctx,
                                      const spsc_entry_t* entry,
                                      const uint8_t* data, uint32_t data_len) {
    int owns = entry->stream_ctx != NULL &&
               aiopquic_rx_event_owns_sc(entry->event_type);
    if (owns) {
        aiopquic_stream_ctx_ref((aiopquic_stream_ctx_t*)entry->stream_ctx);
    }
    int rc = aiopquic_rx_push(ctx, entry, data, data_len);
    if (rc != 0 && owns) {
        aiopquic_stream_ctx_destroy((aiopquic_stream_ctx_t*)entry->stream_ctx);
    }
    return rc;
}

/* Asyncio thread: TX push for an entry that may carry an sc, with the same
 * contract. Returns spsc_ring_push's result. */
static inline int aiopquic_tx_push_sc(aiopquic_ctx_t* ctx,
                                      const spsc_entry_t* entry,
                                      const uint8_t* data, uint32_t data_len) {
    int owns = entry->stream_ctx != NULL &&
               aiopquic_tx_event_owns_sc(entry->event_type);
    if (owns) {
        aiopquic_stream_ctx_ref((aiopquic_stream_ctx_t*)entry->stream_ctx);
    }
    int rc = spsc_ring_push(ctx->tx_event_ring, entry, data, data_len);
    if (rc != 0 && owns) {
        aiopquic_stream_ctx_destroy((aiopquic_stream_ctx_t*)entry->stream_ctx);
    }
    return rc;
}

/* Asyncio thread, the worker stopped: drop the sc references of TX
 * entries it never consumed. A swept entry is cleared, so a second sweep
 * is a no-op. */
static inline void aiopquic_tx_sc_release_undrained(aiopquic_ctx_t* ctx) {
    spsc_ring_t* r = ctx->tx_event_ring;
    uint64_t head = atomic_load_explicit(&r->head, memory_order_acquire);
    uint64_t tail = atomic_load_explicit(&r->tail, memory_order_acquire);
    for (uint64_t i = head; i < tail; i++) {
        spsc_entry_t* e = &r->entries[i & r->mask];
        aiopquic_tx_event_release(e);
        if (aiopquic_tx_event_owns_sc(e->event_type)) {
            e->stream_ctx = NULL;
        }
    }
}

/* Python-side helpers for the TX ring drain wakeup protocol. The
 * producer (asyncio thread) calls arm() before awaiting the event,
 * and clear() if it raced with a worker drain. Worker side does
 * the CAS-clear+fire inside aiopquic_maybe_fire_tx_event_ring_drained. */
/* Returns 1 when the caller may wait: the worker fires once the ring is
 * at or below low water. Returns 0 when it already is: the caller
 * retries instead (the arm stays; another waiter may own it). The fence
 * pairs with aiopquic_tx_event_ring_drained_final. */
static inline int aiopquic_arm_tx_event_ring_drain_pending(aiopquic_ctx_t* ctx) {
    ctx->cnt_tx_event_ring_arms++;
    ctx->last_tx_event_ring_arm_ns = aiopquic_now_ns();
    __atomic_store_n(&ctx->tx_event_ring_drain_pending, 1,
                      __ATOMIC_RELAXED);
    __atomic_thread_fence(__ATOMIC_SEQ_CST);
    return spsc_ring_count(ctx->tx_event_ring) > ctx->tx_event_ring_low_water;
}

static inline void aiopquic_clear_tx_event_ring_drain_pending(aiopquic_ctx_t* ctx) {
    __atomic_store_n(&ctx->tx_event_ring_drain_pending, 0,
                      __ATOMIC_RELEASE);
}

/* Push an SPSC_EVT_TX_OPEN_FLOW_CONTROL event onto the TX ring so
 * the picoquic worker re-evaluates the per-stream MAX_STREAM_DATA
 * grant. Called from two sites:
 *   - drain_rx data paths after popping bytes from sc->rx (normal
 *     credit replenishment as peer data is consumed).
 *   - StreamChunk.__dealloc__ when a chunk's bytes are released
 *     back to aiopquic, so peer credit reopens when the Python
 *     pipeline drains. This is the closed-loop signal that breaks
 *     the FC-stall deadlock: peer doesn't need to send anything
 *     for credit to resume; releasing a chunk is sufficient.
 *
 * entry.stream_ctx carries the BORROWED aiopquic_stream_ctx_t* so
 * the worker can read both sc->rx_buf_free and sc->bytes_pending_release
 * when computing the effective grant. The wake is written only to an
 * idle worker (aiopquic_tx_wake_needed). */
static inline void aiopquic_push_fc_credit(aiopquic_ctx_t* ctx,
                                            void* cnx,
                                            uint64_t stream_id,
                                            aiopquic_stream_ctx_t* sc) {
    if (!ctx || !cnx || !sc) return;
    /* Take a ref on sc so the worker handler (which runs later,
     * possibly after the caller's chunk has been dealloc'd) can
     * safely deref sc->rx and sc->bytes_pending_release. The
     * handler is responsible for the matching unref via
     * aiopquic_stream_ctx_destroy. */
    aiopquic_stream_ctx_ref(sc);
    ctx->cnt_sc_ref_fc_credit++;
    spsc_entry_t entry;
    memset(&entry, 0, sizeof(entry));
    entry.event_type = SPSC_EVT_TX_OPEN_FLOW_CONTROL;
    entry.stream_id = stream_id;
    entry.cnx = (picoquic_cnx_t*)cnx;
    entry.stream_ctx = sc;
    if (spsc_ring_push(ctx->tx_event_ring, &entry, NULL, 0) == 0) {
        ctx->cnt_tx_event_ring_pushes++;
        ctx->cnt_fc_credit_pushed++;
        /* Wake only a running thread, and only when idle.
         * CRITICAL: picoquic_wake_up_network_thread takes
         * picoquic_network_thread_ctx_t*, NOT picoquic_quic_t* —
         * passing the wrong type is a UAF-class bug that silently
         * corrupts picoquic state. */
        if (ctx->thread_ctx != NULL && aiopquic_tx_wake_needed(ctx)) {
            picoquic_wake_up_network_thread(ctx->thread_ctx);
        }
    } else {
        /* tx_event_ring push failed (ring full). Drop the ref we just
         * took since no worker handler will run for this push. */
        ctx->cnt_fc_credit_dropped++;
        ctx->cnt_sc_destroy_fc_credit_pushfail++;
        aiopquic_stream_ctx_destroy(sc);
    }
}

/* Drop a released ring's reference, with cnx's table entry while that
 * still holds this ring. Worker thread, or the asyncio thread once no
 * worker runs. */
static inline void aiopquic_dgram_ring_drop(aiopquic_ctx_t* ctx, void* cnx,
                                            aiopquic_dgram_buf_t* db) {
    aiopquic_dgram_table_remove_ring(&ctx->dgram_table, cnx, db);
    aiopquic_dgram_buf_unref(db);
}

static inline int aiopquic_dgram_ring_release_post(aiopquic_ctx_t* ctx,
                                                   void* cnx,
                                                   aiopquic_dgram_buf_t* db) {
    spsc_entry_t entry;
    memset(&entry, 0, sizeof(entry));
    entry.event_type = SPSC_EVT_TX_DGRAM_RING_RELEASE;
    entry.cnx = cnx;
    entry.stream_ctx = db;
    if (spsc_ring_push(ctx->tx_event_ring, &entry, NULL, 0) != 0) {
        return -1;
    }
    ctx->cnt_tx_event_ring_pushes++;
    if (aiopquic_tx_wake_needed(ctx)) {
        picoquic_wake_up_network_thread(ctx->thread_ctx);
    }
    return 0;
}

static inline void aiopquic_dgram_ring_release_flush(aiopquic_ctx_t* ctx);

/* Asyncio thread: give up the caller's ring reference. A running worker
 * drops it behind every MARK queued before it, which carries the ring
 * without a reference; with none running it is dropped here. A full TX
 * ring owes the release to aiopquic_dgram_ring_release_flush. */
static inline void aiopquic_dgram_ring_release(aiopquic_ctx_t* ctx, void* cnx,
                                               aiopquic_dgram_buf_t* db) {
    if (db == NULL) return;
    if (ctx->thread_ctx == NULL) {
        aiopquic_dgram_buf_unref(db);
        return;
    }
    if (aiopquic_dgram_ring_release_post(ctx, cnx, db) == 0) return;
    if (ctx->dgram_release_owed_n == ctx->dgram_release_owed_cap) {
        uint32_t cap = ctx->dgram_release_owed_cap
                     ? 2 * ctx->dgram_release_owed_cap : 8;
        aiopquic_dgram_release_t* grown = (aiopquic_dgram_release_t*)realloc(
            ctx->dgram_release_owed, cap * sizeof(*grown));
        if (grown == NULL) return;  /* out of memory: the ring leaks */
        ctx->dgram_release_owed = grown;
        ctx->dgram_release_owed_cap = cap;
    }
    ctx->dgram_release_owed[ctx->dgram_release_owed_n].cnx = cnx;
    ctx->dgram_release_owed[ctx->dgram_release_owed_n].db = db;
    ctx->dgram_release_owed_n++;
    aiopquic_dgram_ring_release_flush(ctx);
}

/* Asyncio thread: post owed releases while the TX ring has room; what
 * stays owed is posted on the drain cycle the ring-drained event starts. */
static inline void aiopquic_dgram_ring_release_flush(aiopquic_ctx_t* ctx) {
    if (ctx->thread_ctx == NULL) return;
    for (;;) {
        uint32_t n = ctx->dgram_release_owed_n;
        uint32_t i = 0;
        while (i < n && aiopquic_dgram_ring_release_post(
                   ctx, ctx->dgram_release_owed[i].cnx,
                   ctx->dgram_release_owed[i].db) == 0) {
            i++;
        }
        if (i > 0) {
            memmove(ctx->dgram_release_owed, ctx->dgram_release_owed + i,
                    (n - i) * sizeof(*ctx->dgram_release_owed));
        }
        ctx->dgram_release_owed_n = n - i;
        if (n - i == 0 || aiopquic_arm_tx_event_ring_drain_pending(ctx)) {
            return;
        }
    }
}

/* Asyncio thread, the worker stopped: drop what queued and owed releases
 * still hold. A queued entry is cleared, so a second sweep is a no-op. */
static inline void aiopquic_dgram_ring_release_undrained(aiopquic_ctx_t* ctx) {
    spsc_ring_t* r = ctx->tx_event_ring;
    uint64_t head = atomic_load_explicit(&r->head, memory_order_acquire);
    uint64_t tail = atomic_load_explicit(&r->tail, memory_order_acquire);
    for (uint64_t i = head; i < tail; i++) {
        spsc_entry_t* e = &r->entries[i & r->mask];
        if (e->event_type == SPSC_EVT_TX_DGRAM_RING_RELEASE
                && e->stream_ctx != NULL) {
            aiopquic_dgram_ring_drop(ctx, e->cnx,
                                     (aiopquic_dgram_buf_t*)e->stream_ctx);
            e->stream_ctx = NULL;
        }
    }
    for (uint32_t i = 0; i < ctx->dgram_release_owed_n; i++) {
        aiopquic_dgram_ring_drop(ctx, ctx->dgram_release_owed[i].cnx,
                                 ctx->dgram_release_owed[i].db);
    }
    ctx->dgram_release_owed_n = 0;
}

/* Worker-side: if a Python writer armed tx_event_ring_drain_pending and the
 * TX SPSC event ring has now drained to or below the low-water mark,
 * fire SPSC_EVT_TX_EVENT_RING_DRAINED to wake the writer. CAS-clear ensures
 * exactly one event per arm.
 *
 * Called after every spsc_ring_pop(tx_event_ring) in the worker's drain
 * loop so the wake fires at the moment the count crosses below
 * low_water — gives the producer concurrent runway rather than
 * waiting for full drain.
 *
 * The arm itself is the producer-side "clear-arm-recheck-wait"
 * pattern: producer clears event, arms pending, re-checks pressure
 * (if dropped below high_water during the arm window, producer
 * proceeds without waiting; otherwise awaits the event).
 *
 * No lost wakeup: if producer armed and pressure is still high,
 * worker WILL fire at the next crossing of low_water (CAS-clear is
 * single-shot per arm; pending=1 persists until worker observes it
 * AND ring is below low_water). */
static inline void aiopquic_maybe_fire_tx_event_ring_drained(aiopquic_ctx_t* ctx) {
    if (__atomic_load_n(&ctx->tx_event_ring_drain_pending,
                         __ATOMIC_ACQUIRE) != 1) {
        return;
    }
    if (spsc_ring_count(ctx->tx_event_ring) > ctx->tx_event_ring_low_water) {
        return;
    }
    uint32_t expected = 1;
    if (!__atomic_compare_exchange_n(
            &ctx->tx_event_ring_drain_pending, &expected, 0,
            0, __ATOMIC_ACQ_REL, __ATOMIC_RELAXED)) {
        return;  /* another caller beat us; their fire is sufficient */
    }
    spsc_entry_t entry = {0};
    entry.event_type = SPSC_EVT_TX_EVENT_RING_DRAINED;
    if (aiopquic_rx_push(ctx, &entry, NULL, 0) == 0) {
        ctx->cnt_tx_event_ring_fires++;
        ctx->last_tx_event_ring_fire_ns = aiopquic_now_ns();
    } else {
        /* Out of memory: re-arm so the next pop fires again. */
        ctx->cnt_tx_event_ring_fire_dropped++;
        __atomic_store_n(&ctx->tx_event_ring_drain_pending, 1,
                          __ATOMIC_RELEASE);
    }
}

/* Worker, after the drain loop emptied the TX ring: an arm whose
 * re-check read the ring before the last pops is seen here. */
static inline void aiopquic_tx_event_ring_drained_final(aiopquic_ctx_t* ctx) {
    __atomic_thread_fence(__ATOMIC_SEQ_CST);
    aiopquic_maybe_fire_tx_event_ring_drained(ctx);
}

/* Signal asyncio that there are RX events.
 * Coalesced: write the wake fd only on the 0→1 transition of
 * rx_notify_pending. The consumer (aiopquic_clear_rx) restores the
 * flag to 0 after draining its ring snapshot and the wake fd, then
 * re-arms if the ring is still non-empty, so any push that races
 * against the consumer's drain is guaranteed to wake asyncio at least
 * once. ACQ_REL pairs with the consumer's exchange on the same flag
 * and ACQUIRE on the ring entries. */
static inline void aiopquic_notify_rx(aiopquic_ctx_t* ctx) {
    if (__atomic_exchange_n(&ctx->rx_notify_pending, 1,
                              __ATOMIC_ACQ_REL) != 0) {
        ctx->cnt_rx_notify_skips++;
        return;
    }
    ssize_t rc;
#ifdef __linux__
    uint64_t val = 1;
    rc = write(ctx->wake_write_fd, &val, sizeof(val));
#else
    uint8_t b = 1;
    rc = write(ctx->wake_write_fd, &b, 1);
#endif
    int err = (rc < 0) ? errno : 0;
    ctx->cnt_rx_notify_flips++;
    if (err) {
        ctx->cnt_rx_notify_write_errs++;
        ctx->last_rx_notify_errno = err;
    }
    aiopquic_wake_trace_add(&ctx->worker_trace, AIOPQUIC_WAKE_NOTIFY,
                            (uint32_t)err, spsc_ring_count(ctx->rx_event_ring));
}

/* Consumer-side wake-fd clear + re-arm. Caller (drain_rx) MUST have
 * already drained as many ring entries as it intends to consume in
 * this cycle BEFORE calling this. We then:
 *   1. Drain the wake-fd counter (Linux: one read; other: read until
 *      EAGAIN).
 *   2. Exchange rx_notify_pending to 0 so the NEXT producer push will
 *      write the wake fd (the producer's exchange sees 0→1).
 *   3. Re-arm by writing the wake fd if the ring or the overflow is
 *      still non-empty.
 * Read before clear: a notify that flips the flag after step 2 leaves
 * its write unread, so the reader runs again. Clearing first would let
 * step 1 consume such a write after its entry was drained, leaving
 * pending=1 with no wake to read and every later push skipping its
 * write. A push that saw pending=1 before step 2 skipped its write;
 * step 3 finds its entry. */
/* Events the consumer has taken off the RX ring so far (consumer-owned). */
static inline uint64_t aiopquic_rx_consumed(aiopquic_ctx_t* ctx) {
    return atomic_load_explicit(&ctx->rx_event_ring->head, memory_order_relaxed);
}

static inline void aiopquic_clear_rx(aiopquic_ctx_t* ctx) {
    spsc_ring_refill_from_overflow(ctx->rx_event_ring, &ctx->rx_overflow);
    uint64_t got = 0;
#ifdef __linux__
    uint64_t val = 0;
    if (read(ctx->eventfd, &val, sizeof(val)) > 0) {
        got = val;
    }
#else
    uint8_t buf[64];
    ssize_t n;
    while ((n = read(ctx->eventfd, buf, sizeof(buf))) > 0) {
        got += (uint64_t)n;
    }
#endif
    /* Exchange, so the re-check below cannot read the ring before the
     * clear is visible to aiopquic_notify_rx's exchange. */
    uint32_t was = __atomic_exchange_n(&ctx->rx_notify_pending, 0,
                                       __ATOMIC_ACQ_REL);
    uint32_t flags = was ? AIOPQUIC_CLEAR_WAS_PENDING : 0;
    ctx->cnt_rx_clears++;
    if (got == 0) {
        flags |= AIOPQUIC_CLEAR_READ_EMPTY;
        ctx->cnt_rx_clear_read_empty++;
    }
    /* Overflow counts too: a push that decided "overflow" before the
     * refill above and counted itself after it can have its wake consumed
     * by the read above while the ring is still empty. */
    uint32_t left = spsc_ring_count(ctx->rx_event_ring);
    if (left > 0 ||
            atomic_load_explicit(&ctx->rx_overflow.depth,
                                 memory_order_seq_cst) > 0) {
        ssize_t rc;
#ifdef __linux__
        uint64_t one = 1;
        rc = write(ctx->wake_write_fd, &one, sizeof(one));
#else
        uint8_t b = 1;
        rc = write(ctx->wake_write_fd, &b, 1);
#endif
        flags |= AIOPQUIC_CLEAR_REARMED;
        ctx->cnt_rx_rearms++;
        if (rc < 0) {
            flags |= AIOPQUIC_CLEAR_REARM_ERR;
        }
    }
    aiopquic_wake_trace_add(&ctx->asyncio_trace, AIOPQUIC_WAKE_CLEAR, flags,
                            ((uint64_t)left << 32) | (got & 0xffffffffu));
}

/* WT TX-event dispatch hook. Defined in h3wt_callback.h. The loop
 * callback below routes any TX entry whose event type is a WT
 * command (TX_WT_OPEN/CREATE_STREAM/CLOSE/DRAIN/RESET_STREAM)
 * through this function. Returns 1 if handled, 0 if not a WT TX
 * event (caller falls through to normal dispatch). */
static int aiopquic_wt_handle_tx(picoquic_quic_t* quic,
                                   aiopquic_ctx_t* ctx,
                                   spsc_entry_t* entry);

static inline int aiopquic_map_event(picoquic_call_back_event_t ev) {
    switch (ev) {
        case picoquic_callback_stream_data:     return SPSC_EVT_STREAM_DATA;
        case picoquic_callback_stream_fin:      return SPSC_EVT_STREAM_FIN;
        case picoquic_callback_stream_reset:    return SPSC_EVT_STREAM_RESET;
        case picoquic_callback_stop_sending:    return SPSC_EVT_STOP_SENDING;
        case picoquic_callback_close:           return SPSC_EVT_CLOSE;
        case picoquic_callback_application_close: return SPSC_EVT_APP_CLOSE;
        case picoquic_callback_ready:           return SPSC_EVT_READY;
        case picoquic_callback_almost_ready:    return SPSC_EVT_ALMOST_READY;
        case picoquic_callback_datagram:        return SPSC_EVT_DATAGRAM;
        case picoquic_callback_datagram_acked:  return SPSC_EVT_DATAGRAM_ACKED;
        case picoquic_callback_datagram_lost:   return SPSC_EVT_DATAGRAM_LOST;
        /* "Spurious loss" = a datagram earlier reported lost was in fact
         * delivered — surface it as an ACK so consumers keep one net
         * delivered/lost pair of counters. */
        case picoquic_callback_datagram_spurious: return SPSC_EVT_DATAGRAM_ACKED;
        case picoquic_callback_path_available:  return SPSC_EVT_PATH_AVAILABLE;
        case picoquic_callback_path_suspended:  return SPSC_EVT_PATH_SUSPENDED;
        case picoquic_callback_path_deleted:    return SPSC_EVT_PATH_DELETED;
        case picoquic_callback_pacing_changed:  return SPSC_EVT_PACING_CHANGED;
        default: return -1;
    }
}

/* Parse the next comma/space-delimited token from a CSV cursor. Advances
 * *cursor past the token. Copies the token (NUL-terminated, surrounding
 * quotes stripped) into out[0..outsz). Returns the token length, or 0 at
 * end of string. */
static inline size_t aiopquic_alpn_next_token(const char** cursor,
                                              char* out, size_t outsz) {
    const char* p = *cursor;
    size_t n = 0;
    while (*p == ' ' || *p == '\t' || *p == ',') p++;
    while (*p != '\0' && *p != ',' && *p != ' ' && *p != '\t') {
        if (*p != '"' && n + 1 < outsz) out[n++] = *p;
        p++;
    }
    if (outsz > 0) out[n] = '\0';
    *cursor = p;
    return n;
}

/* Parse a CSV (e.g. "moqt-18,moqt-16") into an owned array of
 * NUL-terminated strings on the bridge, in input/preference order,
 * replacing any previous list. Tokens are copied because
 * picoquic_add_proposed_alpn stores the pointers for the handshake's
 * lifetime. NULL/empty clears the list. */
static inline void aiopquic_ctx_set_alpn_list(aiopquic_ctx_t* ctx,
                                              const char* csv) {
    if (ctx == NULL) return;
    if (ctx->alpn_list != NULL) {
        for (size_t i = 0; i < ctx->alpn_list_count; i++)
            free(ctx->alpn_list[i]);
        free(ctx->alpn_list);
        ctx->alpn_list = NULL;
    }
    ctx->alpn_list_count = 0;
    if (csv == NULL || *csv == '\0') return;
    size_t cap = strlen(csv) + 1;  /* upper bound on token count */
    char** arr = (char**)malloc(cap * sizeof(char*));
    if (arr == NULL) return;
    char tok[256];
    const char* cursor = csv;
    size_t n = 0, tlen;
    while (n < cap &&
           (tlen = aiopquic_alpn_next_token(&cursor, tok, sizeof(tok))) > 0) {
        char* s = (char*)malloc(tlen + 1);
        if (s == NULL) {  /* OOM: free what we built and leave the list empty */
            for (size_t j = 0; j < n; j++) free(arr[j]);
            free(arr);
            return;
        }
        memcpy(s, tok, tlen + 1);  /* tok is NUL-terminated at tlen */
        arr[n++] = s;
    }
    if (n == 0) { free(arr); return; }
    ctx->alpn_list = arr;
    ctx->alpn_list_count = n;
}

/* Server-side ALPN selector (picoquic_alpn_select_fn_v2). Picks the
 * highest-preference protocol in the server's configured allowlist
 * (bridge->alpn_list) that the client also offered and returns its index
 * into the client's list. Honors SERVER preference order (RFC 7301: the
 * server selects); since aiomoqt lists drafts newest-first on both ends,
 * this resolves to the newest mutually-supported draft. Returns count
 * (reject → TLS no_application_protocol / PICOQUIC_TLS_ALERT_WRONG_ALPN)
 * when there is no overlap or no allowlist is set. Reached only when
 * default_alpn is NULL, i.e. a multi-ALPN server. */
static size_t aiopquic_alpn_select_cb(picoquic_quic_t* quic,
                                      picoquic_iovec_t* list, size_t count) {
    aiopquic_ctx_t* bridge =
        (aiopquic_ctx_t*)picoquic_get_default_callback_context(quic);
    if (bridge == NULL || bridge->alpn_list == NULL) return count;
    for (size_t a = 0; a < bridge->alpn_list_count; a++) {
        size_t alen = strlen(bridge->alpn_list[a]);
        for (size_t i = 0; i < count; i++) {
            if (list[i].len == alen &&
                memcmp(list[i].base, bridge->alpn_list[a], alen) == 0) {
                return i;
            }
        }
    }
    return count;  /* no mutual ALPN — reject the handshake */
}

/* Python drops its reference to every sc of a cnx on CLOSE / APP_CLOSE,
 * which the worker pushes only once the cnx is disconnecting or later. */
static inline int aiopquic_cnx_closing(picoquic_cnx_t* cnx) {
    return picoquic_get_cnx_state(cnx) >= picoquic_state_disconnecting;
}

/*
 * Picoquic stream/connection callback. Runs in the picoquic network thread.
 * Mandatory copy-out happens here: picoquic's stream-callback bytes have
 * callback-frame lifetime, so spsc_ring_push allocates a fresh buffer
 * and memcpys before publishing the entry.
 */
static int aiopquic_stream_cb(picoquic_cnx_t* cnx,
                               uint64_t stream_id,
                               uint8_t* bytes,
                               size_t length,
                               picoquic_call_back_event_t fin_or_event,
                               void* callback_ctx,
                               void* stream_ctx) {
    aiopquic_ctx_t* ctx = (aiopquic_ctx_t*)callback_ctx;
    if (!ctx) return -1;

    /* Client-side ALPN offer: picoquic asks the app for the ALPN list to
     * advertise in the ClientHello when the cnx was created with a NULL
     * alpn. 'bytes' is the opaque TLS context handed to
     * picoquic_add_proposed_alpn. Offer each configured ALPN in
     * preference order (newest first). */
    if (fin_or_event == picoquic_callback_request_alpn_list) {
        /* Offer each configured ALPN (preference order). The bridge owns
         * these strings; picoquic_add_proposed_alpn stores the pointers,
         * which stay valid until the handshake completes. */
        for (size_t i = 0; i < ctx->alpn_list_count; i++) {
            (void)picoquic_add_proposed_alpn((void*)bytes, ctx->alpn_list[i]);
        }
        return 0;
    }

    /* TX-side callback. PULL model only: stream_ctx is an
     * aiopquic_stream_ctx_t* set by picoquic_mark_active_stream
     * (queued via SPSC_EVT_TX_MARK_ACTIVE). Drain bytes from the
     * stream's sc->tx ring into picoquic's frame buffer up to the
     * caller's budget. If sc->tx drains to empty AND fin_pending
     * is set, signal FIN; else keep the stream active. The legacy
     * push-model fallback (stream_ctx==NULL → drain a single
     * SPSC_EVT_TX_STREAM_DATA/FIN entry from the shared TX ring)
     * was removed in 0.3.5; mark_active never passes NULL.
     */
    if (fin_or_event == picoquic_callback_prepare_to_send) {
        ctx->worker_prepare_to_send_calls++;
        if (stream_ctx) {
            aiopquic_stream_ctx_t* sc =
                (aiopquic_stream_ctx_t*)stream_ctx;
            aiopquic_stream_buf_t* sb = sc->tx;
            if (!sb) {
                (void)picoquic_provide_stream_data_buffer(bytes, 0, 0, 0);
                return 0;
            }
            uint32_t want = (uint32_t)length;
            /* FIN first: the producer sets it after publishing the
             * tail, so an acquire of a set FIN makes every byte
             * written before it visible to the tail load below. The
             * other order can FIN at an old tail and drop the rest. */
            int fin_after = aiopquic_stream_buf_fin_pending(sb);
            uint32_t avail = aiopquic_stream_buf_used(sb);
            uint32_t sendable = aiopquic_stream_ctx_tx_sendable(sc, avail);
            uint32_t to_send = (sendable < want) ? sendable : want;
            int is_fin = (fin_after && !sc->tx_reset_pending
                          && to_send == avail) ? 1 : 0;
            int is_still_active = (sendable > to_send) ? 1 : 0;
            if (!is_still_active && !is_fin
                    && aiopquic_stream_ctx_tx_park(sc, to_send, fin_after)) {
                is_still_active = 1;
                ctx->cnt_tx_park_kept_active++;
            }
            uint8_t* buf = picoquic_provide_stream_data_buffer(
                bytes, to_send, is_fin, is_still_active);
            if (buf && to_send > 0) {
                aiopquic_stream_buf_pop(sb, buf, to_send);
                ctx->worker_prepare_to_send_pulled_bytes += to_send;
                aiopquic_tx_data_bytes_pulled_add(to_send);
            } else {
                /* prepare_to_send invoked with no bytes to pull —
                 * either sc->tx empty (worker faster than producer)
                 * or picoquic offered length==0 (out of packet space).
                 * Tracked separately from the bytes-pulled case so the
                 * counter dump can tell idle from productive cycles. */
                ctx->cnt_prepare_to_send_empty++;
            }
            /* No sender-side STREAM_DESTROY here: picoquic may still
             * callback with stream_ctx=sc after our FIN (retransmit
             * / ACK), so early destroy is a UAF. Deferred to 0.3.6. */
            /* Edge-trigger TX backpressure: if a Python writer was
             * blocked (set tx_drain_pending=1 after seeing sc->tx
             * full OR via the soft byte-budget arm in path B),
             * CAS-clear and emit one SPSC event so it can wake and
             * retry. Single-shot per cycle — only the CAS winner
             * pushes the event.
             *
             * Hoisted OUTSIDE the to_send > 0 guard: prepare_to_send
             * may legitimately arrive with to_send == 0 (sc->tx drained
             * by a prior call, picoquic still calling us to ask) yet
             * the writer's "wait for sc->tx room" precondition is in
             * fact satisfied (avail == 0 means maximum room). Keeping
             * the fire inside the guard caused a deterministic miss
             * after the LAST drain emptied sc->tx — pending stayed
             * at 1 forever, sc_event never fired. Mirrors the WT
             * fix at h3wt_callback.h. */
            if (aiopquic_stream_ctx_tx_drain_take(sc)) {
                spsc_entry_t drain_entry = {0};
                drain_entry.event_type = SPSC_EVT_STREAM_TX_DRAINED;
                drain_entry.stream_id = stream_id;
                drain_entry.cnx = cnx;
                if (aiopquic_rx_push(ctx, &drain_entry, NULL, 0) == 0) {
                    sc->cnt_drain_fires++;
                    sc->last_drain_fire_ns = aiopquic_now_ns();
                } else {
                    /* Out of memory: re-arm so the next pull fires again. */
                    sc->cnt_drain_dropped++;
                    atomic_store_explicit(
                        &sc->tx_drain_pending, 1,
                        memory_order_release);
                }
            }
            return 0;
        }

        /* stream_ctx==NULL on prepare_to_send is unexpected in pull-model
         * 0.3.5+: mark_active is always called with a stream_ctx, so
         * picoquic should never invoke this callback with a null ctx.
         * Defensive: signal "no data" and return without consuming
         * anything from the shared TX ring. */
        (void)picoquic_provide_stream_data_buffer(bytes, 0, 0, 0);
        return 0;
    }

    /* picoquic decodes the frames behind a peer's close in the same
     * packet, but Python may already have dropped every sc of the cnx:
     * from here on stream callbacks create, touch and release no sc. */
    if ((fin_or_event == picoquic_callback_stream_data ||
         fin_or_event == picoquic_callback_stream_fin ||
         fin_or_event == picoquic_callback_stream_reset ||
         fin_or_event == picoquic_callback_stop_sending ||
         fin_or_event == picoquic_callback_stream_released) &&
        aiopquic_cnx_closing(cnx)) {
        ctx->cnt_stream_cb_after_close++;
        return 0;
    }

    /* picoquic fires this once per stream
     * when it considers the stream fully retired (pure receivers on
     * FIN/RESET; senders/bidi when all sent data ACKed). Universal
     * sc-destroy signal; covers cases the old pure-receiver-only
     * STREAM_DESTROY emit (further down) didn't. picoquic won't call
     * back with this stream_ctx again, so dropping the stream-
     * lifetime ref is safe. */
    if (fin_or_event == picoquic_callback_stream_released) {
        if (stream_ctx != NULL) {
            spsc_entry_t destroy_entry = {0};
            destroy_entry.event_type = SPSC_EVT_STREAM_DESTROY;
            destroy_entry.stream_id = stream_id;
            destroy_entry.cnx = cnx;
            destroy_entry.stream_ctx = stream_ctx;
            (void)aiopquic_rx_push(ctx, &destroy_entry, NULL, 0);
        }
        return 0;
    }

    if (fin_or_event == picoquic_callback_ready
            && ctx->keep_alive_us > 0) {
        /* Enable keep-alive once the cnx is ready (worker thread owns
         * the cnx here). PING frames keep a quiet connection alive past
         * the idle timeout — important for a flow-controlled subscriber
         * whose consumer stalled and back-pressured the sender silent. */
        picoquic_enable_keep_alive(cnx, ctx->keep_alive_us);
    }

    /* Pull-model datagram TX. picoquic asks for the next datagram:
     * 'bytes' is the opaque provide-context, 'length' is the space
     * available in the packet under construction (already capped at
     * the peer's max_datagram_frame_size). Copy the head record from
     * the cnx's record ring straight into the packet. A head record
     * larger than THIS packet's leftover space stays queued — producer-
     * side max_record enforcement guarantees it fits a fresh packet. */
    if (fin_or_event == picoquic_callback_prepare_datagram) {
        ctx->worker_dgram_prepare_calls++;
        aiopquic_dgram_buf_t* db =
            aiopquic_dgram_table_get(&ctx->dgram_table, cnx);
        uint32_t rec = db ? aiopquic_dgram_buf_peek_len(db) : 0;
        if (rec == 0) {
            (void)picoquic_provide_datagram_buffer_ex(
                bytes, 0, picoquic_datagram_not_active);
        } else if (rec <= (uint32_t)length) {
            /* More records after this one? Keep the mark active. */
            uint32_t used = aiopquic_dgram_buf_used(db);
            picoquic_datagram_active_enum still =
                (used > AIOPQUIC_DGRAM_REC_HDR + rec)
                    ? picoquic_datagram_active_any_path
                    : picoquic_datagram_not_active;
            uint8_t* buf = picoquic_provide_datagram_buffer_ex(
                bytes, rec, still);
            if (buf) {
                aiopquic_dgram_buf_pop_into(db, buf, rec);
                ctx->worker_dgram_records_sent++;
                ctx->worker_dgram_bytes_sent += rec;
                /* Edge-trigger producer wakeup, mirroring the stream
                 * sc->tx_drain_pending contract: only the CAS winner
                 * emits the event. */
                if (aiopquic_dgram_buf_drain_take(db)) {
                    spsc_entry_t drain_entry = {0};
                    drain_entry.event_type = SPSC_EVT_DATAGRAM_TX_DRAINED;
                    drain_entry.cnx = cnx;
                    if (aiopquic_rx_push(ctx, &drain_entry, NULL, 0) != 0) {
                        /* Out of memory: re-arm so a later pop fires again. */
                        atomic_store_explicit(&db->drain_pending, 1,
                                              memory_order_release);
                    }
                }
            }
        } else {
            db->head_deferred++;
            (void)picoquic_provide_datagram_buffer_ex(
                bytes, 0, picoquic_datagram_active_any_path);
        }
        return 0;
    }

    if (ctx->deferred_resets
            && (fin_or_event == picoquic_callback_close
                || fin_or_event == picoquic_callback_application_close
                || fin_or_event == picoquic_callback_stateless_reset)) {
        aiopquic_deferred_resets_drop_cnx(ctx, cnx);
    }
    if (ctx->close_reasons
            && (fin_or_event == picoquic_callback_close
                || fin_or_event == picoquic_callback_stateless_reset)) {
        aiopquic_close_reason_drop(ctx, cnx);
    }

    int evt = aiopquic_map_event(fin_or_event);
    if (evt < 0) {
        return 0;
    }

    spsc_entry_t entry = {0};
    entry.event_type = (uint32_t)evt;
    entry.stream_id = stream_id;
    entry.cnx = cnx;
    entry.stream_ctx = stream_ctx;

    if (fin_or_event == picoquic_callback_stream_reset) {
        entry.error_code = picoquic_get_remote_stream_error(cnx, stream_id);
    } else if (fin_or_event == picoquic_callback_stop_sending) {
        entry.error_code =
            picoquic_get_remote_stop_sending_error(cnx, stream_id);
    } else if (fin_or_event == picoquic_callback_application_close) {
        entry.error_code = picoquic_get_application_error(cnx);
        aiopquic_dgram_table_remove(&ctx->dgram_table, cnx);
    } else if (fin_or_event == picoquic_callback_close) {
        entry.error_code = picoquic_get_remote_error(cnx);
        if (entry.error_code == 0 && picoquic_get_local_error(cnx) != 0) {
            entry.error_code = picoquic_get_local_error(cnx);
            entry.is_fin = AIOPQUIC_CLOSE_LOCAL;
        }
        aiopquic_dgram_table_remove(&ctx->dgram_table, cnx);
    }

    /* Canonical RX path: stream_data / stream_fin bytes are pushed
     * synchronously into a per-stream byte ring on the wrapper. The
     * SPSC event delivered to Python carries ONLY the wrapper pointer
     * (no payload), so picoquic's "callback returns = bytes consumed"
     * contract is satisfied without ever risking a silent drop on
     * SPSC ring full.
     *
     * The Python consumer (connection.py RX drain) pops bytes from
     * sc->rx, builds StreamDataReceived events, and (Landing B)
     * advances peer credit via picoquic_open_flow_control. */
    int has_payload = (fin_or_event == picoquic_callback_stream_data ||
                       fin_or_event == picoquic_callback_stream_fin)
                      && bytes != NULL && length > 0;
    int ret;
    aiopquic_stream_ctx_t* coalesce_sc = NULL;
    if (has_payload) {
        /* Physical RX ring sized at exactly the advertised window
         * (1x). picoquic's auto-FC extension is gated by
         * !stream->use_app_flow_control (frames.c:4638), and we set
         * use_app_flow_control=1 SYNCHRONOUSLY inside this first
         * stream_data callback before returning to picoquic's send
         * framer — so no auto-extend frame can be emitted after our
         * opt-in. Before our opt-in, the peer's max in-flight bytes
         * is bounded by the initial_max_stream_data transport
         * parameter; after, by advertise_cap. Neither produces 2x
         * overshoot, so the previous 2x headroom was unnecessary
         * memory traffic + cache footprint per stream. RX ring
         * overflow remains a hard error: a peer that overruns is a
         * spec-correct FLOW_CONTROL_ERROR connection close. */
        uint32_t advertise_cap = ctx->rx_data_ring_cap > 0
            ? ctx->rx_data_ring_cap
            : AIOPQUIC_RX_DATA_RING_CAP_DEFAULT;
        uint32_t physical_cap = advertise_cap;
        aiopquic_stream_ctx_t* sc = (aiopquic_stream_ctx_t*)stream_ctx;
        if (!sc) {
            sc = aiopquic_stream_ctx_create();
            if (!sc) {
                return -1;
            }
            ctx->cnt_sc_create_raw_quic++;
            picoquic_set_app_stream_ctx(cnx, stream_id, sc);
            entry.stream_ctx = sc;
        }
        /* First RX on this stream, including a local bidi whose sc the
         * TX path created: switch it to application-driven flow control. */
        int rx_first_touch = (sc->rx == NULL);
        if (rx_first_touch) {
            (void)picoquic_set_app_flow_control(cnx, stream_id, 1);
        }
        if (aiopquic_stream_ctx_ensure_rx(sc, physical_cap) != 0) {
            return -1;
        }
        uint32_t pushed = aiopquic_stream_buf_push(
            sc->rx, bytes, (uint32_t)length);
        if (pushed > 0) {
            aiopquic_sc_rx_bytes_pushed_add(pushed);
        }
        if (pushed != length) {
            /* Per-stream RX byte-ring overflow. Means the peer sent
             * more than its advertised flow-control window allowed —
             * a spec-correct FLOW_CONTROL_ERROR connection close.
             * Counter incremented from worker thread; opt-in stderr
             * via env AIOPQUIC_RX_LOG=1 (libc stdio holds a global
             * lock and stalls the worker thread under load, so the
             * default is silent). */
            ctx->worker_rx_byte_ring_overflow++;
            if (aiopquic_rx_log_enabled()) {
                fprintf(stderr,
                    "[aiopquic_rx] stream=%llu RX ring overflow: "
                    "pushed %u of %zu (free=%u, physical_cap=%u, "
                    "advertised=%u). Peer flow-control violation.\n",
                    (unsigned long long)stream_id, pushed, length,
                    aiopquic_stream_buf_free(sc->rx),
                    physical_cap, advertise_cap);
            }
            return -1;
        }
        if (fin_or_event == picoquic_callback_stream_fin) {
            aiopquic_stream_buf_set_fin(sc->rx);
        }
        /* First touch extends the handshake window to the ring only when
         * the window is smaller, and never once FIN arrived (RFC 9000
         * §3.3); replenishment is consumer-driven
         * (SPSC_EVT_TX_OPEN_FLOW_CONTROL from drain_rx). */
        if (rx_first_touch) {
            if (fin_or_event != picoquic_callback_stream_fin &&
                aiopquic_initial_rx_window(cnx, stream_id) < advertise_cap) {
                uint32_t buf_free = aiopquic_stream_buf_free(sc->rx);
                (void)picoquic_open_flow_control(cnx, stream_id, buf_free);
            }
            aiopquic_stream_ctx_rx_credit_store(sc, advertise_cap);
        }
        /* RX data-event coalescing: at most ONE outstanding STREAM_DATA
         * notification per stream. The event carries no payload —
         * drain pops ALL available sc->rx bytes per notification — so
         * extra notifications are pure ring traffic that, under flood,
         * overflow the ring and get DROPPED, stranding bytes already
         * sitting in sc->rx. Only the CAS winner pushes; losers
         * return knowing the in-flight notification's drain picks up
         * their bytes. FIN always pushes — end-of-stream is a
         * distinct signal the drain must see. */
        if (entry.event_type == SPSC_EVT_STREAM_DATA) {
            if (!aiopquic_stream_ctx_rx_event_pending_arm(sc)) {
                ctx->cnt_rx_data_event_coalesced++;
                return 0;
            }
            coalesce_sc = sc;
        }
        ret = aiopquic_rx_push_sc(ctx, &entry, NULL, 0);
    } else if (entry.event_type == SPSC_EVT_DATAGRAM_ACKED ||
               entry.event_type == SPSC_EVT_DATAGRAM_LOST) {
        /* Delivery signals, not data: picoquic hands us the ORIGINAL
         * datagram body here. Copying it into the ring paid a malloc +
         * memcpy per event for payloads no consumer read. Surface the
         * event with its length only. */
        entry.data_length = (uint32_t)length;
        ret = aiopquic_rx_push(ctx, &entry, NULL, 0);
    } else if (fin_or_event == picoquic_callback_ready
               || (fin_or_event == picoquic_callback_almost_ready
                   && !picoquic_is_client(cnx))) {
        /* The handshake-time state asyncio needs rides with READY; a
         * server's ALMOST_READY creates its connection, so it carries one
         * too. */
        aiopquic_cnx_snapshot_t snap;
        aiopquic_cnx_snapshot_fill(cnx, &snap);
        ret = aiopquic_rx_push(ctx, &entry,
                               (const uint8_t*)&snap, sizeof(snap));
    } else if (fin_or_event == picoquic_callback_close
               || fin_or_event == picoquic_callback_application_close) {
        /* The peer's reason phrase, or the local cause's name. */
        const char* reason = (entry.is_fin & AIOPQUIC_CLOSE_LOCAL)
            ? picoquic_error_name(entry.error_code)
            : picoquic_get_remote_error_reason(cnx);
        ret = aiopquic_rx_push_sc(ctx, &entry, (const uint8_t*)reason,
                                  reason ? (uint32_t)strlen(reason) : 0);
    } else {
        ret = aiopquic_rx_push_sc(ctx, &entry, bytes, (uint32_t)length);
    }
    if (ret != 0) {
        /* Out of memory: the notification is gone. Stream bytes wait
         * in sc->rx and the next arrival re-arms. */
        if (has_payload) {
            ctx->worker_rx_event_drops_stream_data++;
        }
        if (coalesce_sc != NULL) {
            aiopquic_stream_ctx_rx_event_pending_clear(coalesce_sc);
        }
        if (aiopquic_rx_log_enabled()
                && ctx->worker_rx_event_drops <= 100) {
            fprintf(stderr,
                "[aiopquic_rx] EVENT DROP (no memory): "
                "stream=%llu evt=%u\n",
                (unsigned long long)stream_id, entry.event_type);
        }
    }

    return 0;
}

/* picoquic_reset_stream and picoquic_stop_sending detach the stream's app
 * ctx, so stream_released, which frees sc, would never fire: put sc back.
 * Once the cnx is closing, Python may have dropped the stream's reference
 * and only the event's keeps sc alive, so it is not handed back to
 * picoquic. Returns sc when reattached, else NULL. */
static inline aiopquic_stream_ctx_t* aiopquic_stream_reattach_sc(
        aiopquic_ctx_t* ctx, picoquic_cnx_t* cnx, uint64_t stream_id,
        aiopquic_stream_ctx_t* sc, int rc) {
    if (sc == NULL || rc == PICOQUIC_ERROR_INVALID_STREAM_ID) return NULL;
    if (aiopquic_cnx_closing(cnx)) {
        ctx->cnt_tx_reattach_after_close++;
        return NULL;
    }
    (void)picoquic_set_app_stream_ctx(cnx, stream_id, sc);
    return sc;
}

static inline aiopquic_stream_ctx_t* aiopquic_stream_reattach(
        aiopquic_ctx_t* ctx, picoquic_cnx_t* cnx, const spsc_entry_t* entry,
        int rc) {
    return aiopquic_stream_reattach_sc(
        ctx, cnx, entry->stream_id,
        (aiopquic_stream_ctx_t*)entry->stream_ctx, rc);
}

/* WT half of a held reset. Defined in h3wt_callback.h. */
static void aiopquic_wt_deferred_reset(aiopquic_ctx_t* ctx,
                                       aiopquic_deferred_reset_t* d);

/* After a send pass: send the held resets whose reliable bytes are out.
 * Once a second, also drop those of cnxs that went away without a close
 * callback. Worker only. */
static void aiopquic_run_deferred_resets(picoquic_quic_t* quic,
                                         aiopquic_ctx_t* ctx) {
    uint64_t now = picoquic_get_quic_time(quic);
    int sweep = now - ctx->deferred_resets_swept >= 1000000;
    if (sweep) ctx->deferred_resets_swept = now;
    aiopquic_deferred_reset_t** pp = &ctx->deferred_resets;
    while (*pp) {
        aiopquic_deferred_reset_t* d = *pp;
        uint64_t head = atomic_load_explicit(&d->sc->tx->head,
                                             memory_order_relaxed);
        int ready = head >= d->sc->tx_reliable_size;
        if (!ready && !sweep) {
            pp = &d->next;
            continue;
        }
        int alive = aiopquic_cnx_live(ctx, quic, d->cnx);
        if (alive && !ready) {
            pp = &d->next;
            continue;
        }
        *pp = d->next;
        d->next = NULL;
        if (alive && !aiopquic_cnx_closing(d->cnx)) {
            d->sc->tx_reset_pending = 0;
            if (d->is_wt) {
                aiopquic_wt_deferred_reset(ctx, d);
            } else {
                int rr = aiopquic_reset_stream_reliable(d->cnx, d->stream_id,
                    d->error_code, d->sc->tx_reliable_size);
                aiopquic_stream_ctx_tx_abandon(aiopquic_stream_reattach_sc(
                    ctx, d->cnx, d->stream_id, d->sc, rr));
            }
        }
        aiopquic_deferred_reset_free(d);
    }
}

/*
 * Packet loop callback. The TX ring drains on a wake-up and, for entries
 * whose producers skipped the wake, before each wait.
 */
static int aiopquic_loop_cb(picoquic_quic_t* quic,
                             picoquic_packet_loop_cb_enum cb_mode,
                             void* callback_ctx,
                             void* callback_argv) {
    aiopquic_ctx_t* ctx = (aiopquic_ctx_t*)callback_ctx;
    ctx->cnt_loop_cb++;
    /* Running: producers may skip the wake until time_check re-arms. */
    if (__atomic_load_n(&ctx->tx_worker_idle, __ATOMIC_RELAXED) != 0) {
        if (ctx->tx_worker_armed_at == 0) {
            __atomic_store_n(&ctx->tx_worker_idle, 0, __ATOMIC_RELAXED);
        } else if (__atomic_exchange_n(&ctx->tx_worker_idle, 0, __ATOMIC_RELAXED) != 0 &&
                picoquic_current_time() - ctx->tx_worker_armed_at
                    >= AIOPQUIC_TX_WAKE_LOST_US &&
                spsc_ring_peek(ctx->tx_event_ring) != NULL) {
            /* Woke on its own from a long wait with entries queued: a
             * producer skipped the wake. */
            ctx->cnt_tx_wake_lost++;
        }
    }

    switch (cb_mode) {
        case picoquic_packet_loop_ready:
            ctx->quic = quic;
            if (callback_argv != NULL) {
                ((picoquic_packet_loop_options_t*)callback_argv)->do_time_check = 1;
            }
#ifdef __linux__
            /* The loop sleeps in ppoll() until the next paced send, often
             * tens of µs away; the default 50 µs timer slack overshoots it. */
            (void)prctl(PR_SET_TIMERSLACK, 1000UL, 0, 0, 0);
#endif
            {
                spsc_entry_t ready = {0};
                ready.event_type = SPSC_EVT_READY;
                (void)aiopquic_rx_push(ctx, &ready, NULL, 0);
            }
            break;

        case picoquic_packet_loop_time_check: {
            /* Runs before every wait that can block. */
            packet_loop_time_check_arg_t* tc =
                (packet_loop_time_check_arg_t*)callback_argv;
            if (tc->delta_t > 0) {
                ctx->tx_worker_armed_at = (tc->delta_t >= AIOPQUIC_TX_WAKE_LOST_US)
                    ? tc->current_time : 0;
            }
            int queued = (tc->delta_t > 0)
                ? aiopquic_tx_worker_idle_arm(ctx)
                : spsc_ring_peek(ctx->tx_event_ring) != NULL;
            if (!queued) {
                break;
            }
            /* Drained entries can make a send due now. */
            tc->delta_t = 0;
        }
            /* fall through */
        case picoquic_packet_loop_wake_up:
            while (1) {
                spsc_entry_t* entry = spsc_ring_peek(ctx->tx_event_ring);
                if (!entry) break;

                picoquic_cnx_t* cnx = (picoquic_cnx_t*)entry->cnx;

                if (entry->event_type == SPSC_EVT_TX_CONNECT) {
                    const uint8_t* raw = (const uint8_t*)entry->data_buf;
                    if (raw && entry->data_length >=
                            sizeof(aiopquic_connect_params_t)) {
                        const aiopquic_connect_params_t* p =
                            (const aiopquic_connect_params_t*)raw;
                        const char* sni_ptr = NULL;
                        const char* alpn_ptr = NULL;
                        char sni_buf[256];
                        char alpn_buf[64];
                        size_t offset = sizeof(aiopquic_connect_params_t);

                        if (p->sni_len > 0 && p->sni_len < sizeof(sni_buf) &&
                            offset + p->sni_len <= entry->data_length) {
                            memcpy(sni_buf, raw + offset, p->sni_len);
                            sni_buf[p->sni_len] = '\0';
                            sni_ptr = sni_buf;
                            offset += p->sni_len;
                        }
                        if (p->alpn_len > 0 && p->alpn_len < sizeof(alpn_buf) &&
                            offset + p->alpn_len <= entry->data_length) {
                            memcpy(alpn_buf, raw + offset, p->alpn_len);
                            alpn_buf[p->alpn_len] = '\0';
                            alpn_ptr = alpn_buf;
                        }

                        /* picoquic_create_client_cnx, with the desired version
                         * set before the first Initial goes out. */
                        picoquic_cnx_t* new_cnx = picoquic_create_cnx(
                            quic, picoquic_null_connection_id,
                            picoquic_null_connection_id,
                            (struct sockaddr*)&p->addr,
                            picoquic_current_time(), 0,
                            sni_ptr, alpn_ptr, 1);
                        if (new_cnx) {
                            picoquic_set_callback(new_cnx, aiopquic_stream_cb,
                                                  (void*)ctx);
                            if (p->desired_version != 0) {
                                picoquic_set_desired_version(new_cnx,
                                                             p->desired_version);
                            }
                            if (picoquic_start_client_cnx(new_cnx) != 0) {
                                picoquic_delete_cnx(new_cnx);
                                new_cnx = NULL;
                            }
                        }
                        if (new_cnx) {
                            spsc_entry_t resp = {0};
                            resp.event_type = SPSC_EVT_ALMOST_READY;
                            resp.cnx = new_cnx;
                            (void)aiopquic_rx_push(ctx, &resp, NULL, 0);
                        }
                    }
                    ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                    aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                    continue;
                }

                if (entry->event_type == SPSC_EVT_TX_SET_MAX_CONNECTIONS) {
                    (void)picoquic_adjust_max_connections(
                        quic, (uint32_t)entry->error_code);
                    ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                    aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                    continue;
                }

                /* Ahead of the stale-cnx guard: the ring is released
                 * whether or not its cnx lives; cnx is only a table key. */
                if (entry->event_type == SPSC_EVT_TX_DGRAM_RING_RELEASE) {
                    if (entry->stream_ctx != NULL) {
                        aiopquic_dgram_ring_drop(
                            ctx, entry->cnx,
                            (aiopquic_dgram_buf_t*)entry->stream_ctx);
                    }
                    ctx->worker_dgram_ring_release_processed++;
                    ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                    aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                    continue;
                }

                /* WT events route through aiopquic_wt_handle_tx, which
                 * interprets entry->cnx as aiopquic_wt_session_t* — NOT a
                 * picoquic_cnx_t*. TX_WT_OPEN in particular CREATES the
                 * picoquic cnx (via picowt_prepare_client_cnx) and stashes
                 * it into wt_session->cnx. The raw-QUIC liveness guard
                 * below must not be applied to these: walking picoquic's
                 * live-cnx list with a wt_session pointer always misses
                 * and drops the event. WT sessions track their own
                 * lifecycle inside aiopquic_wt_handle_tx. */
                if ((entry->event_type >= SPSC_EVT_TX_WT_OPEN &&
                     entry->event_type <= SPSC_EVT_TX_WT_STOP_SENDING) ||
                    entry->event_type == SPSC_EVT_TX_WT_SESSION_CLEANUP ||
                    entry->event_type == SPSC_EVT_TX_MARK_WT_DATAGRAM_READY ||
                    entry->event_type == SPSC_EVT_TX_WT_SET_STREAM_PRIORITY ||
                    entry->event_type == SPSC_EVT_TX_WT_SET_DATAGRAM_PRIORITY ||
                    entry->event_type == SPSC_EVT_TX_WT_FIN) {
                    (void)aiopquic_wt_handle_tx(quic, ctx, entry);
                    ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                    aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                    continue;
                }

                /* Stale-cnx guard. Drops events whose cnx was freed
                 * between the Python push and this pop. Without this,
                 * any picoquic_* call below UAFs. */
                if (!cnx || !aiopquic_cnx_live(ctx, quic, cnx)) {
                    ctx->cnt_tx_event_dropped_dead_cnx++;
                    if (entry->event_type == SPSC_EVT_TX_OPEN_FLOW_CONTROL &&
                        entry->stream_ctx != NULL) {
                        ctx->cnt_sc_destroy_fc_credit_dead_cnx++;
                    }
                    aiopquic_tx_event_release(entry);
                    ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                    aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                    continue;
                }

                switch (entry->event_type) {
                    case SPSC_EVT_TX_MARK_ACTIVE: {
                        /* Raw QUIC pushes stream_ctx = sc so picoquic's
                         * app_stream_ctx routes sc into subsequent
                         * stream callbacks. WT pushes stream_ctx = NULL
                         * (h3zero owns app_stream_ctx) — use v2 so the
                         * h3zero pointer isn't clobbered. */
                        if (entry->stream_ctx != NULL) {
                            if (aiopquic_cnx_closing(cnx)) {
                                ctx->cnt_tx_reattach_after_close++;
                            } else {
                                picoquic_mark_active_stream(
                                    cnx, entry->stream_id, 1,
                                    entry->stream_ctx);
                            }
                        } else {
                            picoquic_mark_active_stream_v2(cnx, entry->stream_id,
                                                            1);
                        }
                        aiopquic_tx_event_release(entry);
                        ctx->worker_mark_active_processed++;
                        ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                        aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                        break;
                    }
                    /* SPSC_EVT_TX_STREAM_DATA / SPSC_EVT_TX_STREAM_FIN
                     * (push-model byte-bearing events) were removed in
                     * 0.3.5. All stream writes now flow through the
                     * pull-model path: producer commits to sc->tx and
                     * pushes a MARK_ACTIVE event; picoquic later drains
                     * via the prepare_to_send callback. */
                    case SPSC_EVT_TX_MARK_DATAGRAM_READY: {
                        /* Producer already committed the record(s) to the
                         * per-cnx ring; register the ring (idempotent,
                         * takes a worker-side ref on first sight) and
                         * arm picoquic's datagram scheduler. The ring is
                         * alive: Python's release queues behind this. */
                        aiopquic_dgram_buf_t* db =
                            (aiopquic_dgram_buf_t*)entry->stream_ctx;
                        if (db) {
                            (void)aiopquic_dgram_table_put(
                                &ctx->dgram_table, cnx, db);
                            (void)picoquic_mark_datagram_ready(cnx, 1);
                        }
                        ctx->worker_dgram_mark_ready_processed++;
                        ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                        aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                        break;
                    }
                    case SPSC_EVT_TX_SET_STREAM_PRIORITY: {
                        int pri_ret = picoquic_set_stream_priority(
                            cnx, entry->stream_id,
                            (uint8_t)entry->error_code);
                        if (pri_ret == 0) {
                            ctx->worker_set_priority_applied++;
                        } else {
                            ctx->worker_set_priority_rejected++;
                            ctx->worker_set_priority_last_err =
                                (uint64_t)pri_ret;
                        }
                        ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                        aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                        break;
                    }
                    case SPSC_EVT_TX_SET_DATAGRAM_PRIORITY:
                        picoquic_set_datagram_priority(cnx, (uint8_t)entry->error_code);
                        ctx->worker_set_dgram_priority_applied++;
                        ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                        aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                        break;
                    case SPSC_EVT_TX_CNX_REFRESH: {
                        /* cnx liveness already verified by the outer
                         * aiopquic_cnx_live() guard above. */
                        aiopquic_cnx_snapshot_t snap;
                        aiopquic_cnx_snapshot_fill(cnx, &snap);
                        spsc_entry_t out = {0};
                        out.event_type = SPSC_EVT_CNX_SNAPSHOT;
                        out.cnx = cnx;
                        (void)aiopquic_rx_push(ctx, &out, (const uint8_t*)&snap,
                                               sizeof(snap));
                        ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                        aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                        break;
                    }
                    case SPSC_EVT_TX_CLOSE: {
                        /* cnx liveness already verified by the outer
                         * aiopquic_cnx_live() guard above. */
                        const char* reason = aiopquic_close_reason_hold(
                            ctx, cnx, entry->data_buf, entry->data_length);
                        if (reason) {
                            picoquic_close_ex(cnx, entry->error_code, reason);
                        } else {
                            picoquic_close(cnx, entry->error_code);
                        }
                        ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                        aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                        break;
                    }
                    case SPSC_EVT_TX_STREAM_RESET: {
                        aiopquic_stream_ctx_t* sc =
                            (aiopquic_stream_ctx_t*)entry->stream_ctx;
                        if (sc && sc->tx_reset_pending) {
                            /* Already resetting. */
                        } else if (aiopquic_stream_can_send(cnx, entry->stream_id)) {
                            uint64_t reliable = aiopquic_reset_reliable_size(
                                cnx, sc, entry->aux);
                            if (reliable > 0 && reliable > atomic_load_explicit(
                                    &sc->tx->head, memory_order_relaxed)
                                    && aiopquic_defer_reset(ctx, cnx, sc,
                                        entry->stream_id, entry->error_code,
                                        reliable, 0, 0) == 0) {
                                (void)picoquic_mark_active_stream(
                                    cnx, entry->stream_id, 1, sc);
                            } else {
                                int rr = aiopquic_reset_stream_reliable(cnx,
                                    entry->stream_id, entry->error_code,
                                    reliable);
                                aiopquic_stream_ctx_tx_abandon(
                                    aiopquic_stream_reattach(ctx, cnx, entry, rr));
                            }
                        } else {
                            ctx->cnt_tx_wrong_direction_dropped++;
                        }
                        aiopquic_tx_event_release(entry);
                        ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                        aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                        break;
                    }
                    case SPSC_EVT_TX_STOP_SENDING: {
                        if (aiopquic_stream_can_receive(cnx, entry->stream_id)) {
                            int rr = picoquic_stop_sending(cnx, entry->stream_id,
                                                           entry->error_code);
                            (void)aiopquic_stream_reattach(ctx, cnx, entry, rr);
                        } else {
                            ctx->cnt_tx_wrong_direction_dropped++;
                        }
                        aiopquic_tx_event_release(entry);
                        ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                        aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                        break;
                    }
                    case SPSC_EVT_TX_OPEN_FLOW_CONTROL: {
                        /* Asyncio thread asks us to advance peer's
                         * MAX_STREAM_DATA. entry->stream_ctx carries a
                         * borrowed pointer to the per-stream wrapper
                         * (aiopquic_stream_ctx_t*); we compute the
                         * effective grant HERE rather than relying on
                         * a value Python snapshotted at push time.
                         *
                         * Effective grant accounts for BOTH sc->rx
                         * ring fullness AND bytes that drain_rx has
                         * dispatched to Python (StreamChunks) but the
                         * consumer hasn't released yet (sc->bytes_pending_release).
                         * Over-granting ignores the Python pipeline
                         * backlog and lets peer flood beyond what the
                         * end-to-end consumer can absorb. The min/sub
                         * here is the application-aware backpressure
                         * point: peer's window grows only as Python
                         * actually releases chunks.
                         *
                         * effective_free = max(0, sc->rx_buf_free
                         *                          - bytes_pending_release)
                         *
                         * StreamChunk.__dealloc__ pushes a fresh event
                         * here on every chunk release, so when peer
                         * stalls on FC, the next release reopens
                         * credit — no asyncio polling required. */
                        ctx->cnt_fc_credit_handled++;
                        aiopquic_stream_ctx_t* sc =
                            (aiopquic_stream_ctx_t*)entry->stream_ctx;
                        /* No credit once FIN arrived (RFC 9000 §3.3). */
                        if (sc != NULL && sc->rx != NULL &&
                                !aiopquic_stream_buf_fin_pending(sc->rx)) {
                            uint32_t buf_free =
                                aiopquic_stream_buf_free(sc->rx);
                            uint32_t grant;
                            if (aiopquic_fc_raw_enabled()) {
                                grant = buf_free;
                            } else {
                                uint64_t pending =
                                    aiopquic_stream_ctx_pending_load(sc);
                                grant = (pending >= buf_free)
                                    ? 0
                                    : (uint32_t)(buf_free - pending);
                            }
                            if (grant > 0) {
                                (void)picoquic_open_flow_control(
                                    cnx, entry->stream_id, grant);
                            }
                        }
                        /* Drop the ref aiopquic_push_fc_credit took
                         * on our behalf. sc may be freed here if this
                         * was the last reference (chunks all dealloc'd
                         * AND stream FIN'd AND no other pending fc
                         * events). Safe — we accessed sc above; this
                         * is the very last touch. */
                        if (sc != NULL) {
                            ctx->cnt_sc_destroy_fc_credit_worker++;
                            aiopquic_stream_ctx_destroy(sc);
                        }
                        ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                        aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                        break;
                    }
                    case SPSC_EVT_TX_SET_APP_FLOW_CONTROL: {
                        (void)picoquic_set_app_flow_control(
                            cnx, entry->stream_id, (int)entry->is_fin);
                        ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                        aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                        break;
                    }
                    default:
                        /* Unknown for raw-QUIC; route to WT dispatch
                         * which handles WT-specific TX commands. */
                        (void)aiopquic_wt_handle_tx(quic, ctx, entry);
                        ctx->cnt_tx_event_ring_pops++; spsc_ring_pop(ctx->tx_event_ring);
                        aiopquic_maybe_fire_tx_event_ring_drained(ctx);
                        break;
                }
            }
            aiopquic_tx_event_ring_drained_final(ctx);
            break;

        case picoquic_packet_loop_after_send:
            if (ctx->deferred_resets) {
                aiopquic_run_deferred_resets(quic, ctx);
            }
            break;

        default:
            break;
    }

    return 0;
}

#ifdef __cplusplus
}
#endif

#endif /* AIOPQUIC_CALLBACK_H */
