/*
 * stream_ctx.h — per-stream wrapper holding both TX and RX byte rings.
 *
 * picoquic gives applications a single stream_ctx slot per stream
 * (settable via picoquic_set_app_stream_ctx() or as v_stream_ctx in
 * picoquic_mark_active_stream()). For bidirectional streams we need both
 * TX and RX rings, so the slot points at this wrapper rather than at a
 * raw aiopquic_stream_buf_t. Each direction's ring is allocated lazily —
 * unidirectional streams only ever populate one side.
 *
 * Lifecycle:
 *   - First contact (RX path's first stream_data callback OR TX path's
 *     send_stream_data): aiopquic_stream_ctx_get_or_create binds a fresh
 *     wrapper to the stream slot.
 *   - aiopquic_stream_ctx_ensure_tx / _ensure_rx allocate the side ring
 *     on demand (idempotent).
 *   - On stream_reset / stop_sending: mark pending_destroy; the TX ring
 *     can be freed immediately (sender abandoned), RX waits for Python
 *     to drain.
 *   - On stream_fin: same; mark pending_destroy and let drain complete.
 *   - aiopquic_stream_ctx_destroy frees both rings + wrapper.
 *
 * All ring access remains single-producer/single-consumer per direction:
 *   TX: Python pushes, picoquic worker pops in prepare_to_send.
 *   RX: picoquic worker pushes in stream_data callback, Python pops.
 * Memory ordering is handled inside aiopquic_stream_buf_t.
 */
#pragma once

#include "stream_buf.h"
#include <stdatomic.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

/* Inline helper for ns-resolution monotonic timestamps. CLOCK_MONOTONIC
 * is a single time-base across worker thread and asyncio thread on
 * Linux/macOS, making counter-event ordering directly comparable.
 * Defined here (rather than in callback.h) because stream_ctx.h is
 * included by callback.h — putting it here keeps the timestamp helper
 * usable from both header trees. */
static inline uint64_t aiopquic_now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
}

typedef struct {
    aiopquic_stream_buf_t* tx;
    aiopquic_stream_buf_t* rx;
    /* Cumulative bytes Python has drained from the RX ring. Atomic
     * because the picoquic worker thread reads it from inside the
     * stream_data callback to decide when to extend MAX_STREAM_DATA,
     * while Python writes it after each drain_rx pop. Acquire/release
     * ordering ensures the worker sees Python's drain progress. */
    _Atomic(uint64_t) rx_consumed;
    /* Bytes that drain_rx has popped from sc->rx and wrapped into a
     * StreamChunk for delivery to the Python consumer, but whose
     * StreamChunk has NOT yet been released (last memoryview ref
     * dropped → __dealloc__ fired).
     *
     * Incremented by StreamChunk._wrap (asyncio thread); decremented
     * by StreamChunk.__dealloc__ (asyncio thread). Read by the picoquic
     * worker inside the SPSC_EVT_TX_OPEN_FLOW_CONTROL handler to
     * compute the effective MAX_STREAM_DATA grant:
     *   effective_free = max(0, sc->rx_buf_free - bytes_pending_release)
     * Acquire/release ordering ensures the worker sees Python's
     * release progress.
     *
     * Conflates two populations the application may produce:
     *   (1) bytes in the dispatch pipeline (parser still chewing)
     *   (2) bytes the app intentionally retained beyond delivery
     *       (archiving, deferred processing)
     * aiopquic cannot distinguish without an explicit release API
     * (deferred); both manifest as live-StreamChunk bytes and both
     * propagate as peer-side backpressure — which is correct: peer
     * flow naturally matches actual end-to-end consumption rate. */
    _Atomic(uint64_t) bytes_pending_release;
    /* Last MAX_STREAM_DATA limit advertised by the worker — kept here
     * (not in Python) so the worker-side hysteresis check needs no
     * additional state. Written only by the picoquic worker. */
    _Atomic(uint64_t) rx_credit_limit;
    /* Hysteresis gate for asyncio-side fc_credit push: peer's
     * consumed_offset (sc->rx_consumed) the last time we actually
     * pushed an SPSC_EVT_TX_OPEN_FLOW_CONTROL. Skip subsequent
     * pushes until consumed advances by at least ring_cap >> 4
     * (see _push_fc_credit in _transport.pyx). Asyncio thread
     * reads + writes; relaxed semantics OK because a missed push
     * just defers credit by one event — the next event will
     * catch up. */
    _Atomic(uint64_t) last_fc_push_consumed;
    /* Edge-triggered TX backpressure signal. Python sets this to 1
     * when a send_data attempt returns 0 (sc->tx full). The picoquic
     * worker thread CAS-clears it from 1->0 after popping bytes in
     * prepare_to_send; the CAS winner emits one SPSC event so the
     * blocked Python writer wakes and retries. Only one event fires
     * per fill->drain cycle. */
    _Atomic(uint32_t) tx_drain_pending;
    /* 1 while picoquic holds the stream active or a MARK_ACTIVE for it is
     * queued. Python posts MARK_ACTIVE only on its 0->1 edge; the worker
     * clears it when it parks the stream. */
    _Atomic(uint32_t) tx_armed;
    /* RX data-event coalescing: 1 while a STREAM_DATA notification for
     * this stream is outstanding on the rx_event_ring. The worker
     * CAS-arms 0->1 before pushing; losers skip the push (the
     * in-flight notification's drain pops ALL available sc->rx bytes,
     * including theirs). drain_rx clears BEFORE popping so an
     * arrival racing the pop re-arms a fresh notification. Bounds
     * data-event ring occupancy at one per live stream — ring
     * overflow (which silently DROPS notifications and strands bytes
     * in sc->rx) becomes structurally impossible for the dominant
     * event type. FIN/RESET events are never coalesced. */
    _Atomic(uint32_t) rx_event_pending;
    /* fin/reset arrived; free wrapper after final drain. */
    uint8_t  pending_destroy;
    /* RESET_STREAM_AT waiting for its reliable bytes (worker only):
     * sends stop at tx_reliable_size, then the reset goes out. */
    uint8_t  tx_reset_pending;
    uint64_t tx_reliable_size;
    /* Observability counters (single-writer; relaxed semantics).
     * Aligned with the connection-global ring_event counters in
     * aiopquic_ctx_t so the SIGUSR2 dump can correlate per-stream
     * sc->tx drain activity with cnx-wide ring activity at the same
     * monotonic timestamp. */
    uint64_t cnt_drain_arms;        /* Python armed sc->tx_drain_pending */
    uint64_t cnt_drain_fires;       /* worker fired SPSC_EVT_STREAM_TX_DRAINED */
    uint64_t cnt_drain_dropped;     /* CAS won but rx_event_ring push failed → re-arm */
    uint64_t last_drain_arm_ns;     /* CLOCK_MONOTONIC of last arm */
    uint64_t last_drain_fire_ns;    /* CLOCK_MONOTONIC of last fire */
    /* Reference count for lifecycle management. Starts at 1 (the
     * "stream lifetime" ref, dropped via SPSC_EVT_STREAM_DESTROY or
     * explicit teardown). Each live StreamChunk holds +1 (so a
     * chunk outliving the stream FIN keeps sc alive for __dealloc__
     * to safely touch sc->bytes_pending_release). Each pending
     * SPSC_EVT_TX_OPEN_FLOW_CONTROL event in flight holds +1 (so
     * the worker's handler can safely deref sc even if all chunks
     * dealloc'd after the push).
     *
     * aiopquic_stream_ctx_destroy (the public free entry point) is
     * the unref operation: decrements refcount and frees only when
     * the count hits zero. All call sites can use destroy() with
     * "drop my reference" semantics. */
    _Atomic(uint32_t) refcount;
} aiopquic_stream_ctx_t;

/* Global lifecycle counters (process-wide). Used by dump_counters() to
 * detect sc leaks: cnt_sc_created - cnt_sc_destroyed = live sc count.
 * Single-writer-per-cell is NOT true here (multi-cnx), so atomic.
 * Single-TU build (_transport.c) lets us define storage directly. */
static _Atomic(uint64_t) aiopquic_cnt_sc_created = 0;
static _Atomic(uint64_t) aiopquic_cnt_sc_destroyed = 0;
static _Atomic(int64_t)  aiopquic_cnt_chunks_alive = 0;

static inline void aiopquic_chunks_alive_inc(void) {
    atomic_fetch_add_explicit(&aiopquic_cnt_chunks_alive, 1,
                               memory_order_relaxed);
}
/* Aggregate TX data-ring byte flow (process-wide). pushed is
 * incremented by the Cython push sites (asyncio thread) on every
 * successful sc->tx commit; pulled by the worker prepare/provide
 * drain paths (single writer per transport worker thread);
 * discarded by stream_ctx final-free when an sc->tx ring still
 * holds bytes (reset/abandon — those bytes will never be pulled).
 * Live queued bytes across all streams and transports:
 *   queued = pushed - pulled - discarded
 * This is the O(1) primitive behind the aiopquic aggregate TX gate
 * (QuicConfiguration.tx_max_queued_bytes). Per-stream caps are
 * structurally bypassed by short-stream churn — each fresh stream
 * resets the per-stream budget — so saturation hardening needs an
 * aggregate measure that survives stream rollover. */
static _Atomic(uint64_t) aiopquic_cnt_tx_data_bytes_pushed = 0;
static _Atomic(uint64_t) aiopquic_cnt_tx_data_bytes_pulled = 0;
static _Atomic(uint64_t) aiopquic_cnt_tx_data_bytes_discarded = 0;

static inline void aiopquic_tx_data_bytes_pushed_add(uint64_t n) {
    atomic_fetch_add_explicit(&aiopquic_cnt_tx_data_bytes_pushed, n,
                               memory_order_relaxed);
}
static inline void aiopquic_tx_data_bytes_pulled_add(uint64_t n) {
    atomic_fetch_add_explicit(&aiopquic_cnt_tx_data_bytes_pulled, n,
                               memory_order_relaxed);
}
static inline uint64_t aiopquic_tx_data_bytes_pushed_load(void) {
    return atomic_load_explicit(&aiopquic_cnt_tx_data_bytes_pushed,
                                 memory_order_relaxed);
}
static inline uint64_t aiopquic_tx_data_bytes_pulled_load(void) {
    return atomic_load_explicit(&aiopquic_cnt_tx_data_bytes_pulled,
                                 memory_order_relaxed);
}
static inline uint64_t aiopquic_tx_data_bytes_discarded_load(void) {
    return atomic_load_explicit(&aiopquic_cnt_tx_data_bytes_discarded,
                                 memory_order_relaxed);
}
static inline uint64_t aiopquic_tx_data_bytes_queued(void) {
    uint64_t consumed = aiopquic_tx_data_bytes_pulled_load()
                      + aiopquic_tx_data_bytes_discarded_load();
    uint64_t pushed = aiopquic_tx_data_bytes_pushed_load();
    return (pushed > consumed) ? (pushed - consumed) : 0;
}

static inline void aiopquic_chunks_alive_dec(void) {
    atomic_fetch_sub_explicit(&aiopquic_cnt_chunks_alive, 1,
                               memory_order_relaxed);
}
static inline uint64_t aiopquic_cnt_sc_created_load(void) {
    return atomic_load_explicit(&aiopquic_cnt_sc_created,
                                 memory_order_relaxed);
}
static inline uint64_t aiopquic_cnt_sc_destroyed_load(void) {
    return atomic_load_explicit(&aiopquic_cnt_sc_destroyed,
                                 memory_order_relaxed);
}
static inline int64_t aiopquic_cnt_chunks_alive_load(void) {
    return atomic_load_explicit(&aiopquic_cnt_chunks_alive,
                                 memory_order_relaxed);
}

/* Per-site sc create/ref/destroy counters for Python-side call sites
 * (added 2026-06-06). C-side counters live on aiopquic_ctx_t (per cnx).
 * Process-wide here because chunk dealloc, rx_event drain, and the
 * Python create/destroy helpers don't reliably have ctx in scope.
 * Invariant at process end:
 *   sc_created == sc_destroyed
 *   (cnt_sc_create_raw_quic + cnt_sc_create_wt_link + cnt_sc_create_python_helper
 *    + cnt_sc_ref_fc_credit + cnt_sc_ref_chunk_wrap)
 *   == (cnt_sc_destroy_wt_link + cnt_sc_destroy_fc_credit_pushfail
 *       + cnt_sc_destroy_fc_credit_worker + cnt_sc_destroy_fc_credit_dead_cnx
 *       + cnt_sc_destroy_chunk_dealloc + cnt_sc_destroy_rx_event
 *       + cnt_sc_destroy_python_helper) */
static _Atomic(uint64_t) aiopquic_cnt_sc_ref_chunk_wrap = 0;
static _Atomic(uint64_t) aiopquic_cnt_sc_destroy_chunk_dealloc = 0;
static _Atomic(uint64_t) aiopquic_cnt_sc_destroy_rx_event = 0;
static _Atomic(uint64_t) aiopquic_cnt_sc_create_python_helper = 0;
static _Atomic(uint64_t) aiopquic_cnt_sc_destroy_python_helper = 0;

static inline void aiopquic_cnt_sc_ref_chunk_wrap_inc(void) {
    atomic_fetch_add_explicit(&aiopquic_cnt_sc_ref_chunk_wrap, 1,
                               memory_order_relaxed);
}
static inline void aiopquic_cnt_sc_destroy_chunk_dealloc_inc(void) {
    atomic_fetch_add_explicit(&aiopquic_cnt_sc_destroy_chunk_dealloc, 1,
                               memory_order_relaxed);
}
static inline void aiopquic_cnt_sc_destroy_rx_event_inc(void) {
    atomic_fetch_add_explicit(&aiopquic_cnt_sc_destroy_rx_event, 1,
                               memory_order_relaxed);
}
static inline void aiopquic_cnt_sc_create_python_helper_inc(void) {
    atomic_fetch_add_explicit(&aiopquic_cnt_sc_create_python_helper, 1,
                               memory_order_relaxed);
}
static inline void aiopquic_cnt_sc_destroy_python_helper_inc(void) {
    atomic_fetch_add_explicit(&aiopquic_cnt_sc_destroy_python_helper, 1,
                               memory_order_relaxed);
}
static inline uint64_t aiopquic_cnt_sc_ref_chunk_wrap_load(void) {
    return atomic_load_explicit(&aiopquic_cnt_sc_ref_chunk_wrap,
                                 memory_order_relaxed);
}
static inline uint64_t aiopquic_cnt_sc_destroy_chunk_dealloc_load(void) {
    return atomic_load_explicit(&aiopquic_cnt_sc_destroy_chunk_dealloc,
                                 memory_order_relaxed);
}
static inline uint64_t aiopquic_cnt_sc_destroy_rx_event_load(void) {
    return atomic_load_explicit(&aiopquic_cnt_sc_destroy_rx_event,
                                 memory_order_relaxed);
}
static inline uint64_t aiopquic_cnt_sc_create_python_helper_load(void) {
    return atomic_load_explicit(&aiopquic_cnt_sc_create_python_helper,
                                 memory_order_relaxed);
}
static inline uint64_t aiopquic_cnt_sc_destroy_python_helper_load(void) {
    return atomic_load_explicit(&aiopquic_cnt_sc_destroy_python_helper,
                                 memory_order_relaxed);
}

/* sc->rx byte-ring in-flight tracker. Worker thread bumps on push;
 * Cython asyncio drain bumps on pop. Delta = bytes currently sitting
 * in sc->rx rings across ALL streams in the process. Reveals when
 * the RX ring layer is accumulating (consumer stalled) vs not. */
static _Atomic(uint64_t) aiopquic_cnt_sc_rx_bytes_pushed = 0;
static _Atomic(uint64_t) aiopquic_cnt_sc_rx_bytes_popped = 0;

static inline void aiopquic_sc_rx_bytes_pushed_add(uint64_t n) {
    atomic_fetch_add_explicit(&aiopquic_cnt_sc_rx_bytes_pushed, n,
                               memory_order_relaxed);
}
static inline void aiopquic_sc_rx_bytes_popped_add(uint64_t n) {
    atomic_fetch_add_explicit(&aiopquic_cnt_sc_rx_bytes_popped, n,
                               memory_order_relaxed);
}
static inline uint64_t aiopquic_cnt_sc_rx_bytes_pushed_load(void) {
    return atomic_load_explicit(&aiopquic_cnt_sc_rx_bytes_pushed,
                                 memory_order_relaxed);
}
static inline uint64_t aiopquic_cnt_sc_rx_bytes_popped_load(void) {
    return atomic_load_explicit(&aiopquic_cnt_sc_rx_bytes_popped,
                                 memory_order_relaxed);
}

static inline aiopquic_stream_ctx_t* aiopquic_stream_ctx_create(void) {
    aiopquic_stream_ctx_t* sc = (aiopquic_stream_ctx_t*)calloc(
        1, sizeof(aiopquic_stream_ctx_t));
    if (sc) {
        /* Initial "stream lifetime" reference. Released by either
         * SPSC_EVT_STREAM_DESTROY (raw QUIC pure receiver), the WT
         * link-release path, or any explicit Python stream_ctx_destroy
         * call. Additional refs come and go via _ref/_destroy as
         * StreamChunks are created and freed. */
        atomic_store_explicit(&sc->refcount, 1, memory_order_relaxed);
        atomic_fetch_add_explicit(&aiopquic_cnt_sc_created, 1,
                                   memory_order_relaxed);
    }
    return sc;
}

/* Take an additional reference. Called when a StreamChunk wraps
 * bytes whose lifetime might exceed the stream's, or when an SPSC
 * event is queued whose handler needs sc to still be alive when
 * it runs. */
static inline void aiopquic_stream_ctx_ref(aiopquic_stream_ctx_t* sc) {
    if (!sc) return;
    atomic_fetch_add_explicit(&sc->refcount, 1, memory_order_acquire);
}

/* Python-side arm for the per-stream sc->tx drain signal. Mirrors
 * the connection-global aiopquic_arm_tx_event_ring_drain_pending in
 * callback.h. Use when the Python writer wants to wait for sc->tx
 * to drain at a soft threshold (e.g. a byte-budget cap below the
 * hard sc->tx ring capacity) rather than waiting for the natural
 * BufferError at full capacity. */
static inline void aiopquic_set_tx_data_drain_pending(
        aiopquic_stream_ctx_t* sc) {
    if (!sc) return;
    sc->cnt_drain_arms++;
    sc->last_drain_arm_ns = aiopquic_now_ns();
    (void)atomic_exchange_explicit(&sc->tx_drain_pending, 1,
                                   memory_order_acq_rel);
}

static inline void aiopquic_clear_tx_data_drain_pending(
        aiopquic_stream_ctx_t* sc) {
    if (!sc) return;
    atomic_store_explicit(&sc->tx_drain_pending, 0,
                          memory_order_release);
}

/* Worker, after pulling from sc->tx: 1 if a writer armed the drain
 * signal and this call took it (the caller emits STREAM_TX_DRAINED).
 * An exchange, so a writer's arm is ordered against the pull. */
static inline int aiopquic_stream_ctx_tx_drain_take(aiopquic_stream_ctx_t* sc) {
    return atomic_exchange_explicit(&sc->tx_drain_pending, 0,
                                    memory_order_acq_rel) == 1;
}

/* Producer, after committing bytes or a FIN: 1 when the stream was parked
 * and needs a MARK_ACTIVE. The fence orders the commit before the load of
 * tx_armed (pairs with aiopquic_stream_ctx_tx_park). */
static inline int aiopquic_stream_ctx_tx_arm(aiopquic_stream_ctx_t* sc) {
    atomic_thread_fence(memory_order_seq_cst);
    return atomic_exchange_explicit(&sc->tx_armed, 1,
                                    memory_order_seq_cst) == 0;
}

/* Producer, when its MARK_ACTIVE did not post: the next commit posts one. */
static inline void aiopquic_stream_ctx_tx_disarm(aiopquic_stream_ctx_t* sc) {
    atomic_store_explicit(&sc->tx_armed, 0, memory_order_seq_cst);
}

static inline int aiopquic_stream_ctx_ensure_tx(aiopquic_stream_ctx_t* sc,
                                                 uint32_t capacity) {
    if (!sc) return -1;
    if (sc->tx) return 0;
    sc->tx = aiopquic_stream_buf_create(capacity);
    return sc->tx ? 0 : -1;
}

static inline int aiopquic_stream_ctx_ensure_rx(aiopquic_stream_ctx_t* sc,
                                                 uint32_t capacity) {
    if (!sc) return -1;
    if (sc->rx) return 0;
    sc->rx = aiopquic_stream_buf_create(capacity);
    return sc->rx ? 0 : -1;
}

/* Drop one reference; free tx/rx rings and the wrapper itself only
 * when this was the LAST reference. Idempotent on NULL. Safe to
 * call from any thread (asyncio drain, picoquic worker, StreamChunk
 * __dealloc__) because the refcount manipulation is atomic and the
 * "is this the final ref" test uses the return value of
 * atomic_fetch_sub. Replacement for the old free-immediately
 * semantics; existing callers transparently get the right behavior
 * (initial-ref-only callers free immediately; multi-ref callers
 * release lazily). */
static inline void aiopquic_stream_ctx_destroy(aiopquic_stream_ctx_t* sc) {
    if (!sc) return;
    uint32_t prev = atomic_fetch_sub_explicit(&sc->refcount, 1,
                                               memory_order_acq_rel);
    if (prev != 1) {
        /* Other refs still outstanding; defer actual free until they
         * each drop in turn. */
        return;
    }
    if (sc->tx) {
        /* Bytes still queued at final free will never be pulled by
         * the worker (reset/abandon/close). Credit them to the
         * discarded sink so aggregate queued accounting can't drift
         * upward across stream teardown. */
        uint32_t remaining = aiopquic_stream_buf_used(sc->tx);
        if (remaining > 0) {
            atomic_fetch_add_explicit(
                &aiopquic_cnt_tx_data_bytes_discarded,
                (uint64_t)remaining, memory_order_relaxed);
        }
        aiopquic_stream_buf_destroy(sc->tx);
    }
    if (sc->rx) aiopquic_stream_buf_destroy(sc->rx);
    free(sc);
    atomic_fetch_add_explicit(&aiopquic_cnt_sc_destroyed, 1,
                               memory_order_relaxed);
}

/* Drop bytes queued in sc->tx that will never be sent (the stream was
 * reset) and credit them as discarded now, so the process-wide queued
 * total does not wait for the final free. Consumer side: worker only,
 * after the stream's send callback is detached. Later pushes are
 * credited by aiopquic_stream_ctx_destroy. */
static inline void aiopquic_stream_ctx_tx_abandon(aiopquic_stream_ctx_t* sc) {
    if (!sc || !sc->tx) return;
    uint64_t tail = atomic_load_explicit(&sc->tx->tail, memory_order_acquire);
    uint64_t head = atomic_load_explicit(&sc->tx->head, memory_order_relaxed);
    if (tail > head) {
        atomic_fetch_add_explicit(&aiopquic_cnt_tx_data_bytes_discarded,
                                  tail - head, memory_order_relaxed);
        atomic_store_explicit(&sc->tx->head, tail, memory_order_release);
    }
}

/* Bytes of sc->tx the worker may hand to picoquic: avail, or only those
 * below a pending reset's reliable size. Worker only. */
static inline uint32_t aiopquic_stream_ctx_tx_sendable(
        const aiopquic_stream_ctx_t* sc, uint32_t avail) {
    if (!sc->tx_reset_pending) return avail;
    uint64_t head = atomic_load_explicit(&sc->tx->head, memory_order_relaxed);
    uint64_t left = sc->tx_reliable_size > head ? sc->tx_reliable_size - head : 0;
    return left < avail ? (uint32_t)left : avail;
}

/* Worker, about to park the stream after offering to_send bytes: clears
 * tx_armed, then 1 when bytes or a FIN the offer missed have arrived and
 * the stream must stay active. A commit after the clear sees 0 and posts
 * a MARK_ACTIVE instead. */
static inline int aiopquic_stream_ctx_tx_park(aiopquic_stream_ctx_t* sc,
                                              uint32_t to_send, int fin_seen) {
    atomic_store_explicit(&sc->tx_armed, 0, memory_order_seq_cst);
    atomic_thread_fence(memory_order_seq_cst);
    int fin_now = aiopquic_stream_buf_fin_pending(sc->tx);
    uint32_t avail = aiopquic_stream_buf_used(sc->tx);
    if (aiopquic_stream_ctx_tx_sendable(sc, avail) > to_send
            || (fin_now && !fin_seen && !sc->tx_reset_pending)) {
        atomic_store_explicit(&sc->tx_armed, 1, memory_order_relaxed);
        return 1;
    }
    return 0;
}

/* Atomic accessors for cross-thread fields. Cython sees plain uint64_t
 * (no _Atomic in the .pyx cdef extern); call these from both Python and
 * C sides for proper memory ordering. */
static inline uint64_t aiopquic_stream_ctx_rx_consumed_load(
        aiopquic_stream_ctx_t* sc) {
    return atomic_load_explicit(&sc->rx_consumed, memory_order_acquire);
}

static inline void aiopquic_stream_ctx_rx_consumed_add(
        aiopquic_stream_ctx_t* sc, uint64_t delta) {
    atomic_fetch_add_explicit(&sc->rx_consumed, delta, memory_order_release);
}

static inline uint64_t aiopquic_stream_ctx_rx_credit_load(
        aiopquic_stream_ctx_t* sc) {
    return atomic_load_explicit(&sc->rx_credit_limit, memory_order_acquire);
}

static inline void aiopquic_stream_ctx_rx_credit_store(
        aiopquic_stream_ctx_t* sc, uint64_t value) {
    atomic_store_explicit(&sc->rx_credit_limit, value, memory_order_release);
}

/* Per-stream "bytes pending release" accessors. Producer is
 * StreamChunk._wrap (asyncio thread); consumer is StreamChunk.__dealloc__
 * (same thread). Worker thread reads via load() during FC handler. */
static inline void aiopquic_stream_ctx_pending_add(
        aiopquic_stream_ctx_t* sc, uint64_t n) {
    if (!sc || n == 0) return;
    atomic_fetch_add_explicit(&sc->bytes_pending_release, n,
                              memory_order_release);
}

static inline void aiopquic_stream_ctx_pending_sub(
        aiopquic_stream_ctx_t* sc, uint64_t n) {
    if (!sc || n == 0) return;
    atomic_fetch_sub_explicit(&sc->bytes_pending_release, n,
                              memory_order_release);
}

static inline uint64_t aiopquic_stream_ctx_pending_load(
        aiopquic_stream_ctx_t* sc) {
    if (!sc) return 0;
    return atomic_load_explicit(&sc->bytes_pending_release,
                                memory_order_acquire);
}

/* last_fc_push_consumed accessors. Hysteresis state for the
 * asyncio-side _push_fc_credit gate in _transport.pyx. */
static inline uint64_t aiopquic_stream_ctx_last_fc_push_consumed_load(
        aiopquic_stream_ctx_t* sc) {
    if (!sc) return 0;
    return atomic_load_explicit(&sc->last_fc_push_consumed,
                                memory_order_relaxed);
}

static inline void aiopquic_stream_ctx_last_fc_push_consumed_store(
        aiopquic_stream_ctx_t* sc, uint64_t v) {
    if (!sc) return;
    atomic_store_explicit(&sc->last_fc_push_consumed, v,
                          memory_order_relaxed);
}

/* rx_event_pending arm/clear. Arm returns 1 iff this caller set it and
 * must push the notification event; 0 means one is already in flight.
 * The drain side clears BEFORE it pops sc->rx, so an arrival after the
 * clear re-arms (worst case one empty notification). Both are exchanges:
 * with a store or a failed CAS, each side's ring access could pass its
 * flag access and the bytes would sit unnotified. */
static inline int aiopquic_stream_ctx_rx_event_pending_arm(
        aiopquic_stream_ctx_t* sc) {
    return atomic_exchange_explicit(&sc->rx_event_pending, 1,
                                    memory_order_acq_rel) == 0;
}

static inline void aiopquic_stream_ctx_rx_event_pending_clear(
        aiopquic_stream_ctx_t* sc) {
    (void)atomic_exchange_explicit(&sc->rx_event_pending, 0,
                                   memory_order_acq_rel);
}

/* Combined send-data fast path. Atomic from Python's perspective:
 * lazy-allocates the TX ring on first call, atomically pushes `data`
 * (all-or-nothing — never commits a partial accept), optionally sets
 * FIN. Pull model unchanged: bytes go into the SPSC TX ring; picoquic
 * still pulls at wire rate via prepare_to_send.
 *
 * Returns:
 *    1  pushed all `len` bytes (and set FIN if requested);
 *    0  no bytes pushed because ring full (caller must retry);
 *   -1  allocation / NULL-arg failure (caller raises).
 *
 * The all-or-nothing guarantee is the reason this exists as one C
 * call rather than the Python-level ensure/free/push triple: with
 * Python control between free-check and push, a writer thread cannot
 * race the underlying ring (single-producer model already guarantees
 * that), but ALSO the partial-accept window of stream_buf_push gets
 * eliminated — `len > free_bytes` is detected and rejected before
 * any tail advance happens, so a caller catching "not all pushed"
 * can safely retry the entire `data` buffer.
 */
static inline int aiopquic_stream_ctx_send_data(
        aiopquic_stream_ctx_t* sc,
        const uint8_t* data, uint32_t len,
        uint32_t capacity, uint8_t set_fin) {
    if (!sc) return -1;
    if (!sc->tx) {
        sc->tx = aiopquic_stream_buf_create(capacity);
        if (!sc->tx) return -1;
    }
    if (len > sc->tx->capacity) return -2;  /* can never fit */
    if (len > 0) {
        /* All-or-nothing: pre-check free_bytes against full request,
         * then call push only when the whole request fits. push is
         * single-producer so there is no concurrent writer to consume
         * the room between the check and the push. */
        uint64_t tail = atomic_load_explicit(&sc->tx->tail,
                                             memory_order_relaxed);
        uint64_t head = atomic_load_explicit(&sc->tx->head,
                                             memory_order_acquire);
        uint32_t free_bytes = sc->tx->capacity - (uint32_t)(tail - head);
        if (free_bytes < len) {
            /* Arm the edge-trigger so the worker emits one
             * SPSC_EVT_STREAM_TX_DRAINED when it next drains bytes
             * from sc->tx, then re-check: a drain that finished before
             * the arm took nothing and may not run again. */
            sc->cnt_drain_arms++;
            sc->last_drain_arm_ns = aiopquic_now_ns();
            (void)atomic_exchange_explicit(&sc->tx_drain_pending, 1,
                                           memory_order_acq_rel);
            head = atomic_load_explicit(&sc->tx->head, memory_order_acquire);
            free_bytes = sc->tx->capacity - (uint32_t)(tail - head);
            if (free_bytes < len) return 0;
            /* Room after all: push. The arm stays (another waiter may
             * own it); the worst case is one spurious wake. */
        }
        uint32_t accepted = aiopquic_stream_buf_push(sc->tx, data, len);
        if (accepted != len) return 0;  /* defensive; shouldn't happen */
    }
    if (set_fin) {
        aiopquic_stream_buf_set_fin(sc->tx);
    }
    return 1;
}
