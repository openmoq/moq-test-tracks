/*
 * h3wt_callback.h — H3/WebTransport adapter callbacks.
 *
 * Bridges picoquic's per-stream picohttp_call_back_event_t events
 * (delivered by the h3zero/picowt machinery) into the aiopquic SPSC
 * ring as SPSC_EVT_WT_* events for the asyncio thread to consume.
 *
 * One aiopquic_wt_session_t per WT session. Per-data-stream state
 * (aiopquic_stream_ctx_t + back-pointer to session) lives in
 * aiopquic_wt_stream_link_t, attached directly to h3zero's
 * stream_ctx->path_callback_ctx. Dispatch is O(0): the callback's
 * path_app_ctx IS the link (data streams) or the session (control
 * stream / session-level events) — no side-table lookup.
 *
 * path_callback_ctx is polymorphic between sessions and links.
 * A uint32_t kind tag at offset 0 of both structs discriminates and
 * doubles as a heap-corruption canary: freed-then-reused memory
 * won't read back AIOPQUIC_WT_CTX_SESSION or AIOPQUIC_WT_CTX_LINK,
 * so a wild path_app_ctx fails fast in dispatch rather than UB-ing
 * through the wrong type interpretation.
 *
 * Copyright (c) 2026, aiopquic contributors. BSD-3-Clause license.
 */

#ifndef AIOPQUIC_H3WT_CALLBACK_H
#define AIOPQUIC_H3WT_CALLBACK_H

#include "callback.h"
#include "spsc_ring.h"

#include <picoquic.h>
#include <picoquic_unified_log.h>
#include <h3zero_common.h>
#include <pico_webtransport.h>

#include <inttypes.h>
#include <string.h>
#include <stdlib.h>

/* A client that closed its session waits this long for the peer's CONNECT
 * FIN before closing the connection anyway, and this long after both FINs
 * are in so the queued stream resets leave before the CONNECTION_CLOSE:
 * a disconnecting picoquic cnx sends nothing else. */
#define AIOPQUIC_WT_CLOSE_DEADLINE_US 1000000
#define AIOPQUIC_WT_CLOSE_GRACE_US 20000

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Discriminator tag for path_callback_ctx polymorphism. The tag also
 * acts as a heap canary — cleared to 0 on destroy so use-after-free
 * fails the dispatch check rather than re-interpreting bytes.
 */
typedef enum {
    AIOPQUIC_WT_CTX_SESSION = 0x57545301u,  /* 'WTS\1' */
    AIOPQUIC_WT_CTX_LINK    = 0x57544c01u,  /* 'WTL\1' */
} aiopquic_wt_ctx_kind_t;

/* WT_SESSION_GONE (draft-ietf-webtrans-http3 §6, IANA 0x170d7b68). The code
 * a peer needs to tell session teardown from an ordinary stream reset. */
#define AIOPQUIC_WT_SESSION_GONE 0x170d7b68u

/* WT_APPLICATION_ERROR (draft-ietf-webtrans-http3 §4.4): a 32-bit stream
 * application code travels as an HTTP/3 code in this range, skipping the
 * reserved 0x1f * N + 0x21 codepoints. Codes above 32 bits are HTTP/3 codes
 * already (WT_SESSION_GONE) and pass through both ways. */
#define AIOPQUIC_WT_APP_ERROR_FIRST 0x52e4a40fa8dbull
#define AIOPQUIC_WT_APP_ERROR_LAST  0x52e5ac983162ull

static inline uint64_t aiopquic_wt_code_to_h3(uint64_t code) {
    if (code > 0xffffffffull) return code;
    return AIOPQUIC_WT_APP_ERROR_FIRST + code + code / 0x1e;
}

/* A code outside the range, or a reserved codepoint in it, carries no
 * application code and is delivered as received. */
static inline uint64_t aiopquic_wt_code_from_h3(uint64_t h) {
    if (h < AIOPQUIC_WT_APP_ERROR_FIRST || h > AIOPQUIC_WT_APP_ERROR_LAST
            || (h - 0x21) % 0x1f == 0) {
        return h;
    }
    uint64_t shifted = h - AIOPQUIC_WT_APP_ERROR_FIRST;
    return shifted - shifted / 0x1f;
}

/*
 * Packed payload for SPSC_EVT_TX_WT_OPEN. Stored as data_buf:
 *   header + sni + path + protocols.
 *
 * ALPN is always "h3" for WT, not carried.
 *
 * protocols is an OPTIONAL comma-separated list of subprotocol
 * identifiers to advertise in the WT-Available-Protocols header
 * (per WebTransport HTTP/3 spec §3.3). aiopquic treats it as an
 * opaque string — no interpretation; passed verbatim to
 * picowt_connect. Empty (protocols_len == 0) sends no header.
 *
 * connect_protocol picks the CONNECT's :protocol, AIOPQUIC_WT_CONNECT_*.
 */
#define AIOPQUIC_WT_CONNECT_AUTO   0  /* "webtransport", one "webtransport-h3" retry */
#define AIOPQUIC_WT_CONNECT_LEGACY 1  /* "webtransport" only */
#define AIOPQUIC_WT_CONNECT_H3     2  /* "webtransport-h3" only */

typedef struct {
    struct sockaddr_storage addr;
    uint16_t sni_len;
    uint16_t path_len;
    uint16_t protocols_len;
    uint8_t connect_protocol;
    /* followed by: sni_len bytes of SNI, then path_len bytes of path,
     * then protocols_len bytes of protocols. */
} aiopquic_wt_open_params_t;

/* Forward decls — link references session and vice versa via the
 * callback chain. */
struct st_aiopquic_wt_session_t;
typedef struct st_aiopquic_wt_session_t aiopquic_wt_session_t;

/*
 * Per-WT-stream link. Attached to h3zero's stream_ctx->path_callback_ctx
 * for data streams. The kind tag MUST be first — discriminator + canary.
 * Allocated once at first event for an inbound stream, or at create
 * time for an outbound stream we initiated. Freed by
 * picohttp_callback_free, which h3zero fires after the stream is gone
 * from picoquic's perspective.
 */
typedef struct st_aiopquic_wt_stream_link_t {
    uint32_t                  kind;        /* AIOPQUIC_WT_CTX_LINK */
    aiopquic_wt_session_t*    session;     /* back-pointer for routing */
    aiopquic_stream_ctx_t*    sc;          /* per-stream rx + tx rings */
    uint64_t                  stream_id;
} aiopquic_wt_stream_link_t;

/*
 * Per-WebTransport-session context. Lives for the lifetime of the
 * WT session. Allocated when the asyncio side requests a WT session
 * open (client) or on CONNECT arrival (server); freed on session-closed
 * event after Python releases its reference. kind tag MUST be first.
 */
struct st_aiopquic_wt_session_t {
    uint32_t                      kind;            /* AIOPQUIC_WT_CTX_SESSION */
    aiopquic_ctx_t*               bridge;          /* shared rx/tx rings + eventfd */
    picoquic_cnx_t*               cnx;             /* per-session QUIC cnx */
    h3zero_callback_ctx_t*        h3_ctx;          /* picoquic-owned H3 ctx */
    h3zero_stream_ctx_t*          control_stream;  /* picoquic-owned control stream ctx */
    uint64_t                      control_stream_id;
    picowt_capsule_t              capsule;         /* incremental capsule accumulator */
    int                           session_ready;   /* CONNECT accepted */
    int                           session_closing; /* close/drain seen or initiated */
    int                           fin_sent;        /* our CONNECT FIN is sent */
    int                           peer_fin;        /* peer FIN or reset on CONNECT seen */
    uint64_t                      close_deadline;  /* quic time to close the cnx, 0 = none */
    int                           cleanup_done;    /* the session's stream resets are queued */
    char*                         wt_protocol;     /* negotiated WT subprotocol (owned copy), NULL if none */
    /* AIOPQUIC_WT_CONNECT_AUTO: the CONNECT arguments, kept for its one
     * "webtransport-h3" retry. connect_authority == NULL: no retry left. */
    char*                         connect_authority;
    char*                         connect_path;
    char*                         connect_protocols;
    /* Pull-model datagram TX for this session. The producer commits
     * records from Python; h3zero pulls them in provide_datagram and
     * frames each as an HTTP datagram on the session's control stream
     * (RFC 9297 quarter-stream-id prefix is h3zero's business). */
    aiopquic_dgram_buf_t*         dgram_ring;
};

/*
 * Diagnostic helper — formats the cnx's logging CID as hex into a
 * static buffer (caller-private; not thread-safe for concurrent use).
 * Gated by AIOPQUIC_WT_DIAG to keep production output clean.
 */
static inline int aiopquic_wt_diag_enabled(void) {
    static int cached = -1;
    if (cached < 0) {
        const char* v = getenv("AIOPQUIC_WT_DIAG");
        cached = (v != NULL && v[0] != '\0' && v[0] != '0');
    }
    return cached;
}

/* AIOPQUIC_WT_DEBUG: per-packet TX hex dump. Read once — provide_data
 * runs per packet on the worker, where getenv() would also race a
 * setenv() from Python. */
static inline int aiopquic_wt_debug_enabled(void) {
    static int cached = -1;
    if (cached < 0) {
        cached = getenv("AIOPQUIC_WT_DEBUG") != NULL;
    }
    return cached;
}

static inline void aiopquic_wt_log_cnxid(const char* tag,
                                          picoquic_cnx_t* cnx,
                                          uint64_t sid) {
    if (!aiopquic_wt_diag_enabled() || cnx == NULL) return;
    picoquic_connection_id_t cid = picoquic_get_logging_cnxid(cnx);
    fprintf(stderr, "[wt-diag] %s cid=", tag);
    for (uint8_t i = 0; i < cid.id_len; i++) {
        fprintf(stderr, "%02x", cid.id[i]);
    }
    if (sid != UINT64_MAX) {
        fprintf(stderr, " sid=%llu", (unsigned long long)sid);
    }
    fprintf(stderr, "\n");
    fflush(stderr);
}

/* Copy a NUL-terminated string into a freshly malloc'd buffer
 * (self-contained; avoids depending on POSIX strdup feature macros).
 * Used to capture the negotiated WT subprotocol off picoquic-owned
 * memory so the session owns a copy independent of stream lifetime. */
static inline char* aiopquic_wt_strdup(const char* src) {
    if (src == NULL) return NULL;
    size_t n = strlen(src);
    char* d = (char*)malloc(n + 1);
    if (d != NULL) memcpy(d, src, n + 1);
    return d;
}

/* Status refusing a CONNECT whose WT-Available-Protocols has no match. */
#define AIOPQUIC_WT_NO_PROTOCOL_STATUS 400

#define AIOPQUIC_WT_PROTO_NO_MATCH     (-1)
#define AIOPQUIC_WT_PROTO_NONE_OFFERED 0
#define AIOPQUIC_WT_PROTO_SELECTED     1

/* Next item of a comma-separated list in [p, end): whitespace, one pair
 * of quotes and ";parameters" stripped. Returns the position after the
 * item, NULL when none is left. */
static const char* aiopquic_wt_list_next(const char* p, const char* end,
                                         const char** item, size_t* len) {
    while (p < end && (*p == ' ' || *p == '\t' || *p == ',')) p++;
    if (p >= end) return NULL;
    const char* start = p;
    while (p < end && *p != ',') p++;
    const char* stop = start;
    while (stop < p && *stop != ';') stop++;
    while (stop > start && (stop[-1] == ' ' || stop[-1] == '\t')) stop--;
    if (stop - start >= 2 && *start == '"' && stop[-1] == '"') {
        start++;
        stop--;
    }
    *item = start;
    *len = (size_t)(stop - start);
    return p;
}

/* Defined in picohttp/webtransport.c; no header declares it. */
int picowt_set_wt_protocol(h3zero_stream_ctx_t* stream_ctx,
                           const char* selected_protocol);

/* Select the WT-Protocol by the client's preference order: the first
 * offered entry that is in `supported` (CSV). Sets stream_state.wt_protocol
 * on a match. */
static int aiopquic_wt_select_protocol(h3zero_stream_ctx_t* st,
                                       const char* supported) {
    const char* offer =
        (const char*)st->ps.stream_state.header.wt_available_protocols;
    if (offer == NULL) return AIOPQUIC_WT_PROTO_NONE_OFFERED;
    const char* offer_end =
        offer + st->ps.stream_state.header.wt_available_protocols_length;
    const char* sup_end = supported + strlen(supported);
    const char *o, *sv;
    size_t olen, slen;
    int offered = 0;

    for (const char* q = offer;
         (q = aiopquic_wt_list_next(q, offer_end, &o, &olen)) != NULL;) {
        if (olen > 0) {
            offered = 1;
            break;
        }
    }
    if (!offered) return AIOPQUIC_WT_PROTO_NONE_OFFERED;

    for (const char* q = offer;
         (q = aiopquic_wt_list_next(q, offer_end, &o, &olen)) != NULL;) {
        if (olen == 0) continue;
        for (const char* p = supported;
             (p = aiopquic_wt_list_next(p, sup_end, &sv, &slen)) != NULL;) {
            if (olen == slen && memcmp(o, sv, slen) == 0) {
                char sel[256];
                if (slen >= sizeof(sel)) break;
                memcpy(sel, sv, slen);
                sel[slen] = 0;
                return picowt_set_wt_protocol(st, sel) == 0
                    ? AIOPQUIC_WT_PROTO_SELECTED : AIOPQUIC_WT_PROTO_NO_MATCH;
            }
        }
    }
    return AIOPQUIC_WT_PROTO_NO_MATCH;
}

static inline aiopquic_wt_session_t* aiopquic_wt_session_create(
        aiopquic_ctx_t* bridge) {
    aiopquic_wt_session_t* s =
        (aiopquic_wt_session_t*)calloc(1, sizeof(*s));
    if (!s) return NULL;
    s->kind = AIOPQUIC_WT_CTX_SESSION;
    s->bridge = bridge;
    return s;
}

static inline void aiopquic_wt_drop_retry(aiopquic_wt_session_t* s) {
    free(s->connect_authority);
    free(s->connect_path);
    free(s->connect_protocols);
    s->connect_authority = NULL;
    s->connect_path = NULL;
    s->connect_protocols = NULL;
}

static inline void aiopquic_wt_session_destroy(aiopquic_wt_session_t* s) {
    if (!s) return;
    if (s->dgram_ring) {
        aiopquic_dgram_buf_unref(s->dgram_ring);
        s->dgram_ring = NULL;
    }
    picowt_release_capsule(&s->capsule);
    free(s->wt_protocol);  /* free(NULL) is a no-op when unnegotiated */
    aiopquic_wt_drop_retry(s);
    s->kind = 0;  /* clear canary so post-free dispatch fails fast */
    free(s);
}

static inline aiopquic_wt_stream_link_t* aiopquic_wt_stream_link_create(
        aiopquic_wt_session_t* s, uint64_t stream_id) {
    aiopquic_wt_stream_link_t* link =
        (aiopquic_wt_stream_link_t*)calloc(1, sizeof(*link));
    if (!link) return NULL;
    aiopquic_stream_ctx_t* sc = aiopquic_stream_ctx_create();
    if (!sc) {
        free(link);
        return NULL;
    }
    if (s && s->bridge) {
        s->bridge->cnt_sc_create_wt_link++;
    }
    link->kind = AIOPQUIC_WT_CTX_LINK;
    link->session = s;
    link->sc = sc;
    link->stream_id = stream_id;
    return link;
}

static inline void aiopquic_wt_stream_link_destroy(
        aiopquic_wt_stream_link_t* link) {
    if (!link) return;
    /* No session/bridge deref here: at cnx-teardown, session is freed
     * (h3wt_callback.h:~1115 / TX_WT_DEREGISTER) BEFORE every pending
     * LINK_RELEASE has been popped from rx_event_ring. Touching
     * link->session in this function = UAF on shutdown. The destroy
     * count is captured at call sites (close walker + drain_rx
     * LINK_RELEASE pop) where session validity is guaranteed. */
    if (link->sc) aiopquic_stream_ctx_destroy(link->sc);
    link->kind = 0;  /* clear canary */
    free(link);
}

/*
 * Resolve path_app_ctx into (session, link). Returns 0 on success,
 * -1 on a corrupted / unknown ctx (wild pointer, freed memory).
 * out_link is NULL for session-level events (CONNECT/control-stream).
 */
static inline int aiopquic_wt_ctx_resolve(
        void* path_app_ctx,
        aiopquic_wt_session_t** out_s,
        aiopquic_wt_stream_link_t** out_link) {
    if (!path_app_ctx) {
        *out_s = NULL;
        *out_link = NULL;
        return -1;
    }
    uint32_t kind = *(uint32_t*)path_app_ctx;
    if (kind == AIOPQUIC_WT_CTX_LINK) {
        aiopquic_wt_stream_link_t* link =
            (aiopquic_wt_stream_link_t*)path_app_ctx;
        *out_link = link;
        *out_s = link->session;
        return 0;
    }
    if (kind == AIOPQUIC_WT_CTX_SESSION) {
        *out_link = NULL;
        *out_s = (aiopquic_wt_session_t*)path_app_ctx;
        return 0;
    }
    *out_s = NULL;
    *out_link = NULL;
    return -1;
}

/*
 * Ensure a per-stream link is attached to stream_ctx. On first touch
 * (path_callback_ctx still points at the session via the prefix
 * declaration), allocate a fresh link, install it as path_callback_ctx,
 * and set *out_first_touch = 1 so the caller emits NEW_STREAM.
 * Subsequent calls return the existing link with *out_first_touch = 0.
 */
static inline aiopquic_wt_stream_link_t* aiopquic_wt_ensure_link(
        aiopquic_wt_session_t* s,
        aiopquic_wt_stream_link_t* maybe_link,
        h3zero_stream_ctx_t* stream_ctx,
        uint64_t stream_id,
        int* out_first_touch) {
    if (maybe_link) {
        *out_first_touch = 0;
        return maybe_link;
    }
    aiopquic_wt_stream_link_t* link = aiopquic_wt_stream_link_create(s, stream_id);
    if (!link) {
        *out_first_touch = 0;
        return NULL;
    }
    stream_ctx->path_callback_ctx = link;
    *out_first_touch = 1;
    return link;
}

/*
 * WT push: notification event carrying a BORROWED pointer to
 * the per-stream aiopquic_stream_ctx_t. No inline byte copy — bytes
 * live in sc->rx and the consumer (asyncio drain_rx) pops them
 * directly. entry.data_length=0 signals "borrowed" to spsc_ring_pop
 * which then skips the free.
 *
 * Used for SPSC_EVT_WT_STREAM_DATA and SPSC_EVT_WT_STREAM_FIN where
 * we want true flow control: byte-ring fullness blocks the publisher
 * via lack of MAX_STREAM_DATA extension.
 */
static inline void aiopquic_wt_push_event_with_sc(
        aiopquic_wt_session_t* s,
        uint32_t event_type,
        uint64_t stream_id,
        aiopquic_stream_ctx_t* sc,
        uint8_t is_fin) {
    /* RX data-event coalescing — see the raw-QUIC twin in callback.h.
     * At most one outstanding WT_STREAM_DATA notification per
     * stream; losers skip (the in-flight notification's drain pops all
     * available sc->rx bytes). FIN always pushes. */
    if (event_type == SPSC_EVT_WT_STREAM_DATA) {
        if (!aiopquic_stream_ctx_rx_event_pending_arm(sc)) {
            s->bridge->cnt_rx_data_event_coalesced++;
            return;
        }
    }
    spsc_entry_t entry = {0};
    entry.event_type = event_type;
    entry.stream_id = stream_id;
    entry.cnx = s->cnx;
    entry.stream_ctx = s;     /* session ptr for asyncio routing */
    entry.data_buf = sc;      /* borrowed; freed by link_destroy */
    entry.data_length = 0;    /* sentinel: do not free on pop */
    entry.is_fin = is_fin;
    if (aiopquic_rx_push(s->bridge, &entry, NULL, 0) != 0
            && event_type == SPSC_EVT_WT_STREAM_DATA) {
        s->bridge->worker_rx_event_drops_stream_data++;
        /* Clear rx_event_pending so the next arrival retries. */
        aiopquic_stream_ctx_rx_event_pending_clear(sc);
    }
}

/*
 * Push a WT event to the bridge's rx_event_ring. data may be NULL/0 for
 * pure events. Caller (picoquic thread) must ensure session is set.
 */
static inline void aiopquic_wt_push_event(
        aiopquic_wt_session_t* s,
        uint32_t event_type,
        uint64_t stream_id,
        uint64_t error_code,
        const uint8_t* data,
        uint32_t data_len) {
    spsc_entry_t entry = {0};
    entry.event_type = event_type;
    entry.stream_id = stream_id;
    entry.error_code = error_code;
    entry.cnx = s->cnx;
    entry.stream_ctx = s;       /* session ptr for demux */
    if (aiopquic_rx_push(s->bridge, &entry, data, data_len) != 0
            && event_type == SPSC_EVT_WT_STREAM_DATA) {
        s->bridge->worker_rx_event_drops_stream_data++;
    }
}

/* Source of a SESSION_CLOSED / CNX_CLOSED, carried in is_fin, with
 * AIOPQUIC_CLOSE_LOCAL or'ed in for a local cause. */
#define AIOPQUIC_WT_CLOSE_SESSION      0   /* capsule, control-stream FIN or reset */
#define AIOPQUIC_WT_CLOSE_APPLICATION  1   /* QUIC APPLICATION_CLOSE */
#define AIOPQUIC_WT_CLOSE_TRANSPORT    2   /* QUIC transport close, idle timeout, stateless reset */

static inline void aiopquic_wt_push_close(
        aiopquic_wt_session_t* s,
        uint32_t event_type,
        uint64_t error_code,
        const char* reason,
        uint8_t source) {
    spsc_entry_t entry = {0};
    entry.event_type = event_type;
    entry.stream_id = s->control_stream_id;
    entry.error_code = error_code;
    entry.is_fin = source;
    entry.cnx = s->cnx;
    entry.stream_ctx = s;
    (void)aiopquic_rx_push(s->bridge, &entry, (const uint8_t*)reason,
                           reason ? (uint32_t)strlen(reason) : 0);
}

/*
 * Push NEW_STREAM with a BORROWED sc pointer so Python can stash it
 * in its _stream_tx_ctxs dict for subsequent push_stream_data calls
 * without a round-trip lookup.
 */
static inline void aiopquic_wt_push_new_stream(
        aiopquic_wt_session_t* s,
        uint64_t stream_id,
        aiopquic_stream_ctx_t* sc) {
    spsc_entry_t entry = {0};
    entry.event_type = SPSC_EVT_WT_NEW_STREAM;
    entry.stream_id = stream_id;
    entry.cnx = s->cnx;
    entry.stream_ctx = s;
    entry.data_buf = sc;     /* BORROWED */
    entry.data_length = 0;   /* sentinel: do not free on pop */
    (void)aiopquic_rx_push(s->bridge, &entry, NULL, 0);
}

/*
 * Push STREAM_LINK_RELEASE — the last event for a stream. Carries the
 * link pointer (in data_buf, data_length=0). drain_rx pops this in
 * FIFO order with all preceding stream events, so by the time it
 * runs Python has already drained sc->rx for every STREAM_DATA/FIN
 * for this stream. drain_rx then calls aiopquic_wt_stream_link_destroy
 * and does NOT emit the event to user code.
 *
 * Ordering is the load-bearing property: this is the mechanism that
 * prevents the BORROWED-sc UAF that motivated the LINK_RELEASE pattern.
 */
/*
 * Push WT_STREAM_DESTROY — surfaces "stream is fully retired" to the
 * WebTransportSession dispatcher so it can pop _stream_tx_ctxs[sid]
 * etc. Must be pushed BEFORE link_release so the FIFO order on the
 * SPSC ring guarantees Python sees the destroy event while the link
 * (and its sc) are still alive. drain_rx surfaces this and does NOT
 * call any destroy — LINK_RELEASE owns the sc ref drop.
 */
static inline int aiopquic_wt_push_stream_destroy(
        aiopquic_wt_session_t* s,
        uint64_t stream_id) {
    spsc_entry_t entry = {0};
    entry.event_type = SPSC_EVT_WT_STREAM_DESTROY;
    entry.stream_id = stream_id;
    entry.cnx = s->cnx;
    entry.stream_ctx = s;  /* session ptr for asyncio routing */
    /* Out of memory is the only failure; the caller then skips the
     * paired link_release, since Python's dict would still map the
     * sid to the freed sc. */
    return aiopquic_rx_push(s->bridge, &entry, NULL, 0);
}

static inline void aiopquic_wt_push_link_release(
        aiopquic_wt_session_t* s,
        uint64_t stream_id,
        aiopquic_wt_stream_link_t* link) {
    spsc_entry_t entry = {0};
    entry.event_type = SPSC_EVT_WT_STREAM_LINK_RELEASE;
    entry.stream_id = stream_id;
    entry.cnx = s->cnx;
    entry.stream_ctx = s;
    entry.data_buf = link;
    entry.data_length = 0;
    /* Out of memory leaks the link: it cannot be freed here while
     * Python may still hold events for the stream. */
    (void)aiopquic_rx_push(s->bridge, &entry, NULL, 0);
}

/*
 * Push STREAM_CREATED for an outbound stream we just opened. Carries
 * the BORROWED sc pointer (in data_buf, data_length=0) so Python can
 * register sc in _stream_tx_ctxs[sid] before the first push.
 */
static inline void aiopquic_wt_push_stream_created(
        aiopquic_wt_session_t* s,
        uint64_t stream_id,
        aiopquic_stream_ctx_t* sc,
        uint64_t error_code) {
    spsc_entry_t entry = {0};
    entry.event_type = SPSC_EVT_WT_STREAM_CREATED;
    entry.stream_id = stream_id;
    entry.error_code = error_code;
    entry.cnx = s->cnx;
    entry.stream_ctx = s;
    entry.data_buf = sc;     /* BORROWED, NULL on error */
    entry.data_length = 0;
    (void)aiopquic_rx_push(s->bridge, &entry, NULL, 0);
}

/* A client closes the connection once its FIN and its stream resets are
 * queued and the peer's FIN is in, or at the deadline, carried by the
 * app wake timer. A server leaves the shared connection to the client. */
static void aiopquic_wt_maybe_close_cnx(aiopquic_wt_session_t* s,
                                        picoquic_cnx_t* cnx) {
    if (aiopquic_wt_diag_enabled()) {
        fprintf(stderr, "[wt-diag] maybe_close cnx=%p client=%d fin_sent=%d cleanup=%d peer_fin=%d deadline=%llu\n",
            (void*)cnx, cnx ? picoquic_is_client(cnx) : -1, s->fin_sent, s->cleanup_done, s->peer_fin,
            (unsigned long long)s->close_deadline);
        fflush(stderr);
    }
    if (cnx == NULL || !picoquic_is_client(cnx)
            || !s->fin_sent || !s->cleanup_done) {
        return;
    }
    uint64_t now = picoquic_get_quic_time(picoquic_get_quic_ctx(cnx));
    uint64_t at = now + (s->peer_fin ? AIOPQUIC_WT_CLOSE_GRACE_US
                                     : AIOPQUIC_WT_CLOSE_DEADLINE_US);
    if (s->close_deadline == 0 || at < s->close_deadline) {
        s->close_deadline = at;
        picoquic_set_app_wake_time(cnx, at);
    }
}

/* The peer ended its side of CONNECT. */
static void aiopquic_wt_peer_fin(aiopquic_wt_session_t* s, picoquic_cnx_t* cnx) {
    s->peer_fin = 1;
    aiopquic_wt_maybe_close_cnx(s, cnx);
}

/* Our side of CONNECT is done. */
static void aiopquic_wt_fin_sent(aiopquic_wt_session_t* s, picoquic_cnx_t* cnx) {
    s->fin_sent = 1;
    s->session_closing = 1;
    aiopquic_wt_maybe_close_cnx(s, cnx);
}

static int aiopquic_wt_path_callback(picoquic_cnx_t* cnx, uint8_t* bytes,
                                     size_t length,
                                     picohttp_call_back_event_t event,
                                     h3zero_stream_ctx_t* stream_ctx,
                                     void* path_app_ctx);

/* The session behind a client cnx: the one stream prefix we declared. */
static aiopquic_wt_session_t* aiopquic_wt_client_session(
        h3zero_callback_ctx_t* h3) {
    for (h3zero_stream_prefix_t* p = h3->stream_prefixes.first; p != NULL;
            p = p->next) {
        if (p->function_call == aiopquic_wt_path_callback) {
            return (aiopquic_wt_session_t*)p->function_ctx;
        }
    }
    return NULL;
}

/* Connection callback of a cnx that carries WT sessions, both roles. The
 * callback context stays h3zero's, which its helpers read back from the
 * cnx; everything is handed on to h3zero afterwards. A client learns of a
 * connection close here, h3zero's client branch only flags it, and the
 * close deadline rides the app wake timer. On a server h3zero frees its
 * context on a close, so every session's cached pointers die here first. */
static int aiopquic_wt_cnx_cb(picoquic_cnx_t* cnx, uint64_t stream_id,
                              uint8_t* bytes, size_t length,
                              picoquic_call_back_event_t event,
                              void* callback_ctx, void* v_stream_ctx) {
    h3zero_callback_ctx_t* h3 = (h3zero_callback_ctx_t*)callback_ctx;
    int client = picoquic_is_client(cnx);
    switch (event) {
    case picoquic_callback_app_wakeup: {
        aiopquic_wt_session_t* s = client ? aiopquic_wt_client_session(h3) : NULL;
        if (aiopquic_wt_diag_enabled()) {
            fprintf(stderr, "[wt-diag] app_wakeup deadline=%llu peer_fin=%d\n",
                s ? (unsigned long long)s->close_deadline : 0ULL, s ? s->peer_fin : -1);
            fflush(stderr);
        }
        if (s != NULL && s->close_deadline != 0) {
            s->close_deadline = 0;
            picoquic_close(cnx, H3ZERO_NO_ERROR);
        }
        break;
    }
    case picoquic_callback_close:
    case picoquic_callback_application_close:
    case picoquic_callback_stateless_reset: {
        uint64_t code = 0;
        uint8_t source = AIOPQUIC_WT_CLOSE_TRANSPORT;
        const char* reason = NULL;
        if (event == picoquic_callback_application_close) {
            code = picoquic_get_application_error(cnx);
            source = AIOPQUIC_WT_CLOSE_APPLICATION;
            reason = picoquic_get_remote_error_reason(cnx);
        } else if (event == picoquic_callback_close) {
            code = picoquic_get_remote_error(cnx);
            reason = picoquic_get_remote_error_reason(cnx);
            if (code == 0 && picoquic_get_local_error(cnx) != 0) {
                code = picoquic_get_local_error(cnx);
                reason = picoquic_error_name(code);
                source |= AIOPQUIC_CLOSE_LOCAL;
            }
        }
        int final = event != picoquic_callback_application_close;
        for (h3zero_stream_prefix_t* p = h3->stream_prefixes.first; p != NULL;
                p = p->next) {
            if (p->function_call != aiopquic_wt_path_callback) {
                continue;
            }
            aiopquic_wt_session_t* s = (aiopquic_wt_session_t*)p->function_ctx;
            if (s->bridge && s->bridge->deferred_resets) {
                aiopquic_deferred_resets_drop_cnx(s->bridge, cnx);
            }
            if (final && s->bridge && s->bridge->close_reasons) {
                aiopquic_close_reason_drop(s->bridge, cnx);
            }
            if (!s->session_closing) {
                aiopquic_wt_push_close(s, SPSC_EVT_WT_SESSION_CLOSED, code,
                                       reason, source);
                s->session_closing = 1;
            }
            if (client) {
                aiopquic_wt_push_close(s, SPSC_EVT_WT_CNX_CLOSED, code,
                                       (source & AIOPQUIC_CLOSE_LOCAL)
                                       ? reason : NULL, source);
            } else {
                s->cnx = NULL;
                s->h3_ctx = NULL;
                s->control_stream = NULL;
            }
        }
        break;
    }
    default:
        break;
    }
    return h3zero_callback(cnx, stream_id, bytes, length, event,
                           callback_ctx, v_stream_ctx);
}

/* A server that sent SETTINGS_WT_ENABLED and refused the "webtransport"
 * CONNECT (non-2xx, reset or STOP_SENDING before a response) gets one
 * "webtransport-h3" CONNECT on a new stream of the same connection.
 * Returns 1 when the refusal is consumed: retry sent, or REFUSED pushed. */
static int aiopquic_wt_retry_connect(aiopquic_wt_session_t* s,
                                     picoquic_cnx_t* cnx,
                                     h3zero_stream_ctx_t* stream_ctx) {
    h3zero_callback_ctx_t* h3 = s->h3_ctx;
    if (s->connect_authority == NULL || s->session_ready || s->session_closing
            || h3 == NULL || stream_ctx == NULL
            || stream_ctx->stream_id != s->control_stream_id
            || h3->settings.webtransport_enabled == 0) {
        return 0;
    }
    uint64_t old_id = s->control_stream_id;
    /* picowt allows one session per connection: release the refused one. */
    picowt_uncount_session(h3, stream_ctx);
    /* Unhook the refused CONNECT so its remaining events stay with h3zero,
     * and so dropping its prefix does not deregister the session. */
    stream_ctx->path_callback = NULL;
    stream_ctx->path_callback_ctx = NULL;
    h3zero_stream_prefix_t* prefix = h3zero_find_stream_prefix(h3, old_id);
    if (prefix != NULL) {
        prefix->function_call = NULL;
    }
    h3zero_delete_stream_prefix(cnx, h3, old_id);
    (void)picoquic_reset_stream(cnx, old_id, H3ZERO_REQUEST_CANCELLED);
    if (s->control_stream == stream_ctx) {
        s->control_stream = NULL;
    }

    h3zero_stream_ctx_t* control = picowt_set_control_stream(cnx, h3);
    int rc = -1;
    if (control != NULL) {
        s->control_stream = control;
        s->control_stream_id = control->stream_id;
        h3->wt_connect_protocol = picowt_connect_protocol_h3;
        rc = picowt_connect(cnx, h3, control, s->connect_authority,
                            s->connect_path, aiopquic_wt_path_callback,
                            (void*)s, s->connect_protocols);
    }
    aiopquic_wt_drop_retry(s);
    picoquic_log_app_message(cnx,
        "WebTransport CONNECT on stream %" PRIu64 " refused; webtransport-h3 retry %s",
        old_id, rc == 0 ? "sent" : "failed");
    if (rc != 0) {
        aiopquic_wt_push_event(s, SPSC_EVT_WT_SESSION_REFUSED,
                                s->control_stream_id, 5, NULL, 0);
    }
    return 1;
}

/*
 * The picohttp_post_data_cb_fn registered via picowt_connect.
 * Runs in the picoquic network thread.
 *
 * Translates picohttp_call_back_event_t → SPSC_EVT_WT_* and pushes
 * to rx_event_ring. Special-cases the control stream: data on the control
 * stream is capsule bytes; we feed it to picowt_receive_capsule and
 * surface CLOSE/DRAIN as session events instead of stream events.
 *
 * path_app_ctx is polymorphic:
 *   - For control-stream events (and the very first event seen on a
 *     prefix-routed data stream before we install a link), it is the
 *     session pointer.
 *   - For all subsequent data-stream events, it is the link pointer
 *     we installed on first touch.
 * aiopquic_wt_ctx_resolve discriminates by the kind tag at offset 0
 * and rejects wild / freed contexts.
 */
static int aiopquic_wt_path_callback(
        picoquic_cnx_t* cnx,
        uint8_t* bytes, size_t length,
        picohttp_call_back_event_t event,
        h3zero_stream_ctx_t* stream_ctx,
        void* path_app_ctx) {
    aiopquic_wt_session_t* s = NULL;
    aiopquic_wt_stream_link_t* link = NULL;
    if (aiopquic_wt_ctx_resolve(path_app_ctx, &s, &link) != 0 || !s) {
        return 0;
    }

    int is_control = (stream_ctx != NULL &&
                       stream_ctx->stream_id == s->control_stream_id);
    uint64_t sid = stream_ctx ? stream_ctx->stream_id : 0;

    switch (event) {
    case picohttp_callback_connecting:
        break;

    case picohttp_callback_connect_accepted:
        s->session_ready = 1;
        /* Capture the server's selected WT-Protocol from the parsed
         * CONNECT response header. h3zero populates header.wt_protocol
         * (NUL-terminated) before firing this event; the buffer is
         * h3zero-owned and lives until stream cleanup, so we copy it
         * onto the session now. NULL when the server sent no WT-Protocol. */
        if (stream_ctx != NULL &&
            stream_ctx->ps.stream_state.header.wt_protocol != NULL) {
            s->wt_protocol = aiopquic_wt_strdup(
                (const char*)stream_ctx->ps.stream_state.header.wt_protocol);
        }
        if (s->bridge != NULL && s->bridge->keep_alive_us > 0) {
            /* PING keep-alive on the WT cnx — same rationale as the
             * raw-QUIC path: hold a quiet (e.g. FC-stalled) connection
             * open past the idle timeout. Worker thread owns cnx here. */
            picoquic_enable_keep_alive(cnx, s->bridge->keep_alive_us);
        }
        aiopquic_wt_log_cnxid("client-cnx-ready", cnx, UINT64_MAX);
        {
            /* The handshake-time state asyncio needs rides with READY. */
            aiopquic_cnx_snapshot_t snap;
            aiopquic_cnx_snapshot_fill(cnx, &snap);
            aiopquic_wt_push_event(s, SPSC_EVT_WT_SESSION_READY,
                                    s->control_stream_id, 0,
                                    (const uint8_t*)&snap, sizeof(snap));
        }
        break;

    case picohttp_callback_connect_refused:
        if (aiopquic_wt_retry_connect(s, cnx, stream_ctx)) {
            break;
        }
        /* error_code carries the response status. */
        aiopquic_wt_push_event(s, SPSC_EVT_WT_SESSION_REFUSED,
                                s->control_stream_id,
                                stream_ctx != NULL
                                    ? (uint64_t)stream_ctx->ps.stream_state.header.status
                                    : 0,
                                NULL, 0);
        break;

    case picohttp_callback_drain:
        /* picoquic >= 1.1.50 parses the DRAIN capsule itself and
         * surfaces it as this event; emit the same signal our own
         * capsule branch pushes when it sees the raw capsule. */
        aiopquic_wt_push_event(s, SPSC_EVT_WT_SESSION_DRAINING,
                                s->control_stream_id, 0, NULL, 0);
        break;

    case picohttp_callback_post_data:
        if (is_control) {
            int rc = picowt_receive_capsule(cnx, bytes, bytes + length,
                                              &s->capsule);
            if (rc == 0 && s->capsule.h3_capsule.is_stored) {
                uint64_t ctype = s->capsule.h3_capsule.capsule_type;
                if (ctype == picowt_capsule_close_webtransport_session) {
                    if (!s->session_closing) {
                        aiopquic_wt_push_event(s, SPSC_EVT_WT_SESSION_CLOSED,
                            s->control_stream_id, s->capsule.error_code,
                            s->capsule.error_msg, (uint32_t)s->capsule.error_msg_len);
                    }
                    s->session_closing = 1;
                } else if (ctype == picowt_capsule_drain_webtransport_session) {
                    aiopquic_wt_push_event(s, SPSC_EVT_WT_SESSION_DRAINING,
                        s->control_stream_id, 0, NULL, 0);
                }
                picowt_release_capsule(&s->capsule);
                memset(&s->capsule, 0, sizeof(s->capsule));
            }
        } else {
            /* Data stream: ensure a link is attached. First touch
             * triggers NEW_STREAM (which carries the sc as BORROWED
             * for the Python-side _stream_tx_ctxs dict). */
            int first_touch = 0;
            link = aiopquic_wt_ensure_link(s, link, stream_ctx, sid,
                                            &first_touch);
            if (!link) return -1;
            aiopquic_stream_ctx_t* sc = link->sc;

            uint32_t advertise_cap =
                s->bridge->rx_data_ring_cap > 0
                    ? s->bridge->rx_data_ring_cap
                    : AIOPQUIC_RX_DATA_RING_CAP_DEFAULT;
            int rx_first = (sc->rx == NULL);
            if (rx_first) {
                /* Switch picoquic to app-controlled FC on this stream.
                 * The actual MAX_STREAM_DATA grant is issued via
                 * picoquic_open_flow_control AFTER we push the
                 * just-delivered bytes — see the FC block below. */
                (void)picoquic_set_app_flow_control(cnx, sid, 1);
            }
            if (aiopquic_stream_ctx_ensure_rx(sc, advertise_cap) != 0) {
                return -1;
            }
            uint32_t pushed = aiopquic_stream_buf_push(
                sc->rx, bytes, (uint32_t)length);
            if (pushed > 0) {
                aiopquic_sc_rx_bytes_pushed_add(pushed);
            }
            if (pushed != length) {
                s->bridge->worker_rx_byte_ring_overflow++;
                if (aiopquic_rx_log_enabled()
                        && s->bridge->worker_rx_byte_ring_overflow <= 16) {
                    fprintf(stderr,
                        "[aiopquic_rx] WT stream=%llu RX ring overflow: "
                        "pushed %u of %zu (free=%u, advertise=%u). "
                        "Peer flow-control violation.\n",
                        (unsigned long long)sid, pushed, length,
                        aiopquic_stream_buf_free(sc->rx), advertise_cap);
                }
                return -1;
            }
            /* First touch extends the handshake window to the ring only
             * when the window is smaller; replenishment is consumer-driven
             * (SPSC_EVT_TX_OPEN_FLOW_CONTROL from drain_rx). */
            if (rx_first) {
                if (aiopquic_initial_rx_window(cnx, sid) < advertise_cap) {
                    uint32_t buf_free = aiopquic_stream_buf_free(sc->rx);
                    (void)picoquic_open_flow_control(cnx, sid, buf_free);
                }
                aiopquic_stream_ctx_rx_credit_store(sc, advertise_cap);
            }
            if (first_touch) {
                aiopquic_wt_push_new_stream(s, sid, sc);
            }
            aiopquic_wt_push_event_with_sc(
                s, SPSC_EVT_WT_STREAM_DATA, sid, sc, 0);
        }
        break;

    case picohttp_callback_post_fin:
        if (is_control) {
            uint64_t code = 0;
            const uint8_t* reason = NULL;
            uint32_t reason_len = 0;
            if (length > 0
                    && picowt_receive_capsule(cnx, bytes, bytes + length,
                                              &s->capsule) == 0
                    && s->capsule.h3_capsule.is_stored
                    && s->capsule.h3_capsule.capsule_type
                        == picowt_capsule_close_webtransport_session) {
                code = s->capsule.error_code;
                reason = s->capsule.error_msg;
                reason_len = (uint32_t)s->capsule.error_msg_len;
            }
            if (!s->session_closing) {
                aiopquic_wt_push_event(s, SPSC_EVT_WT_SESSION_CLOSED,
                                        s->control_stream_id, code,
                                        reason, reason_len);
            }
            s->session_closing = 1;
            if (aiopquic_wt_diag_enabled()) {
                fprintf(stderr, "[wt-diag] control post_fin len=%zu code=%llu\n", length, (unsigned long long)code);
                fflush(stderr);
            }
            aiopquic_wt_peer_fin(s, cnx);
        } else {
            int first_touch = 0;
            link = aiopquic_wt_ensure_link(s, link, stream_ctx, sid,
                                            &first_touch);
            if (!link) return -1;
            aiopquic_stream_ctx_t* sc = link->sc;

            uint32_t advertise_cap =
                s->bridge->rx_data_ring_cap > 0
                    ? s->bridge->rx_data_ring_cap
                    : AIOPQUIC_RX_DATA_RING_CAP_DEFAULT;
            int rx_first = (sc->rx == NULL);
            if (rx_first) {
                (void)picoquic_set_app_flow_control(cnx, sid, 1);
            }
            if (aiopquic_stream_ctx_ensure_rx(sc, advertise_cap) != 0) {
                return -1;
            }
            if (length > 0) {
                uint32_t pushed = aiopquic_stream_buf_push(
                    sc->rx, bytes, (uint32_t)length);
                if (pushed > 0) {
                    aiopquic_sc_rx_bytes_pushed_add(pushed);
                }
                if (pushed != length) {
                    s->bridge->worker_rx_byte_ring_overflow++;
                    return -1;
                }
            }
            aiopquic_stream_buf_set_fin(sc->rx);

            /* All data has arrived: no grant (RFC 9000 §3.3). */
            if (rx_first) {
                aiopquic_stream_ctx_rx_credit_store(
                    sc, aiopquic_stream_ctx_rx_consumed_load(sc) + advertise_cap);
            }

            if (first_touch) {
                aiopquic_wt_push_new_stream(s, sid, sc);
            }
            aiopquic_wt_push_event_with_sc(
                s, SPSC_EVT_WT_STREAM_FIN, sid, sc, 1);
        }
        break;

    case picohttp_callback_provide_data: {
        /* TX path. link MUST exist for an outbound stream — we set
         * it at create time. A provide_data on a peer-opened bidi
         * stream we haven't replied on yet → link exists from the
         * RX first-touch path but sc->tx is NULL. Either way: no
         * tx ring → provide 0. */
        if (!link || !link->sc || !link->sc->tx) {
            (void)picoquic_provide_stream_data_buffer(bytes, 0, 0, 0);
            break;
        }
        aiopquic_stream_ctx_t* sc = link->sc;
        aiopquic_stream_buf_t* sb = sc->tx;
        uint32_t want = (uint32_t)length;
        /* FIN before the tail; see the raw prepare_to_send path. */
        int fin_after = aiopquic_stream_buf_fin_pending(sb);
        uint32_t avail = aiopquic_stream_buf_used(sb);
        uint32_t sendable = aiopquic_stream_ctx_tx_sendable(sc, avail);
        uint32_t to_send = (sendable < want) ? sendable : want;
        int is_fin = (fin_after && !sc->tx_reset_pending
                      && to_send == avail) ? 1 : 0;
        int still_active = (sendable > to_send) ? 1 : 0;
        if (!still_active && !is_fin
                && aiopquic_stream_ctx_tx_park(sc, to_send, fin_after)) {
            still_active = 1;
            s->bridge->cnt_tx_park_kept_active++;
        }
        uint8_t* buf = picoquic_provide_stream_data_buffer(
            bytes, to_send, is_fin, still_active);
        if (buf && to_send > 0) {
            aiopquic_stream_buf_pop(sb, buf, to_send);
            aiopquic_tx_data_bytes_pulled_add(to_send);
            if (aiopquic_wt_debug_enabled()) {
                fprintf(stderr, "[wt-debug] provide sid=%llu len=%u "
                        "is_fin=%d still_active=%d hex=",
                        (unsigned long long)sid, to_send,
                        is_fin, still_active);
                uint32_t dump = to_send < 32 ? to_send : 32;
                for (uint32_t i = 0; i < dump; i++) {
                    fprintf(stderr, "%02x", buf[i]);
                }
                fprintf(stderr, "\n");
                fflush(stderr);
            }
        }
        /* Edge-trigger TX backpressure: if a Python writer was
         * blocked (set tx_drain_pending=1 after seeing sc->tx full),
         * CAS-clear and emit one SPSC_EVT_STREAM_TX_DRAINED so it
         * wakes and retries. Hoisted OUTSIDE the to_send>0 guard so
         * a zero-byte provide_data still wakes the writer when the
         * ring genuinely drained via concurrent path (defensive vs
         * picoquic window-math edge cases). Single-shot per arm —
         * only the CAS winner pushes. */
        {
            if (aiopquic_stream_ctx_tx_drain_take(sc)) {
                spsc_entry_t drain_entry = {0};
                drain_entry.event_type = SPSC_EVT_STREAM_TX_DRAINED;
                drain_entry.stream_id = sid;
                drain_entry.cnx = s->cnx;
                drain_entry.stream_ctx = s;
                if (aiopquic_rx_push(s->bridge, &drain_entry, NULL, 0) == 0) {
                    sc->cnt_drain_fires++;
                    sc->last_drain_fire_ns = aiopquic_now_ns();
                } else {
                    sc->cnt_drain_dropped++;
                    atomic_store_explicit(
                        &sc->tx_drain_pending, 1,
                        memory_order_release);
                }
            }
        }
        /* On FIN we don't free the link here — picoquic still owns
         * the stream until h3zero fires picohttp_callback_free. */
        break;
    }

    case picohttp_callback_post_datagram:
        aiopquic_wt_push_event(s, SPSC_EVT_WT_DATAGRAM,
                                s->control_stream_id, 0,
                                bytes, (uint32_t)length);
        break;

    case picohttp_callback_provide_datagram: {
        /* Pull one record from the session ring, same model as raw
         * QUIC's prepare_datagram: h3zero offers `length` bytes of
         * packet space and frames what we copy in as an HTTP datagram.
         * A record too large for THIS packet stays queued — producer-
         * side max_record guarantees it fits a fresh one. */
        aiopquic_dgram_buf_t* db = s->dgram_ring;
        uint32_t rec = db ? aiopquic_dgram_buf_peek_len(db) : 0;
        if (aiopquic_wt_diag_enabled()) {
            fprintf(stderr, "[wt-diag] provide_datagram ring=%p rec=%u "
                    "space=%zu\n", (void*)db, rec, length);
            fflush(stderr);
        }
        if (rec == 0) {
            (void)h3zero_provide_datagram_buffer(bytes, 0, 0);
            break;
        }
        if (rec > (uint32_t)length) {
            db->head_deferred++;
            (void)h3zero_provide_datagram_buffer(bytes, 0, 1);
            break;
        }
        int more = (aiopquic_dgram_buf_used(db)
                    > AIOPQUIC_DGRAM_REC_HDR + rec) ? 1 : 0;
        uint8_t* buf = h3zero_provide_datagram_buffer(bytes, rec, more);
        if (buf) {
            aiopquic_dgram_buf_pop_into(db, buf, rec);
            s->bridge->worker_dgram_records_sent++;
            s->bridge->worker_dgram_bytes_sent += rec;
            /* Edge-triggered producer wakeup, as on the raw path. */
            if (aiopquic_dgram_buf_drain_take(db)) {
                spsc_entry_t drain_entry = {0};
                drain_entry.event_type = SPSC_EVT_DATAGRAM_TX_DRAINED;
                drain_entry.cnx = cnx;
                drain_entry.stream_ctx = s;  /* session ptr for routing */
                if (aiopquic_rx_push(s->bridge, &drain_entry, NULL, 0) != 0) {
                    atomic_store_explicit(&db->drain_pending, 1,
                                          memory_order_release);
                }
            }
        }
        break;
    }

    case picohttp_callback_reset:
        if (aiopquic_wt_diag_enabled()) {
            fprintf(stderr,
                "[wt-diag] picohttp_callback_reset sid=%llu "
                "remote_err=%llu control=%d\n",
                (unsigned long long)sid,
                (unsigned long long)picoquic_get_remote_stream_error(cnx, sid),
                is_control ? 1 : 0);
            fflush(stderr);
        }
        if (is_control && aiopquic_wt_retry_connect(s, cnx, stream_ctx)) {
            break;
        }
        if (is_control) {
            if (!s->session_closing) {
                aiopquic_wt_push_event(s, SPSC_EVT_WT_SESSION_CLOSED,
                                        s->control_stream_id,
                                        picoquic_get_remote_stream_error(cnx, sid),
                                        NULL, 0);
            }
            s->session_closing = 1;
            aiopquic_wt_peer_fin(s, cnx);
        } else {
            aiopquic_wt_push_event(s, SPSC_EVT_WT_STREAM_RESET,
                                    sid,
                                    aiopquic_wt_code_from_h3(
                                        picoquic_get_remote_stream_error(cnx, sid)),
                                    NULL, 0);
            /* link is freed at picohttp_callback_free below. */
        }
        break;

    case picohttp_callback_stop_sending:
        if (aiopquic_wt_diag_enabled()) {
            fprintf(stderr,
                "[wt-diag] picohttp_callback_stop_sending sid=%llu "
                "remote_err=%llu\n",
                (unsigned long long)sid,
                (unsigned long long)picoquic_get_remote_stop_sending_error(
                    cnx, sid));
            fflush(stderr);
        }
        if (is_control && aiopquic_wt_retry_connect(s, cnx, stream_ctx)) {
            break;
        }
        aiopquic_wt_push_event(s, SPSC_EVT_WT_STOP_SENDING,
                                sid,
                                aiopquic_wt_code_from_h3(
                                    picoquic_get_remote_stop_sending_error(cnx, sid)),
                                NULL, 0);
        /* link is freed at picohttp_callback_free below. */
        break;

    case picohttp_callback_deregister:
        if (!s->session_closing) {
            aiopquic_wt_push_event(s, SPSC_EVT_WT_SESSION_CLOSED,
                                    s->control_stream_id, 0, NULL, 0);
            s->session_closing = 1;
        }
        /* picoquic is retiring the cnx + h3zero ctx; both are invalid
         * once this returns. The session struct outlives the cnx (freed
         * on SESSION_CLOSED after Python drops its ref), so null the
         * cached picoquic-owned pointers here — otherwise a late TX event
         * (e.g. TX_WT_RESET_STREAM) drained afterward passes its !s->cnx
         * guard on a dangling pointer and h3zero_find_stream walks a freed
         * splay tree. Per-stream picohttp_callback_free uses its local
         * stream_ctx arg, not s->h3_ctx, so link release is unaffected. */
        s->cnx = NULL;
        s->h3_ctx = NULL;
        s->control_stream = NULL;
        break;

    case picohttp_callback_free:
        /* h3zero is releasing this stream_ctx. By this point picoquic
         * has fully retired the stream — no further provide_data /
         * post_data / reset events will fire.
         *
         * Push STREAM_LINK_RELEASE so drain_rx tears down the link
         * AFTER it has popped every preceding STREAM_DATA / STREAM_FIN
         * / RESET / STOP_SENDING for this stream out of the SPSC ring.
         * The ring's FIFO order is what guarantees Python has drained
         * sc->rx before sc is freed — the lifetime invariant that
         * makes the BORROWED-sc convention safe. */
        if (aiopquic_wt_diag_enabled()) {
            fprintf(stderr,
                "[wt-diag] picohttp_callback_free sid=%llu "
                "link=%s control=%d session_closing=%d\n",
                (unsigned long long)sid,
                link ? "yes" : "no",
                is_control ? 1 : 0,
                s->session_closing);
            fflush(stderr);
        }
        /* h3zero frees CONNECT once both FINs are done, possibly while
         * the session lives; the cached pointer must not outlive it. */
        if (is_control && stream_ctx == s->control_stream) {
            s->control_stream = NULL;
            s->bridge->cnt_wt_control_released++;
        }
        if (link && stream_ctx
                && stream_ctx->path_callback_ctx == link) {
            stream_ctx->path_callback_ctx = NULL;
            /* Order: STREAM_DESTROY first (Python dict cleanup),
             * then LINK_RELEASE (link + sc ref drop). FIFO on the
             * SPSC ring preserves this ordering at the consumer.
             * PAIRED: if the destroy push fails (ring full), skip
             * the release too — otherwise drain_rx frees the sc
             * while Python's dict still maps the sid, leaving a
             * dangling pointer for any sid-keyed access. Leaking
             * the link+sc instead preserves "present in dict ⇒ sc
             * alive"; bounded by per-cnx stream count and swept at
             * session close. */
            if (aiopquic_wt_push_stream_destroy(s, sid) == 0) {
                aiopquic_wt_push_link_release(s, sid, link);
            }
        } else if (link) {
            /* Diagnostic: cleanup skipped despite a link being
             * provided via path_app_ctx. Tracks the leak signature
             * for the May-23 sub-side retention investigation. */
            s->bridge->cnt_wt_callback_free_skipped++;
            if (aiopquic_wt_diag_enabled()) {
                fprintf(stderr,
                    "[wt-diag] callback_free SKIP sid=%llu link=%p "
                    "stream_ctx=%p path_ctx=%p match=%d\n",
                    (unsigned long long)sid,
                    (void*)link,
                    (void*)stream_ctx,
                    stream_ctx ? stream_ctx->path_callback_ctx : NULL,
                    stream_ctx
                        ? (stream_ctx->path_callback_ctx == link) : 0);
                fflush(stderr);
            }
        }
        break;

    default:
        break;
    }
    return 0;
}

/*
 * Server-side WT path callback. Registered in the picoquic engine's
 * picohttp_server_parameters_t::path_table with path_app_ctx set to
 * the bridge (aiopquic_ctx_t*). h3zero invokes this on a CONNECT
 * landing at the registered path; we accept the WT session, allocate
 * a per-session aiopquic_wt_session_t, re-point the stream's callback
 * to aiopquic_wt_path_callback (the per-session handler used by the
 * client), declare the stream prefix so peer-opened WT streams within
 * this session route through us, and push SPSC_EVT_WT_NEW_SESSION so
 * the asyncio side can construct a Python WebTransportServerSession.
 *
 * Prefix-routed inbound streams arrive at aiopquic_wt_path_callback
 * with path_app_ctx == session (the declare_stream_prefix arg); the
 * per-session callback's first-touch path allocates a link and
 * rebinds stream_ctx->path_callback_ctx so subsequent dispatch is
 * O(0) via the link.
 */
static int aiopquic_wt_server_path_callback(
        picoquic_cnx_t* cnx,
        uint8_t* path_bytes, size_t path_len,
        picohttp_call_back_event_t event,
        h3zero_stream_ctx_t* stream_ctx,
        void* path_app_ctx) {
    aiopquic_ctx_t* bridge = (aiopquic_ctx_t*)path_app_ctx;
    if (!bridge || !stream_ctx) return -1;
    h3zero_callback_ctx_t* h3_ctx =
        (h3zero_callback_ctx_t*)picoquic_get_callback_context(cnx);
    if (!h3_ctx) return -1;
    if (event != picohttp_callback_connect) {
        /* h3zero routes the CONNECT stream's later frames, the capsules
         * and the FIN, through the path entry; the session owns them. */
        h3zero_stream_prefix_t* prefix =
            h3zero_find_stream_prefix(h3_ctx, stream_ctx->stream_id);
        if (prefix != NULL && prefix->function_call == aiopquic_wt_path_callback) {
            return aiopquic_wt_path_callback(cnx, path_bytes, path_len, event,
                                             stream_ctx, prefix->function_ctx);
        }
        return 0;
    }

    /* WT-Protocol: the server's most preferred mutual protocol. An offer
     * with no match is refused (h3zero sends the returned status); a
     * client that offered nothing gets a session with no protocol. */
    int proto_sel = AIOPQUIC_WT_PROTO_NONE_OFFERED;
    if (bridge->wt_supported_protocols != NULL) {
        proto_sel = aiopquic_wt_select_protocol(
            stream_ctx, bridge->wt_supported_protocols);
        if (proto_sel == AIOPQUIC_WT_PROTO_NO_MATCH) {
            return AIOPQUIC_WT_NO_PROTOCOL_STATUS;
        }
    }

    aiopquic_wt_session_t* s = aiopquic_wt_session_create(bridge);
    if (!s) return -1;
    s->cnx = cnx;
    s->h3_ctx = h3_ctx;
    s->control_stream = stream_ctx;
    s->control_stream_id = stream_ctx->stream_id;
    s->session_ready = 1;
    if (bridge != NULL && bridge->keep_alive_us > 0) {
        /* PING keep-alive on the accepted WT cnx (worker thread). */
        picoquic_enable_keep_alive(cnx, bridge->keep_alive_us);
    }
    aiopquic_wt_log_cnxid("server-cnx-accept", cnx, stream_ctx->stream_id);

    /* h3zero emits stream_state.wt_protocol as the WT-Protocol response
     * header; the session keeps a copy for negotiated_protocol. */
    if (proto_sel == AIOPQUIC_WT_PROTO_SELECTED &&
        stream_ctx->ps.stream_state.wt_protocol != NULL) {
        s->wt_protocol =
            aiopquic_wt_strdup(stream_ctx->ps.stream_state.wt_protocol);
    }

    stream_ctx->path_callback = aiopquic_wt_path_callback;
    stream_ctx->path_callback_ctx = s;

    (void)h3zero_declare_stream_prefix(
        h3_ctx, s->control_stream_id,
        aiopquic_wt_path_callback, s);

    {
        /* Cached ahead of NEW_SESSION, so the accepted session has it. */
        aiopquic_cnx_snapshot_t snap;
        aiopquic_cnx_snapshot_fill(cnx, &snap);
        spsc_entry_t se = {0};
        se.event_type = SPSC_EVT_CNX_SNAPSHOT;
        se.cnx = cnx;
        (void)aiopquic_rx_push(bridge, &se, (const uint8_t*)&snap, sizeof(snap));
    }

    spsc_entry_t entry = {0};
    entry.event_type = SPSC_EVT_WT_NEW_SESSION;
    entry.stream_id = s->control_stream_id;
    entry.cnx = cnx;
    entry.stream_ctx = s;
    (void)aiopquic_rx_push(bridge, &entry, path_bytes, (uint32_t)path_len);
    return 0;
}

/* WT §4.4: reset a WebTransport data stream with RESET_STREAM_AT so its
 * header, which names the session, still arrives. picowt does that for a
 * stream we opened; picoquic refuses it unless reset_stream_at was
 * negotiated and the header has been sent, and RESET_STREAM is then the
 * only reset. The caller checks that the stream has a send side.
 * Returns 0 when the stream is reset. */
static int aiopquic_wt_reset_stream(picoquic_cnx_t* cnx,
                                    h3zero_stream_ctx_t* st, uint64_t code) {
    if (picowt_reset_stream(cnx, st, code) == 0) {
        return 0;
    }
    return picoquic_reset_stream(cnx, st->stream_id, code);
}

/* picoquic_reset_stream and picoquic_stop_sending detach h3zero's stream
 * ctx, so the stream would never be released and h3zero would keep it,
 * its link and its sc until the session ends: put it back. A stream
 * picoquic already deleted is left alone (set fails on it). */
static void aiopquic_wt_stream_reattach(picoquic_cnx_t* cnx,
                                        h3zero_stream_ctx_t* st) {
    (void)picoquic_set_app_stream_ctx(cnx, st->stream_id, st);
}

/* The sc of session s behind h3zero stream st, or NULL. */
static aiopquic_stream_ctx_t* aiopquic_wt_stream_sc(aiopquic_wt_session_t* s,
                                                    h3zero_stream_ctx_t* st) {
    if (st->path_callback_ctx != NULL
            && *(uint32_t*)st->path_callback_ctx == AIOPQUIC_WT_CTX_LINK) {
        aiopquic_wt_stream_link_t* lk =
            (aiopquic_wt_stream_link_t*)st->path_callback_ctx;
        if (lk->session == s) {
            return lk->sc;
        }
    }
    return NULL;
}

/* Bytes h3zero sends ahead of the app's data on a WT stream we opened:
 * the stream or frame type, then the session id (as picowt_reset_stream
 * counts them). */
static uint64_t aiopquic_wt_preamble_len(picoquic_cnx_t* cnx,
                                         h3zero_stream_ctx_t* st) {
    if (!aiopquic_stream_is_local(cnx, st->stream_id)) return 0;
    uint64_t v = st->ps.stream_state.control_stream_id;
    return 2 + (v < 0x40 ? 1 : v < 0x4000 ? 2 : v < 0x40000000 ? 4 : 8);
}

/* RESET_STREAM_AT of st keeping its preamble and first `reliable` app
 * bytes. Returns 0 when the stream is reset. */
static int aiopquic_wt_reset_stream_reliable(picoquic_cnx_t* cnx,
        h3zero_stream_ctx_t* st, uint64_t code, uint64_t preamble,
        uint64_t reliable) {
    int rr = aiopquic_reset_stream_reliable(cnx, st->stream_id, code,
                                            preamble + reliable);
    if (rr == 0) {
        st->ps.stream_state.is_fin_sent = 1;
    }
    return rr;
}

static void aiopquic_wt_deferred_reset(aiopquic_ctx_t* ctx,
                                       aiopquic_deferred_reset_t* d) {
    (void)ctx;
    h3zero_callback_ctx_t* h3_ctx =
        (h3zero_callback_ctx_t*)picoquic_get_callback_context(d->cnx);
    h3zero_stream_ctx_t* st =
        h3_ctx ? h3zero_find_stream(h3_ctx, d->stream_id) : NULL;
    if (!st) return;
    if (aiopquic_wt_reset_stream_reliable(d->cnx, st, d->error_code,
            d->preamble, d->sc->tx_reliable_size) == 0) {
        aiopquic_stream_ctx_tx_abandon(d->sc);
    }
    aiopquic_wt_stream_reattach(d->cnx, st);
}

/*
 * WT TX-event dispatch — called from aiopquic_loop_cb in callback.h.
 * Returns 1 if event was a recognized WT command, 0 otherwise.
 * The caller is responsible for spsc_ring_pop on the entry.
 */
static int aiopquic_wt_handle_tx(picoquic_quic_t* quic,
                                   aiopquic_ctx_t* ctx,
                                   spsc_entry_t* entry) {
    aiopquic_wt_session_t* s = (aiopquic_wt_session_t*)entry->cnx;

    switch (entry->event_type) {
    case SPSC_EVT_TX_WT_OPEN: {
        const uint8_t* raw = (const uint8_t*)entry->data_buf;
        if (!s || !raw ||
            entry->data_length < sizeof(aiopquic_wt_open_params_t)) {
            return 1;
        }
        const aiopquic_wt_open_params_t* p =
            (const aiopquic_wt_open_params_t*)raw;
        char sni_buf[256];
        char path_buf[1024];
        char protocols_buf[256];
        const char* protocols_arg = NULL;
        size_t offset = sizeof(aiopquic_wt_open_params_t);

        if (p->sni_len == 0 || p->sni_len >= sizeof(sni_buf) ||
            offset + p->sni_len > entry->data_length) {
            aiopquic_wt_push_event(s, SPSC_EVT_WT_SESSION_REFUSED,
                                    0, 1, NULL, 0);
            return 1;
        }
        memcpy(sni_buf, raw + offset, p->sni_len);
        sni_buf[p->sni_len] = '\0';
        offset += p->sni_len;

        if (p->path_len == 0 || p->path_len >= sizeof(path_buf) ||
            offset + p->path_len > entry->data_length) {
            aiopquic_wt_push_event(s, SPSC_EVT_WT_SESSION_REFUSED,
                                    0, 2, NULL, 0);
            return 1;
        }
        memcpy(path_buf, raw + offset, p->path_len);
        path_buf[p->path_len] = '\0';
        offset += p->path_len;

        if (p->protocols_len > 0
                && p->protocols_len < sizeof(protocols_buf)
                && offset + p->protocols_len <= entry->data_length) {
            memcpy(protocols_buf, raw + offset, p->protocols_len);
            protocols_buf[p->protocols_len] = '\0';
            protocols_arg = protocols_buf;
        }

        picoquic_cnx_t* cnx = NULL;
        h3zero_callback_ctx_t* h3_ctx = NULL;
        h3zero_stream_ctx_t* control_stream = NULL;

        int rc = picowt_prepare_client_cnx(
            quic, (struct sockaddr*)&p->addr,
            &cnx, &h3_ctx, &control_stream,
            picoquic_current_time(), sni_buf);
        if (rc != 0 || !cnx || !h3_ctx || !control_stream) {
            aiopquic_wt_push_event(s, SPSC_EVT_WT_SESSION_REFUSED,
                                    0, 3, NULL, 0);
            return 1;
        }

        s->cnx = cnx;
        s->h3_ctx = h3_ctx;
        s->control_stream = control_stream;
        s->control_stream_id = control_stream->stream_id;
        h3_ctx->wt_connect_protocol =
            p->connect_protocol == AIOPQUIC_WT_CONNECT_H3
                ? picowt_connect_protocol_h3 : picowt_connect_protocol_legacy;
        if (p->connect_protocol == AIOPQUIC_WT_CONNECT_AUTO) {
            s->connect_authority = aiopquic_wt_strdup(sni_buf);
            s->connect_path = aiopquic_wt_strdup(path_buf);
            s->connect_protocols = protocols_arg != NULL
                ? aiopquic_wt_strdup(protocols_arg) : NULL;
            if (s->connect_path == NULL
                    || (protocols_arg != NULL && s->connect_protocols == NULL)) {
                aiopquic_wt_drop_retry(s);
            }
        }
        picoquic_set_callback(cnx, aiopquic_wt_cnx_cb, h3_ctx);
        /* Suppress h3zero's stdout banner on client-side cnx close
         * ("Received a connection close request"). h3zero_common.c
         * gates on !ctx->no_print; raw-QUIC has no equivalent print
         * so this matches WT to raw-QUIC behavior. */
        h3_ctx->no_print = 1;

        rc = picowt_connect(cnx, h3_ctx, control_stream,
                              sni_buf, path_buf,
                              aiopquic_wt_path_callback,
                              (void*)s, protocols_arg);
        if (rc == 0) {
            rc = picoquic_start_client_cnx(cnx);
        }
        if (rc != 0) {
            aiopquic_wt_push_event(s, SPSC_EVT_WT_SESSION_REFUSED,
                                    s->control_stream_id, 4, NULL, 0);
        }
        return 1;
    }

    case SPSC_EVT_TX_WT_CREATE_STREAM: {
        if (!s) return 1;
        if (!s->cnx || !s->h3_ctx) {
            /* Python pairs replies with requests in order: always reply. */
            aiopquic_wt_push_stream_created(s, 0, NULL, 1);
            return 1;
        }
        int is_bidir = (entry->is_fin & AIOPQUIC_WT_CREATE_BIDIR) != 0;
        h3zero_stream_ctx_t* new_stream = picowt_create_local_stream(
            s->cnx, is_bidir, s->h3_ctx, s->control_stream_id);
        if (!new_stream) {
            aiopquic_wt_push_stream_created(s, 0, NULL, 1);
            return 1;
        }
        /* Allocate the link now so the first provide_data has sc->tx
         * ready and Python's _stream_tx_ctxs[sid] dict gets the same
         * sc pointer via the STREAM_CREATED event below. */
        aiopquic_wt_stream_link_t* link =
            aiopquic_wt_stream_link_create(s, new_stream->stream_id);
        if (!link) {
            aiopquic_wt_push_stream_created(s, new_stream->stream_id,
                                              NULL, 2);
            return 1;
        }
        new_stream->path_callback = aiopquic_wt_path_callback;
        new_stream->path_callback_ctx = link;
        if (entry->error_code != 0) {
            int pri_ret = picoquic_set_stream_priority(
                s->cnx, new_stream->stream_id, (uint8_t)(entry->error_code - 1));
            if (pri_ret == 0) {
                ctx->worker_set_priority_applied++;
            } else {
                ctx->worker_set_priority_rejected++;
                ctx->worker_set_priority_last_err = (uint64_t)pri_ret;
            }
        }
        /* The first bytes queue behind the stream header, so one send
         * carries both. */
        uint8_t fin = (entry->is_fin & AIOPQUIC_WT_CREATE_FIN) != 0;
        if (entry->data_length > 0 || fin) {
            if (aiopquic_stream_ctx_send_data(
                    link->sc, (const uint8_t*)entry->data_buf,
                    entry->data_length, entry->aux, fin) != 1) {
                /* A nonzero code makes Python retire the stream. */
                aiopquic_wt_push_stream_created(s, new_stream->stream_id,
                                                  NULL, 3);
                return 1;
            }
            aiopquic_tx_data_bytes_pushed_add(entry->data_length);
            picoquic_mark_active_stream_v2(s->cnx, new_stream->stream_id, 1);
        }
        aiopquic_wt_push_stream_created(s, new_stream->stream_id,
                                          link->sc, 0);
        return 1;
    }

    case SPSC_EVT_TX_WT_CLOSE: {
        if (!s || !s->cnx || !s->control_stream) return 1;
        const char* msg = (const char*)entry->data_buf;
        char buf[256];
        int rc;
        if (msg && entry->data_length > 0 &&
            entry->data_length < sizeof(buf)) {
            memcpy(buf, msg, entry->data_length);
            buf[entry->data_length] = '\0';
            rc = picowt_send_close_session_message(
                s->cnx, s->control_stream,
                (uint32_t)entry->error_code, buf);
        } else {
            rc = picowt_send_close_session_message(
                s->cnx, s->control_stream,
                (uint32_t)entry->error_code, "");
        }
        s->session_closing = 1;
        if (rc == 0) {
            aiopquic_wt_fin_sent(s, s->cnx);
        }
        return 1;
    }
    case SPSC_EVT_TX_WT_FIN: {
        if (aiopquic_wt_diag_enabled()) {
            fprintf(stderr, "[wt-diag] TX_WT_FIN s=%p cnx=%p control=%p fin_sent=%d\n",
                (void*)s, s ? (void*)s->cnx : NULL, s ? (void*)s->control_stream : NULL, s ? s->fin_sent : -1);
            fflush(stderr);
        }
        if (!s || !s->cnx || !s->control_stream) return 1;
        if (!s->fin_sent && !s->control_stream->ps.stream_state.is_fin_sent) {
            int fin_rc = picoquic_add_to_stream(s->cnx, s->control_stream_id,
                                                NULL, 0, 1);
            if (aiopquic_wt_diag_enabled()) {
                fprintf(stderr, "[wt-diag] control FIN add_to_stream rc=%d\n", fin_rc);
                fflush(stderr);
            }
        }
        aiopquic_wt_fin_sent(s, s->cnx);
        return 1;
    }

    case SPSC_EVT_TX_WT_DRAIN: {
        if (!s || !s->cnx || !s->control_stream) return 1;
        picowt_send_drain_session_message(s->cnx, s->control_stream);
        return 1;
    }

    case SPSC_EVT_TX_WT_RESET_STREAM: {
        if (!s || !s->cnx) return 1;
        /* Re-fetch the live h3 ctx from the cnx rather than trusting the
         * cached s->h3_ctx: by the time this TX event is drained the
         * h3zero ctx can already be freed (observed as a SIGSEGV in
         * h3zero_find_stream -> picosplay_find walking a freed splay
         * tree, triggered by an incoming SUBSCRIBE over WebTransport).
         * picoquic_get_callback_context returns the current ctx for a
         * live cnx, or NULL once it is gone. */
        h3zero_callback_ctx_t* h3_ctx =
            (h3zero_callback_ctx_t*)picoquic_get_callback_context(s->cnx);
        if (!h3_ctx) return 1;
        h3zero_stream_ctx_t* st =
            h3zero_find_stream(h3_ctx, entry->stream_id);
        /* Untracked: a retired stream, or one of h3zero's own control or
         * QPACK streams; neither is ours to reset. */
        if (!st) return 1;
        if (!aiopquic_stream_can_send(s->cnx, entry->stream_id)) {
            ctx->cnt_tx_wrong_direction_dropped++;
            return 1;
        }
        uint64_t code = aiopquic_wt_code_to_h3(entry->error_code);
        aiopquic_stream_ctx_t* sc = aiopquic_wt_stream_sc(s, st);
        if (sc && sc->tx_reset_pending) {
            return 1;   /* already resetting */
        }
        uint64_t reliable = aiopquic_reset_reliable_size(s->cnx, sc, entry->aux);
        int rr;
        if (reliable == 0) {
            rr = aiopquic_wt_reset_stream(s->cnx, st, code);
        } else {
            uint64_t preamble = aiopquic_wt_preamble_len(s->cnx, st);
            if (reliable > atomic_load_explicit(&sc->tx->head,
                                                memory_order_relaxed)
                    && aiopquic_defer_reset(ctx, s->cnx, sc, entry->stream_id,
                                            code, reliable, preamble, 1) == 0) {
                picoquic_mark_active_stream_v2(s->cnx, entry->stream_id, 1);
                return 1;
            }
            rr = aiopquic_wt_reset_stream_reliable(s->cnx, st, code,
                                                   preamble, reliable);
        }
        if (rr == 0) {
            aiopquic_stream_ctx_tx_abandon(sc);
        }
        aiopquic_wt_stream_reattach(s->cnx, st);
        return 1;
    }

    case SPSC_EVT_TX_MARK_WT_DATAGRAM_READY: {
        /* WT twin of MARK_DATAGRAM_READY: the ring hangs off the
         * session — h3zero pulls from it in provide_datagram — and the
         * scheduler is armed per control stream, not per connection.
         * db is alive: Python's release queues behind this event. */
        aiopquic_dgram_buf_t* db =
            (aiopquic_dgram_buf_t*)(uintptr_t)entry->error_code;
        if (!s || !s->cnx || !db) return 1;
        if (s->dgram_ring != db) {
            if (s->dgram_ring) aiopquic_dgram_buf_unref(s->dgram_ring);
            aiopquic_dgram_buf_addref(db);
            s->dgram_ring = db;
        }
        int armed = h3zero_set_datagram_ready(s->cnx, s->control_stream_id);
        if (aiopquic_wt_diag_enabled()) {
            fprintf(stderr, "[wt-diag] mark_wt_dgram ready sid=%llu ret=%d\n",
                    (unsigned long long)s->control_stream_id, armed);
            fflush(stderr);
        }
        return 1;
    }

    case SPSC_EVT_TX_WT_SET_STREAM_PRIORITY: {
        /* WT events are dispatched ahead of the raw stale-cnx guard, so
         * this is the only place a dead WT session is counted. */
        if (!s || !s->cnx) {
            ctx->cnt_tx_event_dropped_dead_cnx++;
            return 1;
        }
        int pri_ret = picoquic_set_stream_priority(
            s->cnx, entry->stream_id, (uint8_t)entry->error_code);
        if (pri_ret == 0) {
            ctx->worker_set_priority_applied++;
        } else {
            ctx->worker_set_priority_rejected++;
            ctx->worker_set_priority_last_err = (uint64_t)pri_ret;
        }
        return 1;
    }

    case SPSC_EVT_TX_WT_SET_DATAGRAM_PRIORITY: {
        if (!s || !s->cnx) {
            ctx->cnt_tx_event_dropped_dead_cnx++;
            return 1;
        }
        picoquic_set_datagram_priority(s->cnx, (uint8_t)entry->error_code);
        ctx->worker_set_dgram_priority_applied++;
        return 1;
    }

    case SPSC_EVT_TX_WT_STOP_SENDING: {
        if (!s || !s->cnx) return 1;
        if (aiopquic_stream_can_receive(s->cnx, entry->stream_id)) {
            picoquic_stop_sending(s->cnx, entry->stream_id,
                                   aiopquic_wt_code_to_h3(entry->error_code));
            h3zero_callback_ctx_t* h3_ctx =
                (h3zero_callback_ctx_t*)picoquic_get_callback_context(s->cnx);
            h3zero_stream_ctx_t* st =
                h3_ctx ? h3zero_find_stream(h3_ctx, entry->stream_id) : NULL;
            if (st) aiopquic_wt_stream_reattach(s->cnx, st);
        } else {
            ctx->cnt_tx_wrong_direction_dropped++;
        }
        return 1;
    }

    case SPSC_EVT_TX_WT_SESSION_CLEANUP: {
        /* Terminate this session's streams and release their per-stream
         * wt_links, without tearing down the session itself. Mirrors
         * step 1 of TX_WT_DEREGISTER. The session object survives so
         * the Python wrapper's __dealloc__ can later push
         * TX_WT_DEREGISTER for full teardown.
         *
         * One event covers N streams: the splay tree is the
         * authoritative per-session stream set, so this walk sends the
         * §6 resets and stop-sendings, each only in a direction the
         * stream has, and releases the links in one SPSC slot rather
         * than N. A stalled cnx may never flush them; queueing them
         * costs nothing.
         *
         * Links go through LINK_RELEASE, never an inline destroy: data
         * events still queued for the stream hold its borrowed sc, and
         * drain_rx must consume them before the sc is freed.
         *
         * Idempotent: a released stream's path_callback_ctx is NULL, so
         * a later walk skips it. */
        if (s && s->cnx && s->h3_ctx) {
            picosplay_node_t* node =
                picosplay_first(&s->h3_ctx->h3_stream_tree);
            while (node != NULL) {
                h3zero_stream_ctx_t* st =
                    (h3zero_stream_ctx_t*)picohttp_stream_node_value(node);
                picosplay_node_t* next = picosplay_next(node);
                if (st != NULL && st->path_callback_ctx != NULL) {
                    uint32_t kind = *(uint32_t*)st->path_callback_ctx;
                    if (kind == AIOPQUIC_WT_CTX_LINK) {
                        aiopquic_wt_stream_link_t* lk =
                            (aiopquic_wt_stream_link_t*)
                                st->path_callback_ctx;
                        if (lk->session == s) {
                            /* §6: reset the send side and abort reading on
                             * the receive side of every stream in the
                             * session, with WT_SESSION_GONE; a uni stream
                             * has only one side. picowt_deregister would
                             * reset with code 0 and never stop reading. */
                            if (aiopquic_stream_can_send(s->cnx, st->stream_id)) {
                                (void)aiopquic_wt_reset_stream(
                                    s->cnx, st, AIOPQUIC_WT_SESSION_GONE);
                            }
                            if (aiopquic_stream_can_receive(s->cnx, st->stream_id)) {
                                picoquic_stop_sending(s->cnx, st->stream_id,
                                                      AIOPQUIC_WT_SESSION_GONE);
                            }
                            aiopquic_wt_stream_reattach(s->cnx, st);
                            st->path_callback = NULL;
                            st->path_callback_ctx = NULL;
                            aiopquic_stream_ctx_tx_abandon(lk->sc);
                            aiopquic_wt_push_link_release(s, st->stream_id, lk);
                        }
                    }
                }
                node = next;
            }
        }
        if (s) {
            s->cleanup_done = 1;
            aiopquic_wt_maybe_close_cnx(s, s->cnx);
        }
        return 1;
    }

    case SPSC_EVT_TX_WT_DEREGISTER: {
        /* Python is releasing this session. Cleanup has three steps
         * that MUST happen in order, all on the worker thread:
         *
         * 1. Walk h3zero's splay tree and release any per-stream links
         *    that belong to THIS session, via LINK_RELEASE so queued
         *    data events holding the borrowed sc are consumed first.
         *    This must precede picowt_deregister, which nulls each
         *    data stream's path_callback_ctx before deleting the
         *    h3zero stream_ctx — picohttp_callback_free is then NOT
         *    dispatched for our streams, and our link+sc would be
         *    orphaned. The kind discriminator + session pointer check
         *    ensures we only release our own.
         *
         * 2. Null the control stream's path_callback / _ctx. picowt_
         *    deregister does NOT touch the control stream's callback;
         *    h3zero will delete the control stream node later when
         *    the cnx closes and fire picohttp_callback_free on it.
         *    By then `s` is freed — that callback would UAF. Nulling
         *    path_callback makes h3zero skip dispatching to us.
         *
         * 3. Now picowt_deregister + session_destroy can run safely.
         *
         * Done at session-destroy time only (once per session). No
         * per-stream tracking overhead during active operation. */
        if (s) {
            if (s->cnx && s->h3_ctx && aiopquic_cnx_is_alive(quic, s->cnx)) {
                /* Step 1: free this session's per-stream links. */
                picosplay_node_t* node =
                    picosplay_first(&s->h3_ctx->h3_stream_tree);
                while (node != NULL) {
                    h3zero_stream_ctx_t* st =
                        (h3zero_stream_ctx_t*)picohttp_stream_node_value(node);
                    picosplay_node_t* next = picosplay_next(node);
                    if (st != NULL && st->path_callback_ctx != NULL) {
                        uint32_t kind = *(uint32_t*)st->path_callback_ctx;
                        if (kind == AIOPQUIC_WT_CTX_LINK) {
                            aiopquic_wt_stream_link_t* lk =
                                (aiopquic_wt_stream_link_t*)
                                    st->path_callback_ctx;
                            if (lk->session == s) {
                                st->path_callback = NULL;
                                st->path_callback_ctx = NULL;
                                aiopquic_stream_ctx_tx_abandon(lk->sc);
                                aiopquic_wt_push_link_release(
                                    s, st->stream_id, lk);
                            }
                        }
                    }
                    node = next;
                }
                /* Steps 2 and 3 need CONNECT, which h3zero may have
                 * freed already. Step 2: detach its callback so the
                 * eventual picohttp_callback_free at cnx-close doesn't
                 * dispatch into a freed session pointer. */
                if (s->control_stream) {
                    s->control_stream->path_callback = NULL;
                    s->control_stream->path_callback_ctx = NULL;
                    /* Step 3: now safe to deregister + free. */
                    picowt_deregister(s->cnx, s->h3_ctx, s->control_stream);
                }
                if (picoquic_is_client(s->cnx)) {
                    if (s->fin_sent) {
                        picoquic_close(s->cnx, H3ZERO_NO_ERROR);
                    }
                    picoquic_set_callback(s->cnx, h3zero_callback, s->h3_ctx);
                }
                /* The stream prefix names this session; h3zero would hand
                 * it a deregister at context deletion, after the free.
                 * Deleting it re-enters our deregister case: no
                 * SESSION_CLOSED for a session Python has released. */
                s->session_closing = 1;
                h3zero_delete_stream_prefix(s->cnx, s->h3_ctx,
                                            s->control_stream_id);
            }
            aiopquic_wt_session_destroy(s);
        }
        return 1;
    }

    default:
        return 0;
    }
}

/*
 * Single-port dual-stack dispatch: the quic ctx's default callback when
 * raw QUIC and h3/WebTransport share one UDP port. Each connection is
 * routed exactly once by its negotiated ALPN: "h3" bootstraps the
 * h3zero stack the same way h3zero_callback's own default branch would
 * (per-cnx ctx from the shared server parameters — that branch is
 * unreachable here because the quic default ctx is the bridge, not the
 * params); anything else re-points to the raw aiopquic bridge. ALPN is
 * selected during ClientHello processing, so it is available from the
 * first connection callback; NULL means an event predates negotiation —
 * ignore it and let the next event re-enter.
 */

/* Tell the asyncio side which stack owns this connection, with a snapshot
 * of its state, ahead of the connection's first routed event, so asyncio
 * never reads picoquic state itself. */
static void aiopquic_dispatch_announce(aiopquic_ctx_t* bridge,
                                       picoquic_cnx_t* cnx, int is_h3) {
    aiopquic_cnx_snapshot_t snap;
    aiopquic_cnx_snapshot_fill(cnx, &snap);
    spsc_entry_t entry = {0};
    entry.event_type = SPSC_EVT_CNX_STACK;
    entry.cnx = cnx;
    entry.is_fin = (uint8_t)(is_h3 ? 1 : 0);
    (void)aiopquic_rx_push(bridge, &entry, (const uint8_t*)&snap, sizeof(snap));
}

/* Default callback of a WebTransport-only server: like h3zero's own
 * first-contact path, create the per-cnx H3 context, but install our
 * wrapper so connection-level events reach the sessions. */
static int aiopquic_wt_server_bootstrap_cb(picoquic_cnx_t* cnx, uint64_t stream_id,
    uint8_t* bytes, size_t length, picoquic_call_back_event_t event,
    void* callback_ctx, void* v_stream_ctx)
{
    h3zero_callback_ctx_t* hctx = h3zero_callback_create_context(
        (picohttp_server_parameters_t*)callback_ctx);
    if (hctx == NULL) {
        picoquic_close(cnx, PICOQUIC_ERROR_MEMORY);
        return -1;
    }
    picoquic_set_callback(cnx, aiopquic_wt_cnx_cb, hctx);
    int ret = h3zero_protocol_init_safe(cnx, hctx);
    if (ret != 0) {
        return ret;
    }
    return aiopquic_wt_cnx_cb(cnx, stream_id, bytes, length,
                              event, hctx, v_stream_ctx);
}

static int aiopquic_dispatch_cb(picoquic_cnx_t* cnx, uint64_t stream_id,
    uint8_t* bytes, size_t length, picoquic_call_back_event_t event,
    void* callback_ctx, void* v_stream_ctx)
{
    aiopquic_ctx_t* bridge = (aiopquic_ctx_t*)callback_ctx;
    const char* alpn = picoquic_tls_get_negotiated_alpn(cnx);
    if (alpn == NULL) {
        return 0;
    }
    if (bridge->dual_wt_params != NULL && strcmp(alpn, "h3") == 0) {
        h3zero_callback_ctx_t* hctx = h3zero_callback_create_context(
            (picohttp_server_parameters_t*)bridge->dual_wt_params);
        if (hctx == NULL) {
            picoquic_close(cnx, PICOQUIC_ERROR_MEMORY);
            return -1;
        }
        picoquic_set_callback(cnx, aiopquic_wt_cnx_cb, hctx);
        int ret = h3zero_protocol_init_safe(cnx, hctx);
        if (ret != 0) {
            return ret;
        }
        aiopquic_dispatch_announce(bridge, cnx, 1);
        return aiopquic_wt_cnx_cb(cnx, stream_id, bytes, length,
                               event, hctx, v_stream_ctx);
    }
    picoquic_set_callback(cnx, aiopquic_stream_cb, bridge);
    aiopquic_dispatch_announce(bridge, cnx, 0);
    return aiopquic_stream_cb(cnx, stream_id, bytes, length,
                              event, bridge, v_stream_ctx);
}

#ifdef __cplusplus
}
#endif

#endif /* AIOPQUIC_H3WT_CALLBACK_H */
