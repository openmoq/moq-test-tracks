# cython: language_level=3
"""
_transport — Cython bridge between picoquic (C) and Python asyncio.

Manages the picoquic context lifecycle, SPSC ring buffers,
and the dedicated network thread.

Note: free-threaded Python (cp314t) is not yet supported. The TX-ring
producer side, TransportContext lifecycle fields, and the WebTransport
session/engine state currently rely on the GIL for serialization;
running under a no-GIL build risks ring corruption and use-after-free.
Re-enable freethreading_compatible once the per-context locking audit
covers TX entry points and the WT TX dispatch path.
"""

import errno as _errno
import logging as _logging
import os
import socket as _socket
import sys

cimport cython
from cpython.buffer cimport PyBuffer_FillInfo
from cpython.bytes cimport PyBytes_AsString, PyBytes_FromStringAndSize
from libc.stdint cimport uint8_t, uint16_t, uint32_t, uint64_t, int64_t, uintptr_t
from libc.stdlib cimport free, malloc, realloc
from libc.string cimport memcpy, memset

from aiopquic._binding.spsc_ring cimport (
    spsc_ring_t, spsc_ring_create, spsc_ring_destroy,
    spsc_ring_count,
    spsc_ring_empty, spsc_ring_peek,
    spsc_ring_entry_data, spsc_ring_pop, spsc_ring_push,
    spsc_ring_take_data,
    spsc_entry_t,
    SPSC_EVT_STREAM_DATA, SPSC_EVT_STREAM_FIN,
    SPSC_EVT_STREAM_TX_DRAINED,
    SPSC_EVT_STREAM_DESTROY,
    SPSC_EVT_WT_STREAM_DESTROY,
    SPSC_EVT_STREAM_RESET, SPSC_EVT_STOP_SENDING,
    SPSC_EVT_CLOSE, SPSC_EVT_APP_CLOSE,
    SPSC_EVT_READY, SPSC_EVT_ALMOST_READY,
    SPSC_EVT_DATAGRAM,
    SPSC_EVT_WT_STREAM_DATA, SPSC_EVT_WT_STREAM_FIN,
    SPSC_EVT_WT_STREAM_LINK_RELEASE,
    SPSC_EVT_TX_EVENT_RING_DRAINED,
    SPSC_EVT_TX_CLOSE,
    SPSC_EVT_TX_MARK_ACTIVE, SPSC_EVT_TX_CONNECT,
    SPSC_EVT_TX_WT_OPEN, SPSC_EVT_TX_WT_CREATE_STREAM,
    AIOPQUIC_WT_CREATE_BIDIR, AIOPQUIC_WT_CREATE_FIN,
    SPSC_EVT_TX_WT_CLOSE, SPSC_EVT_TX_WT_DRAIN, SPSC_EVT_TX_WT_FIN,
    SPSC_EVT_TX_WT_RESET_STREAM, SPSC_EVT_TX_WT_DEREGISTER,
    SPSC_EVT_TX_WT_STOP_SENDING,
    SPSC_EVT_TX_OPEN_FLOW_CONTROL,
    SPSC_EVT_TX_SET_APP_FLOW_CONTROL,
    SPSC_EVT_TX_WT_SESSION_CLEANUP,
    SPSC_EVT_TX_MARK_DATAGRAM_READY,
    SPSC_EVT_TX_MARK_WT_DATAGRAM_READY,
    SPSC_EVT_TX_SET_STREAM_PRIORITY,
    SPSC_EVT_TX_WT_SET_STREAM_PRIORITY,
    SPSC_EVT_TX_SET_DATAGRAM_PRIORITY,
    SPSC_EVT_TX_WT_SET_DATAGRAM_PRIORITY,
    SPSC_EVT_TX_SET_MAX_CONNECTIONS,
    SPSC_EVT_DATAGRAM_TX_DRAINED,
    SPSC_EVT_TX_CNX_REFRESH,
    SPSC_EVT_CNX_STACK, SPSC_EVT_CNX_SNAPSHOT,
    SPSC_EVT_WT_SESSION_READY,
    SPSC_EVT_WT_SESSION_REFUSED, SPSC_EVT_WT_SESSION_CLOSED,
)

# Socket address helpers (needed by picoquic declarations)
cdef extern from "<sys/socket.h>":
    enum: AF_INET
    enum: AF_INET6
    cdef struct sockaddr:
        unsigned short sa_family
    cdef struct sockaddr_storage:
        unsigned short ss_family

cdef extern from "<netinet/in.h>":
    cdef struct sockaddr_in:
        unsigned short sin_family
        unsigned short sin_port
        unsigned int sin_addr
    cdef struct in6_addr:
        pass
    cdef struct sockaddr_in6:
        unsigned short sin6_family
        unsigned short sin6_port
        in6_addr sin6_addr
        unsigned int sin6_scope_id
    unsigned short htons(unsigned short hostshort)

cdef extern from "<arpa/inet.h>":
    int inet_pton(int af, const char* src, void* dst)

# picoquic declarations
cdef extern from "picoquic.h":
    ctypedef struct picoquic_quic_t:
        pass
    void picoquic_set_default_priority(picoquic_quic_t* quic,
                                       uint8_t default_stream_priority)
    void picoquic_set_default_datagram_priority(picoquic_quic_t* quic,
                                                uint8_t default_datagram_priority)
    ctypedef struct picoquic_cnx_t:
        pass

    ctypedef int (*picoquic_stream_data_cb_fn)(
        picoquic_cnx_t* cnx, uint64_t stream_id,
        uint8_t* bytes, size_t length,
        int fin_or_event, void* callback_ctx, void* stream_ctx)

    ctypedef void (*picoquic_connection_id_cb_fn)(
        picoquic_quic_t* quic, void* cnx_id_local,
        void* cnx_id_remote, void* cnx_id_cb_data,
        void* cnx_id_returned)

    picoquic_quic_t* picoquic_create(
        uint32_t max_nb_connections,
        const char* cert_file_name, const char* key_file_name,
        const char* cert_root_file_name, const char* default_alpn,
        picoquic_stream_data_cb_fn default_callback_fn,
        void* default_callback_ctx,
        picoquic_connection_id_cb_fn cnx_id_callback,
        void* cnx_id_callback_data,
        uint8_t* reset_seed, uint64_t current_time,
        uint64_t* p_simulated_time,
        const char* ticket_file_name,
        const uint8_t* ticket_encryption_key,
        size_t ticket_encryption_key_length)

    int picoquic_set_default_congestion_algorithm_by_name(
        picoquic_quic_t* quic, const char* alg_name)
    void picoquic_set_default_congestion_algorithm_ex(
        picoquic_quic_t* quic, const void* alg, const char* alg_option_string)
    void picoquic_set_packet_train_mode(picoquic_quic_t* quic, int train_mode)

    void picoquic_register_all_congestion_control_algorithms()
    const void* picoquic_get_congestion_algorithm(const char* alg_name)

    void picoquic_free(picoquic_quic_t* quic)
    uint64_t picoquic_current_time()
    void picoquic_set_null_verifier(picoquic_quic_t* quic)
    void picoquic_set_default_idle_timeout(picoquic_quic_t* quic, uint64_t idle_timeout_ms)
    void picoquic_set_max_data_control(picoquic_quic_t* quic, uint64_t max_data)
    void picoquic_set_cookie_mode(picoquic_quic_t* quic, int cookie_mode)
    ctypedef enum picoquic_pmtud_policy_enum:
        picoquic_pmtud_basic
        picoquic_pmtud_required
        picoquic_pmtud_delayed
        picoquic_pmtud_blocked
    void picoquic_set_default_pmtud_policy(picoquic_quic_t* quic,
                                           picoquic_pmtud_policy_enum pmtud_policy)
    int picoquic_set_cipher_suite(picoquic_quic_t* quic, int cipher_suite_id)
    void picoquic_set_default_crypto_epoch_length(picoquic_quic_t* quic,
                                                  uint64_t crypto_epoch_length_max)
    int picoquic_save_session_tickets(picoquic_quic_t* quic, const char* ticket_store_filename)
    void picoquic_set_log_level(picoquic_quic_t* quic, int log_level)
    void picoquic_enable_sslkeylog(picoquic_quic_t* quic, int enable)
    void picoquic_set_key_log_file(picoquic_quic_t* quic,
                                    const char* keylog_filename)
    void picoquic_set_callback(picoquic_cnx_t* cnx,
        picoquic_stream_data_cb_fn callback_fn, void* callback_ctx)

# picoquic_logger.h transitively pulls picoquic_unified_log.h which
# uses internal-only types. Declare the prototype directly so Cython
# emits a forward declaration rather than including the header.
cdef extern from *:
    """
    int picoquic_set_textlog(picoquic_quic_t* quic, const char* textlog_file);
    int picoquic_set_qlog(picoquic_quic_t* quic, const char* qlog_dir);
    """
    int picoquic_set_textlog(picoquic_quic_t* quic, const char* textlog_file)
    int picoquic_set_qlog(picoquic_quic_t* quic, const char* qlog_dir)

    ctypedef struct picoquic_tp_t:
        uint64_t initial_max_stream_data_bidi_local
        uint64_t initial_max_stream_data_bidi_remote
        uint64_t initial_max_stream_data_uni
        uint64_t initial_max_data
        uint64_t initial_max_stream_id_bidir
        uint64_t initial_max_stream_id_unidir
        uint64_t max_idle_timeout
        uint32_t max_packet_size
        uint32_t max_ack_delay
        uint32_t active_connection_id_limit
        uint8_t ack_delay_exponent
        unsigned int migration_disabled
        uint32_t max_datagram_frame_size
        int enable_loss_bit
        int is_reset_stream_at_enabled
        int enable_time_stamp
        uint64_t min_ack_delay
        int do_grease_quic_bit
        int enable_bdp_frame
        int is_multipath_enabled
        uint64_t initial_max_path_id

    int picoquic_set_default_tp(picoquic_quic_t* quic, picoquic_tp_t* tp)
    const picoquic_tp_t* picoquic_get_default_tp(picoquic_quic_t* quic)
    const picoquic_tp_t* picoquic_get_transport_parameters(
        picoquic_cnx_t* cnx, int get_local)

    ctypedef struct picoquic_connection_id_t:
        uint8_t id[20]
        uint8_t id_len

    picoquic_connection_id_t picoquic_get_local_cnxid(picoquic_cnx_t* cnx)
    picoquic_connection_id_t picoquic_get_remote_cnxid(picoquic_cnx_t* cnx)
    picoquic_connection_id_t picoquic_get_initial_cnxid(picoquic_cnx_t* cnx)

    picoquic_cnx_t* picoquic_create_client_cnx(
        picoquic_quic_t* quic, sockaddr* addr,
        uint64_t start_time, uint32_t preferred_version,
        const char* sni, const char* alpn,
        picoquic_stream_data_cb_fn callback_fn,
        void* callback_ctx)
    int picoquic_start_client_cnx(picoquic_cnx_t* cnx)
    int picoquic_close(picoquic_cnx_t* cnx, uint64_t reason)
    int picoquic_get_cnx_state(picoquic_cnx_t* cnx)
    const char* picoquic_tls_get_negotiated_alpn(picoquic_cnx_t* cnx)
    # Multi-ALPN negotiation. The select fn fires server-side only when
    # default_alpn is NULL; get_default_callback_context lets it reach the
    # bridge from just the quic ctx. add_proposed_alpn is called from the
    # client request_alpn_list callback to build the ClientHello offer.
    ctypedef struct picoquic_iovec_t:
        uint8_t* base
        size_t len
    ctypedef size_t (*picoquic_alpn_select_fn_v2)(
        picoquic_quic_t* quic, picoquic_iovec_t* list, size_t count)
    void picoquic_set_alpn_select_fn_v2(
        picoquic_quic_t* quic, picoquic_alpn_select_fn_v2 fn)
    void* picoquic_get_default_callback_context(picoquic_quic_t* quic)
    int picoquic_add_proposed_alpn(void* tls_context, const char* alpn)
    uint64_t picoquic_get_data_sent(picoquic_cnx_t* cnx)
    uint64_t picoquic_get_data_received(picoquic_cnx_t* cnx)

    # Path quality snapshot — the load-bearing CC/FC observability
    # primitive. Fields documented in picoquic.h ~ line 1129.
    ctypedef struct picoquic_path_quality_t:
        uint64_t receive_rate_estimate    # bytes/sec
        uint64_t pacing_rate              # bytes/sec
        uint64_t cwin                     # cwnd bytes
        uint64_t rtt                      # smoothed RTT us
        uint64_t rtt_sample               # latest sample us
        uint64_t rtt_variant              # RTT variability us
        uint64_t rtt_min
        uint64_t rtt_max
        uint64_t sent                     # packets sent
        uint64_t lost                     # packets considered lost
        uint64_t timer_losses             # losses from timer expiry
        uint64_t spurious_losses          # later-acked
        uint64_t max_spurious_rtt
        uint64_t max_reorder_delay
        uint64_t max_reorder_gap
        uint64_t bytes_in_transit         # in-flight bytes
        uint64_t bytes_sent
        uint64_t bytes_received
    void picoquic_get_default_path_quality(
        picoquic_cnx_t* cnx, picoquic_path_quality_t* quality)

cdef extern from "tls_api.h":
    void picoquic_sort_key_exchange_algorithms(
        uint16_t* ordered_key_exchange, size_t nb_ordered_key_exchange)

cdef extern from "picoquic_packet_loop.h":
    ctypedef struct picoquic_packet_loop_param_t:
        unsigned short local_port
        int local_af
        int dest_if
        unsigned short public_port
        int is_port_shared
        int socket_buffer_size
        int do_not_use_gso
        int extra_socket_required
        int prefer_extra_socket
        int simulate_eio
        size_t send_length_max
        sockaddr_storage local_addr[2]

    ctypedef int (*picoquic_packet_loop_cb_fn)(
        picoquic_quic_t* quic, int cb_mode,
        void* callback_ctx, void* callback_argv)

    ctypedef struct picoquic_network_thread_ctx_t:
        picoquic_quic_t* quic
        int thread_is_ready
        int thread_should_close
        int thread_is_closed
        int return_code

    picoquic_network_thread_ctx_t* picoquic_start_network_thread(
        picoquic_quic_t* quic,
        picoquic_packet_loop_param_t* param,
        picoquic_packet_loop_cb_fn loop_callback,
        void* loop_callback_ctx,
        int* ret)
    int picoquic_wake_up_network_thread(picoquic_network_thread_ctx_t* thread_ctx)
    void picoquic_delete_network_thread(picoquic_network_thread_ctx_t* thread_ctx)

# C callback declarations
cdef extern from "c/spsc_ring.h":
    ctypedef struct spsc_overflow_t:
        uint64_t depth
        uint64_t pushed
        uint64_t max_depth
    uint32_t spsc_ring_refill_from_overflow(spsc_ring_t* ring,
                                            spsc_overflow_t* ovf)

cdef extern from "c/callback.h":
    ctypedef struct aiopquic_connect_params_t:
        sockaddr_storage addr
        uint32_t desired_version
        uint16_t sni_len
        uint16_t alpn_len

cdef extern from "c/callback.h":
    ctypedef struct aiopquic_wake_trace_entry_t:
        uint64_t ts_ns
        uint32_t kind
        uint32_t a
        uint64_t b
    ctypedef struct aiopquic_wake_trace_t:
        uint64_t next
        aiopquic_wake_trace_entry_t e[128]
    enum:
        AIOPQUIC_WAKE_TRACE_LEN
        AIOPQUIC_WAKE_DRAIN

cdef extern from "c/callback.h":
    # Resource defaults — single source of truth in callback.h.
    enum:
        AIOPQUIC_RX_DATA_RING_CAP_DEFAULT
        AIOPQUIC_TX_DATA_RING_CAP_DEFAULT
        AIOPQUIC_SPSC_RING_CAPACITY_DEFAULT
        AIOPQUIC_TX_EVENT_RING_CAP_DEFAULT
        AIOPQUIC_RX_EVENT_RING_CAP_DEFAULT
        AIOPQUIC_TX_RING_WAKE_PCT_DEFAULT

    ctypedef struct aiopquic_dgram_table_t:
        uint32_t live

    ctypedef struct aiopquic_ctx_t:
        spsc_ring_t* rx_event_ring
        spsc_ring_t* tx_event_ring
        spsc_overflow_t rx_overflow
        int eventfd
        picoquic_quic_t* quic
        picoquic_network_thread_ctx_t* thread_ctx
        uint32_t rx_data_ring_cap
        uint64_t keep_alive_us
        char* wt_supported_protocols
        void* dual_wt_params
        uint64_t worker_mark_active_processed
        uint64_t worker_prepare_to_send_calls
        uint64_t worker_prepare_to_send_pulled_bytes
        uint64_t worker_rx_event_drops
        uint64_t worker_rx_event_drops_stream_data
        uint64_t worker_dgram_mark_ready_processed
        uint64_t worker_dgram_prepare_calls
        uint64_t worker_dgram_records_sent
        uint64_t worker_dgram_bytes_sent
        aiopquic_dgram_table_t dgram_table
        uint32_t dgram_release_owed_n
        uint64_t worker_dgram_ring_release_processed
        uint64_t cnt_rx_data_event_coalesced
        uint64_t worker_rx_byte_ring_overflow
        uint32_t rx_notify_pending
        uint64_t cnt_rx_notify_flips
        uint64_t cnt_rx_notify_skips
        uint64_t cnt_rx_notify_write_errs
        int last_rx_notify_errno
        uint64_t cnt_rx_clears
        uint64_t cnt_rx_clear_read_empty
        uint64_t cnt_rx_rearms
        aiopquic_wake_trace_t worker_trace
        aiopquic_wake_trace_t asyncio_trace
        uint32_t tx_worker_idle
        uint32_t tx_event_ring_drain_pending
        uint32_t tx_event_ring_low_water
        # Observability counters (added without behavior change).
        uint64_t cnt_tx_event_ring_pushes
        uint64_t cnt_tx_event_ring_pops
        uint64_t cnt_tx_event_ring_arms
        uint64_t cnt_tx_event_ring_fires
        uint64_t cnt_tx_event_ring_fire_dropped
        uint64_t cnt_wake_calls
        uint64_t cnt_wake_skipped_coalesced
        uint64_t cnt_tx_wake_lost
        uint64_t cnt_prepare_to_send_empty
        uint64_t cnt_loop_cb
        uint64_t worker_set_priority_applied
        uint64_t worker_set_priority_rejected
        uint64_t worker_set_priority_last_err
        uint64_t worker_set_dgram_priority_applied
        uint64_t cnt_tx_event_dropped_dead_cnx
        uint64_t cnt_tx_wrong_direction_dropped
        uint64_t cnt_tx_reattach_after_close
        uint64_t cnt_stream_cb_after_close
        uint64_t last_tx_event_ring_arm_ns
        uint64_t last_tx_event_ring_fire_ns
        uint64_t cnt_fc_credit_pushed
        uint64_t cnt_fc_credit_handled
        uint64_t cnt_fc_credit_dropped
        uint64_t cnt_wt_callback_free_skipped
        uint64_t cnt_sc_create_raw_quic
        uint64_t cnt_sc_create_wt_link
        uint64_t cnt_sc_ref_fc_credit
        uint64_t cnt_sc_destroy_wt_link_callback_free
        uint64_t cnt_sc_destroy_wt_link_close_walker
        uint64_t cnt_sc_destroy_fc_credit_pushfail
        uint64_t cnt_sc_destroy_fc_credit_worker
        uint64_t cnt_sc_destroy_fc_credit_dead_cnx
        uint64_t cnt_wt_control_released
        uint64_t cnt_cnx_live_walks
        uint8_t live_cnxs_hooked
        uint64_t cnt_tx_park_kept_active
        uint64_t cnt_tx_mark_active_skipped

    aiopquic_ctx_t* aiopquic_ctx_create(uint32_t tx_cap,
                                          uint32_t rx_cap,
                                          uint32_t low_water_pct)
    void aiopquic_ctx_destroy(aiopquic_ctx_t* ctx)
    void aiopquic_live_cnx_attach(aiopquic_ctx_t* ctx, picoquic_quic_t* quic)
    void aiopquic_clear_rx(aiopquic_ctx_t* ctx)
    uint64_t aiopquic_rx_consumed(aiopquic_ctx_t* ctx)
    void aiopquic_wake_trace_add(aiopquic_wake_trace_t* t, uint32_t kind,
                                 uint32_t a, uint64_t b)
    uint64_t aiopquic_wake_trace_next(aiopquic_wake_trace_t* t)
    void aiopquic_notify_rx(aiopquic_ctx_t* ctx)
    int aiopquic_tx_wake_needed(aiopquic_ctx_t* ctx)
    int aiopquic_arm_tx_event_ring_drain_pending(aiopquic_ctx_t* ctx)
    void aiopquic_clear_tx_event_ring_drain_pending(aiopquic_ctx_t* ctx)
    void aiopquic_push_fc_credit(aiopquic_ctx_t* ctx, void* cnx,
                                  uint64_t stream_id,
                                  void* sc)

    int aiopquic_stream_cb(picoquic_cnx_t* cnx, uint64_t stream_id,
                            uint8_t* bytes, size_t length,
                            int fin_or_event,
                            void* callback_ctx, void* stream_ctx)
    int aiopquic_loop_cb(picoquic_quic_t* quic, int cb_mode,
                          void* callback_ctx, void* callback_argv)
    size_t aiopquic_alpn_select_cb(picoquic_quic_t* quic,
                                    picoquic_iovec_t* list, size_t count)
    void aiopquic_ctx_set_alpn_list(aiopquic_ctx_t* ctx, const char* csv)

    # picoquic-side audit loaders (defined in third_party/picoquic/
    # picoquic/frames.c). Forward-declared in callback.h above.


# Per-stream byte ring (PULL-model send path). Allocated by Python,
# owned by Python (refcount-style); picoquic-pthread reads from it via
# stream_ctx in aiopquic_stream_cb.
cdef extern from "c/callback.h":
    ctypedef struct aiopquic_addr_t:
        uint8_t family
        uint16_t port
        uint8_t addr[16]
    ctypedef struct aiopquic_cnx_snapshot_t:
        char alpn[32]
        uint8_t has_tp_local
        uint8_t has_tp_remote
        uint32_t dgram_ceiling
        picoquic_tp_t tp_local
        picoquic_tp_t tp_remote
        picoquic_connection_id_t cid_local
        picoquic_connection_id_t cid_remote
        picoquic_connection_id_t cid_initial
        picoquic_path_quality_t path_quality
        uint64_t data_sent
        uint64_t data_received
        aiopquic_addr_t peer_addr
        aiopquic_addr_t local_addr
        uint8_t session_resumed

cdef extern from "c/stream_buf.h":
    ctypedef struct aiopquic_stream_buf_t:
        pass

    aiopquic_stream_buf_t* aiopquic_stream_buf_create(uint32_t capacity)
    void aiopquic_stream_buf_destroy(aiopquic_stream_buf_t* sb)
    uint32_t aiopquic_ceil_pow2_u32(uint32_t n)
    uint32_t aiopquic_stream_buf_push(
        aiopquic_stream_buf_t* sb,
        const uint8_t* data, uint32_t length)
    uint32_t aiopquic_stream_buf_pop(
        aiopquic_stream_buf_t* sb,
        uint8_t* out, uint32_t max_bytes)
    uint32_t aiopquic_stream_buf_used(aiopquic_stream_buf_t* sb)
    uint32_t aiopquic_stream_buf_free(aiopquic_stream_buf_t* sb)
    void aiopquic_stream_buf_set_fin(aiopquic_stream_buf_t* sb)
    int aiopquic_stream_buf_fin_pending(aiopquic_stream_buf_t* sb)
    uint64_t aiopquic_stream_buf_pushed(aiopquic_stream_buf_t* sb)
    uint64_t aiopquic_stream_buf_popped(aiopquic_stream_buf_t* sb)
    uint64_t aiopquic_stream_buf_sent(aiopquic_stream_buf_t* sb)
    uint32_t aiopquic_stream_buf_push_hash(aiopquic_stream_buf_t* sb)
    uint32_t aiopquic_stream_buf_pop_hash(aiopquic_stream_buf_t* sb)


# Per-connection datagram TX record ring — pull-model datagram send.
# Producer: dgram_send (this thread). Consumer: picoquic worker in
# prepare_datagram. Refcounted; the Python connection and the worker's
# cnx→ring table each hold one reference.
cdef extern from "c/datagram_buf.h":
    ctypedef struct aiopquic_dgram_buf_t:
        uint32_t capacity
        uint32_t max_record
        uint64_t records_pushed
        uint64_t push_full
        uint64_t push_oversize
        uint64_t records_popped
        uint64_t bytes_popped
        uint64_t head_deferred

    aiopquic_dgram_buf_t* aiopquic_dgram_buf_create(
        uint32_t capacity, uint32_t max_record)
    void aiopquic_dgram_buf_addref(aiopquic_dgram_buf_t* db)
    void aiopquic_dgram_buf_unref(aiopquic_dgram_buf_t* db)
    int aiopquic_dgram_buf_push_record(
        aiopquic_dgram_buf_t* db, const uint8_t* data, uint32_t length)
    uint32_t aiopquic_dgram_buf_used(aiopquic_dgram_buf_t* db)
    int64_t aiopquic_dgram_rings_alive_load()

cdef extern from "c/callback.h":
    void aiopquic_dgram_ring_release(aiopquic_ctx_t* ctx, void* cnx,
                                     aiopquic_dgram_buf_t* db)
    void aiopquic_dgram_ring_release_flush(aiopquic_ctx_t* ctx)
    void aiopquic_dgram_ring_release_undrained(aiopquic_ctx_t* ctx)
    void aiopquic_rx_event_release(const spsc_entry_t* e)
    int aiopquic_rx_event_owns_sc(uint32_t event_type)
    int aiopquic_rx_push_sc(aiopquic_ctx_t* ctx, const spsc_entry_t* entry,
                            const uint8_t* data, uint32_t data_len)
    int aiopquic_tx_push_sc(aiopquic_ctx_t* ctx, const spsc_entry_t* entry,
                            const uint8_t* data, uint32_t data_len)
    void aiopquic_tx_sc_release_undrained(aiopquic_ctx_t* ctx)


# A reference a drain_rx batch holds until it is released: an sc, or a WT
# stream link (whose destroy drops the link's sc reference).
cdef struct batch_ref_t:
    void* ptr
    bint is_link


# Per-stream wrapper holding both TX and RX byte rings + flow-control
# state. Set as picoquic's app_stream_ctx so the same slot serves both
# directions for bidi streams.
cdef extern from "c/stream_ctx.h":
    uint64_t aiopquic_now_ns()
    ctypedef struct aiopquic_stream_ctx_t:
        aiopquic_stream_buf_t* tx
        aiopquic_stream_buf_t* rx
        # Atomic on the C side; Cython sees plain uint64_t and we touch
        # them via aiopquic_stream_ctx_rx_* accessors.
        uint64_t rx_consumed
        uint64_t rx_credit_limit
        # Bytes wrapped in StreamChunk for the Python consumer but
        # whose StreamChunk has not yet been released (last memoryview
        # ref dropped). Atomic on the C side; the worker reads via
        # pending_load() inside the SPSC_EVT_TX_OPEN_FLOW_CONTROL
        # handler to compute the effective MAX_STREAM_DATA grant.
        uint64_t bytes_pending_release
        uint32_t tx_drain_pending
        uint8_t  pending_destroy
        # Observability counters (single-writer; relaxed semantics).
        uint64_t cnt_drain_arms
        uint64_t cnt_drain_fires
        uint64_t cnt_drain_dropped
        uint64_t last_drain_arm_ns
        uint64_t last_drain_fire_ns

    aiopquic_stream_ctx_t* aiopquic_stream_ctx_create()
    int aiopquic_stream_ctx_ensure_tx(aiopquic_stream_ctx_t* sc,
                                      uint32_t capacity)
    int aiopquic_stream_ctx_ensure_rx(aiopquic_stream_ctx_t* sc,
                                      uint32_t capacity)
    void aiopquic_stream_ctx_ref(aiopquic_stream_ctx_t* sc)
    void aiopquic_stream_ctx_destroy(aiopquic_stream_ctx_t* sc)
    uint64_t aiopquic_stream_ctx_rx_consumed_load(aiopquic_stream_ctx_t* sc)
    void aiopquic_stream_ctx_rx_consumed_add(
        aiopquic_stream_ctx_t* sc, uint64_t delta)
    void aiopquic_stream_ctx_pending_add(
        aiopquic_stream_ctx_t* sc, uint64_t n)
    void aiopquic_stream_ctx_pending_sub(
        aiopquic_stream_ctx_t* sc, uint64_t n)
    uint64_t aiopquic_stream_ctx_pending_load(aiopquic_stream_ctx_t* sc)
    uint64_t aiopquic_stream_ctx_last_fc_push_consumed_load(
        aiopquic_stream_ctx_t* sc)
    void aiopquic_stream_ctx_last_fc_push_consumed_store(
        aiopquic_stream_ctx_t* sc, uint64_t v)
    int aiopquic_stream_ctx_rx_event_pending_arm(aiopquic_stream_ctx_t* sc)
    void aiopquic_stream_ctx_rx_event_pending_clear(aiopquic_stream_ctx_t* sc)
    void aiopquic_tx_data_bytes_pushed_add(uint64_t n)
    uint64_t aiopquic_tx_data_bytes_pushed_load()
    uint64_t aiopquic_tx_data_bytes_pulled_load()
    uint64_t aiopquic_tx_data_bytes_discarded_load()
    uint64_t aiopquic_tx_data_bytes_queued()
    int aiopquic_stream_ctx_send_data(
        aiopquic_stream_ctx_t* sc,
        const uint8_t* data, uint32_t length,
        uint32_t capacity, uint8_t set_fin)
    int aiopquic_stream_ctx_tx_arm(aiopquic_stream_ctx_t* sc)
    void aiopquic_stream_ctx_tx_disarm(aiopquic_stream_ctx_t* sc)
    void aiopquic_set_tx_data_drain_pending(
        aiopquic_stream_ctx_t* sc)
    void aiopquic_clear_tx_data_drain_pending(
        aiopquic_stream_ctx_t* sc)
    void aiopquic_chunks_alive_inc()
    void aiopquic_chunks_alive_dec()
    uint64_t aiopquic_cnt_sc_created_load()
    uint64_t aiopquic_cnt_sc_destroyed_load()
    int64_t  aiopquic_cnt_chunks_alive_load()
    void aiopquic_cnt_sc_ref_chunk_wrap_inc()
    void aiopquic_cnt_sc_destroy_chunk_dealloc_inc()
    void aiopquic_cnt_sc_destroy_rx_event_inc()
    void aiopquic_cnt_sc_create_python_helper_inc()
    void aiopquic_cnt_sc_destroy_python_helper_inc()
    uint64_t aiopquic_cnt_sc_ref_chunk_wrap_load()
    uint64_t aiopquic_cnt_sc_destroy_chunk_dealloc_load()
    uint64_t aiopquic_cnt_sc_destroy_rx_event_load()
    uint64_t aiopquic_cnt_sc_create_python_helper_load()
    uint64_t aiopquic_cnt_sc_destroy_python_helper_load()
    void aiopquic_sc_rx_bytes_pushed_add(uint64_t n)
    void aiopquic_sc_rx_bytes_popped_add(uint64_t n)
    uint64_t aiopquic_cnt_sc_rx_bytes_pushed_load()
    uint64_t aiopquic_cnt_sc_rx_bytes_popped_load()


# picoquic flow-control APIs are thread-bound to the picoquic worker
# (PICOQUIC_THREAD_CHECK in sender.c). The asyncio thread cannot call
# them directly. Instead it queues SPSC events
# (SPSC_EVT_TX_OPEN_FLOW_CONTROL, SPSC_EVT_TX_SET_APP_FLOW_CONTROL)
# which the picoquic worker drains and dispatches to the actual
# picoquic_open_flow_control / picoquic_set_app_flow_control calls.
# See aiopquic_loop_cb's TX-ring-drain switch in callback.h.


# H3+WebTransport: opaque types from picoquic; we hold pointers only.
cdef extern from "h3zero_common.h":
    ctypedef struct h3zero_callback_ctx_t:
        pass
    ctypedef struct h3zero_stream_ctx_t:
        uint64_t stream_id
    ctypedef int (*picohttp_post_data_cb_fn)(
        picoquic_cnx_t* cnx, uint8_t* bytes, size_t length,
        int fin_or_event,
        h3zero_stream_ctx_t* stream_ctx, void* path_app_ctx)

    ctypedef struct picohttp_server_path_item_t:
        const char* path
        size_t path_length
        picohttp_post_data_cb_fn path_callback
        void* path_app_ctx
        const char* connect_protocol
        size_t connect_protocol_length

    ctypedef struct picohttp_server_parameters_t:
        const char* web_folder
        picohttp_server_path_item_t* path_table
        size_t path_table_nb

    int h3zero_callback(picoquic_cnx_t* cnx, uint64_t stream_id,
                         uint8_t* bytes, size_t length,
                         int fin_or_event, void* callback_ctx,
                         void* stream_ctx)


cdef extern from "pico_webtransport.h":
    int picowt_prepare_client_cnx(
        picoquic_quic_t* quic, sockaddr* server_address,
        picoquic_cnx_t** p_cnx, h3zero_callback_ctx_t** p_h3_ctx,
        h3zero_stream_ctx_t** p_stream_ctx,
        uint64_t current_time, const char* sni)

    int picowt_connect(
        picoquic_cnx_t* cnx, h3zero_callback_ctx_t* h3_ctx,
        h3zero_stream_ctx_t* stream_ctx,
        const char* authority, const char* path,
        picohttp_post_data_cb_fn wt_callback, void* wt_ctx,
        const char* wt_available_protocols)

    int picowt_send_close_session_message(
        picoquic_cnx_t* cnx, h3zero_stream_ctx_t* control_stream_ctx,
        uint32_t err, const char* err_msg)

    int picowt_send_drain_session_message(
        picoquic_cnx_t* cnx, h3zero_stream_ctx_t* control_stream_ctx)

    h3zero_stream_ctx_t* picowt_create_local_stream(
        picoquic_cnx_t* cnx, int is_bidir,
        h3zero_callback_ctx_t* h3_ctx, uint64_t control_stream_id)

    int picowt_reset_stream(picoquic_cnx_t* cnx,
                              h3zero_stream_ctx_t* stream_ctx,
                              uint64_t local_stream_error)

    void picowt_deregister(picoquic_cnx_t* cnx,
                            h3zero_callback_ctx_t* h3_ctx,
                            h3zero_stream_ctx_t* control_stream_ctx)

    void picowt_set_transport_parameters(picoquic_cnx_t* cnx)
    void picowt_set_default_transport_parameters(picoquic_quic_t* quic)


cdef extern from "c/h3wt_callback.h":
    ctypedef struct aiopquic_wt_session_t:
        aiopquic_ctx_t* bridge
        picoquic_cnx_t* cnx
        h3zero_callback_ctx_t* h3_ctx
        h3zero_stream_ctx_t* control_stream
        uint64_t control_stream_id
        int session_ready
        int session_closing
        char* wt_protocol

    aiopquic_wt_session_t* aiopquic_wt_session_create(aiopquic_ctx_t* bridge)
    void aiopquic_wt_session_destroy(aiopquic_wt_session_t* s)
    int aiopquic_wt_path_callback(
        picoquic_cnx_t* cnx, uint8_t* bytes, size_t length,
        int event,
        h3zero_stream_ctx_t* stream_ctx, void* path_app_ctx)
    int aiopquic_wt_server_path_callback(
        picoquic_cnx_t* cnx, uint8_t* bytes, size_t length,
        int event,
        h3zero_stream_ctx_t* stream_ctx, void* path_app_ctx)
    int aiopquic_dispatch_cb(
        picoquic_cnx_t* cnx, uint64_t stream_id,
        uint8_t* bytes, size_t length,
        int event,
        void* callback_ctx, void* v_stream_ctx)
    int aiopquic_wt_server_bootstrap_cb(
        picoquic_cnx_t* cnx, uint64_t stream_id,
        uint8_t* bytes, size_t length,
        int event,
        void* callback_ctx, void* v_stream_ctx)
    # Per-WT-stream link, owned by h3zero's stream_ctx->path_callback_ctx.
    # We only ever destroy these from drain_rx on a LINK_RELEASE event;
    # the worker thread allocates them in h3wt_callback.h.
    ctypedef struct aiopquic_wt_stream_link_t:
        aiopquic_stream_ctx_t* sc
        uint64_t stream_id

    void aiopquic_wt_stream_link_destroy(aiopquic_wt_stream_link_t* link)


# Default ring sizing
DEF DEFAULT_RING_CAPACITY = 262144


_CC_NAMES = ("newreno", "reno", "cubic", "dcubic", "fast", "bbr", "bbr1",
             "prague", "c4")


def check_congestion_control_algorithm(name):
    """Raise ValueError unless picoquic has an algorithm registered under
    exactly `name` (str or bytes). None, picoquic's default, passes."""
    if name is None:
        return
    cdef bytes b_name
    if isinstance(name, str):
        b_name = name.encode()
    elif isinstance(name, bytes):
        b_name = name
    else:
        raise ValueError(
            f"congestion_control_algorithm must be a str, not {type(name).__name__}")
    picoquic_register_all_congestion_control_algorithms()
    if b"\0" in b_name or picoquic_get_congestion_algorithm(b_name) is NULL:
        raise ValueError(
            f"unknown congestion_control_algorithm {name!r}; "
            f"expected one of {', '.join(_CC_NAMES)}")


def check_congestion_control_options(options, name):
    """Raise ValueError unless options is None, or a str with an algorithm
    named to take it."""
    if options is None:
        return
    if not isinstance(options, str) or "\0" in options:
        raise ValueError("congestion_control_options must be a str")
    if name is None:
        raise ValueError(
            "congestion_control_options needs a congestion_control_algorithm")


def tx_data_bytes_queued():
    """Process-wide bytes committed to per-stream sc->tx data rings
    and not yet pulled by a picoquic worker (nor discarded at stream
    teardown): pushed - pulled - discarded, three relaxed atomic
    loads. The O(1) primitive behind the aggregate TX gate — bounds
    producer run-ahead that per-stream caps can't see because
    short-stream churn resets the per-stream budget every rollover."""
    return aiopquic_tx_data_bytes_queued()


cdef class StreamChunk:
    """
    Owns a malloc'd byte buffer and exposes it via the Python buffer
    protocol. Built by drain_rx; the underlying buffer is the same
    memory written by the picoquic callback's mandatory copy-out.

    Ownership transfers from spsc_ring entry → StreamChunk via
    spsc_ring_take_data(). The buffer is freed in __dealloc__ when
    the last reference (memoryview or otherwise) is dropped.

    Per-stream flow-control feedback (chunk-lifetime model):
      - On _wrap, chunk length is added to sc->bytes_pending_release
        AND a ref is taken on sc (so sc outlives the stream FIN if
        chunks are still alive in the consumer's pipeline).
      - pending_release is subtracted at the consumer's FIRST buffer
        access (__getbuffer__ → _release_fc): once a memoryview
        exists the bytes are committed to the consumer's pipeline,
        and bounding memory beyond that point is the application's
        job (parser commit cadence, app-level caps), not QUIC FC.
        Releasing at first access avoids the parser-hoarding
        deadlock a release-at-dealloc design suffers (parser holds
        chunks waiting for an object boundary, pending pins the
        grant at zero, the completing chunk can never arrive).
      - __dealloc__ (last memoryview ref dropped) is the fallback
        release for chunks that were never accessed; it frees the
        buffer and drops the chunk's sc ref.
      - Neither path pushes an FC event (per-chunk pushes were an
        event storm at high rate). Credit pushes happen in drain_rx
        with per-cycle dedupe + hysteresis; the worker's grant
        (buf_free - bytes_pending_release) reads pending at handle
        time, so releases land in the next push's grant.

    Back-pointers (_sc, _cnx, _stream_id, _ctx) are required for the
    release-side accounting. They are BORROWED pointers; the chunk
    does NOT hold strong refs to picoquic state. NULL _sc skips
    accounting (used by the RingBuffer.pop() test path where the
    chunk is not tied to a real stream).

    Internal type. Public surface is memoryview(chunk).
    """
    cdef void* _buf
    cdef Py_ssize_t _len
    cdef aiopquic_ctx_t* _ctx
    cdef aiopquic_stream_ctx_t* _sc
    cdef void* _cnx
    cdef uint64_t _stream_id
    cdef bint _delivered

    def __cinit__(self):
        self._buf = NULL
        self._len = 0
        self._ctx = NULL
        self._sc = NULL
        self._cnx = NULL
        self._stream_id = 0
        self._delivered = False

    @staticmethod
    cdef StreamChunk _wrap(void* buf, Py_ssize_t length,
                            aiopquic_ctx_t* ctx,
                            aiopquic_stream_ctx_t* sc,
                            void* cnx,
                            uint64_t stream_id):
        cdef StreamChunk c = StreamChunk.__new__(StreamChunk)
        c._buf = buf
        c._len = length
        c._ctx = ctx
        c._sc = sc
        c._cnx = cnx
        c._stream_id = stream_id
        aiopquic_chunks_alive_inc()
        if sc is not NULL:
            # Take a ref on sc so it stays alive until this chunk
            # is dealloc'd, even if the stream FINs (SPSC_EVT_STREAM_DESTROY
            # drops the stream-lifetime ref) before the consumer
            # releases the memoryview. Released in __dealloc__ via
            # the matching aiopquic_stream_ctx_destroy (unref).
            aiopquic_stream_ctx_ref(sc)
            aiopquic_cnt_sc_ref_chunk_wrap_inc()
            if length > 0:
                aiopquic_stream_ctx_pending_add(sc, <uint64_t>length)
        return c

    cdef inline void _release_fc(self):
        """Idempotent pending_release accounting. Fired by __getbuffer__
        (consumer accessed the bytes — committed to the consumer's
        pipeline) and as a fallback by __dealloc__ when the chunk was
        never accessed. _delivered flag makes both paths converge to a
        single pending_sub regardless of how many memoryviews are
        created or in what order dealloc fires.

        Does NOT push fc_credit on the tx_event_ring. Per-chunk push
        was the May-25 storm (~280K events/sec at 2 Gbps × 64KB) that
        saturated the asyncio thread and triggered rx_event_ring
        overflow → cliff. The credit push happens in drain_rx after
        popping bytes from sc->rx, with hysteresis (see
        _push_fc_credit). The worker's grant computation reads
        bytes_pending_release at push time, so this pending_sub
        update lands in the next push's grant automatically."""
        if (not self._delivered and self._sc is not NULL
                and self._len > 0):
            self._delivered = True
            aiopquic_stream_ctx_pending_sub(
                self._sc, <uint64_t>self._len)

    def __dealloc__(self):
        # Touches only memory this chunk owns: _buf, and _sc through the
        # reference it holds. A chunk keeps no TransportContext reference
        # and so may outlive one — reaching for ctx state here (an event
        # ring, a counter) would be a use-after-free.
        if self._buf is not NULL:
            # Fallback release: chunk dropped without consumer read.
            # No-op when _delivered=True (FC already released at
            # first __getbuffer__). Order matters: push fc_credit
            # BEFORE dropping the chunk's sc ref so the pending
            # SPSC_EVT_TX_OPEN_FLOW_CONTROL event has a valid sc
            # to dereference when the worker handler runs (the
            # worker handler is responsible for its own sc unref).
            self._release_fc()
            free(self._buf)
            self._buf = NULL
        # Drop the chunk's ref on sc. If this is the LAST ref
        # (stream already FIN'd AND all pending fc events handled),
        # sc is freed here. Otherwise the worker handler or another
        # outstanding chunk holds it alive.
        if self._sc is not NULL:
            aiopquic_cnt_sc_destroy_chunk_dealloc_inc()
            aiopquic_stream_ctx_destroy(self._sc)
            self._sc = NULL
        aiopquic_chunks_alive_dec()

    def __len__(self):
        return self._len

    def __getbuffer__(self, Py_buffer* buffer, int flags):
        # Release FC on first consumer access. Semantic: pending_release
        # bounds bytes peer sent that we have NOT yet handed to the
        # consumer. Once a memoryview exists, the bytes are committed
        # to the consumer's pipeline — bounding memory beyond this
        # point is the consumer's responsibility (parser queue caps,
        # track-level limits, etc.), not QUIC FC.
        #
        # Releasing here breaks the parser-hoarding deadlock that
        # __dealloc__-only release caused: parser holds chunks while
        # accumulating bytes for an object boundary, pending stays at
        # full ring capacity, grant = buf_free - pending = 0, peer
        # FC-stalls, the chunk that would unblock things never arrives.
        # _release_fc is idempotent via _delivered, so multiple
        # getbuffer calls (e.g. slicing) and the dealloc fallback all
        # converge to a single release.
        self._release_fc()
        PyBuffer_FillInfo(buffer, self, self._buf, self._len, 1, flags)

    def __releasebuffer__(self, Py_buffer* buffer):
        pass


cdef class RingBuffer:
    """Python wrapper around the SPSC ring buffer for testing/inspection."""
    cdef spsc_ring_t* _ring
    cdef bint _owned

    def __cinit__(self, uint32_t capacity=DEFAULT_RING_CAPACITY):
        self._ring = spsc_ring_create(capacity)
        self._owned = True
        if self._ring is NULL:
            raise MemoryError("Failed to create SPSC ring buffer")

    def __dealloc__(self):
        if self._owned and self._ring is not NULL:
            spsc_ring_destroy(self._ring)
            self._ring = NULL

    @property
    def capacity(self):
        return self._ring.capacity

    @property
    def count(self):
        return spsc_ring_count(self._ring)

    @property
    def empty(self):
        return spsc_ring_empty(self._ring) != 0

    def push(self, uint32_t event_type, uint64_t stream_id,
             bytes data=None, uint8_t is_fin=0, uint64_t error_code=0):
        """Push an entry into the ring (producer side)."""
        cdef spsc_entry_t entry
        cdef const uint8_t* data_ptr = NULL
        cdef uint32_t data_len = 0

        entry.event_type = event_type
        entry.stream_id = stream_id
        entry.is_fin = is_fin
        entry.cnx = NULL
        entry.stream_ctx = NULL
        entry.error_code = error_code

        if data is not None:
            data_ptr = <const uint8_t*>data
            data_len = <uint32_t>len(data)

        cdef int ret = spsc_ring_push(self._ring, &entry, data_ptr, data_len)
        if ret != 0:
            raise BufferError("Ring buffer is full")

    def pop(self):
        """
        Pop the next entry (consumer side).
        Returns (event_type, stream_id, data, is_fin, error_code) or None.
        `data` is a memoryview backed by an internal StreamChunk, or None.
        """
        cdef spsc_entry_t* entry = spsc_ring_peek(self._ring)
        if entry is NULL:
            return None

        data = None
        cdef void* buf
        cdef Py_ssize_t length
        if entry.data_length > 0 and entry.data_buf is not NULL:
            length = entry.data_length
            buf = spsc_ring_take_data(entry)
            data = memoryview(StreamChunk._wrap(
                buf, length, NULL, NULL, NULL, 0))

        result = (entry.event_type, entry.stream_id, data,
                  entry.is_fin, entry.error_code)
        spsc_ring_pop(self._ring)
        return result


def _format_sockaddr(family, addr, port):
    """(host, port) from a snapshot address, or None when unknown.
    An IPv4-mapped IPv6 address is returned as IPv4."""
    if family == 4:
        return (_socket.inet_ntop(_socket.AF_INET, addr[:4]), port)
    if family == 6:
        if addr[:12] == b"\0" * 10 + b"\xff\xff":
            return (_socket.inet_ntop(_socket.AF_INET, addr[12:16]), port)
        return (_socket.inet_ntop(_socket.AF_INET6, addr[:16]), port)
    return None


# Module-level registry of live TransportContext instances. Walked by
# dump_all_counters() (driven from aiomoqt's SIGUSR2 taskdump handler)
# to print forensic counters from every active context. WeakSet so
# contexts aren't kept alive by the registry.
import weakref as _weakref

_TRANSPORT_REGISTRY = _weakref.WeakSet()

# TLS key-exchange group ids (IANA), for start(key_exchange_groups=...).
KEX_X25519 = 29
KEX_SECP256R1 = 23
KEX_X25519MLKEM768 = 4588
KEX_SECP256R1MLKEM768 = 4587
KEX_MLKEM1024 = 514
# Classic groups first: picotls sends one key share, for the first
# group, and a server without the hybrid and without HelloRetryRequest
# (aioquic, qh3) cannot complete a handshake whose only share is
# post-quantum.
DEFAULT_KEY_EXCHANGE_GROUPS = (KEX_X25519, KEX_SECP256R1,
                               KEX_X25519MLKEM768, KEX_SECP256R1MLKEM768,
                               KEX_MLKEM1024)
_applied_key_exchange_groups = None


def dump_all_counters(file=None):
    """Print counters from every live TransportContext to `file`
    (default stderr). Used by the SIGUSR2 handler in
    aiomoqt.utils.taskdump for hang-localization.

    For each TransportContext, also enumerates per-stream counters
    by walking gc-visible objects to find QuicConnection /
    WebTransportSession instances bound to that transport — those
    hold the `_stream_ctxs` / `_stream_tx_ctxs` maps that record
    each stream's `aiopquic_stream_ctx_t*` pointer. Per-stream
    counters are the load-bearing signal for diagnosing
    per-stream sc->tx_drain_pending wake stalls: an outstanding
    arm without matching fire on a specific stream is exactly the
    pattern that hangs a producer in stream_write_drain.
    """
    import os, sys, gc
    if file is None:
        file = sys.stderr
    # Per-stream walk dereferences sc_ptr from the QuicConnection /
    # WebTransportSession _stream_ctxs / _stream_tx_ctxs dicts. Those
    # dicts are not cleaned up when sc is destroyed by drain_rx's
    # internal STREAM_DESTROY handler — stale pointers accumulate
    # and dereferencing them in dump_counters causes UAF / SEGV.
    # Default OFF; opt in with AIOPQUIC_DUMP_PER_STREAM=1 for cases
    # where you know the dicts are clean (small synthetic tests).
    # Proper fix: surface STREAM_DESTROY to QuicConnection so it can
    # del the dict entry. Tracked separately.
    per_stream_enabled = (os.environ.get("AIOPQUIC_DUMP_PER_STREAM")
                          == "1")
    n = 0
    for ctx in list(_TRANSPORT_REGISTRY):
        sc_map = {}
        cnx_ptrs = []
        # Walk gc-visible objects ONCE per ctx; harvest per-stream
        # ctxs (gated, UAF risk on stale sc_ptrs) AND per-cnx ptrs
        # (always safe — cnx is alive for as long as the wrapper is
        # GC-visible, no UAF window).
        for obj in gc.get_objects():
            try:
                if getattr(obj, '_transport', None) is not ctx:
                    continue
                # cnx_ptr collection: QuicConnection has _cnx_ptr,
                # WebTransportSession exposes cnx_ptr (a property
                # reading _state.cnx_ptr). Both yield a non-zero int
                # only once the cnx is open.
                cnx_ptr = getattr(obj, '_cnx_ptr', None)
                if cnx_ptr is None:
                    cnx_ptr = getattr(obj, 'cnx_ptr', None)
                if isinstance(cnx_ptr, int) and cnx_ptr:
                    cnx_ptrs.append(cnx_ptr)
                if per_stream_enabled:
                    inner = getattr(obj, '_stream_ctxs', None)
                    if isinstance(inner, dict):
                        sc_map.update(inner)
                    inner = getattr(obj, '_stream_tx_ctxs', None)
                    if isinstance(inner, dict):
                        sc_map.update(inner)
            except Exception:
                continue
        ctx.dump_counters(
            file=file, label=f"ctx#{n}",
            stream_ctxs=sc_map if per_stream_enabled else None,
            cnx_ptrs=cnx_ptrs if cnx_ptrs else None,
        )
        n += 1
    if n == 0:
        print("=== no live TransportContext instances ===",
              file=file, flush=True)


cdef inline int _pending_fc_add(dict pending_fc, aiopquic_stream_ctx_t* sc,
                                void* cnx, uint64_t stream_id) except -1:
    """Note sc for this drain cycle's credit push. The note holds a
    reference: a later entry in the batch may drop every other one."""
    cdef uintptr_t key = <uintptr_t>sc
    if key not in pending_fc:
        aiopquic_stream_ctx_ref(sc)
        pending_fc[key] = (<uintptr_t>cnx, stream_id)
    return 0


_WAKE_KINDS = {1: "notify", 2: "clear", 3: "drain"}


cdef int _wake_trace_tail(aiopquic_wake_trace_t* trace, str side, int last,
                          list out) except -1:
    cdef uint64_t end = aiopquic_wake_trace_next(trace)
    cdef uint64_t n = min(<uint64_t>last, end, <uint64_t>AIOPQUIC_WAKE_TRACE_LEN)
    cdef uint64_t i
    cdef aiopquic_wake_trace_entry_t* e
    for i in range(end - n, end):
        e = &trace.e[i % AIOPQUIC_WAKE_TRACE_LEN]
        out.append((e.ts_ns, side, _WAKE_KINDS.get(e.kind, e.kind), e.a, e.b))
    return 0


cdef int _fill_sockaddr(str host, int port, sockaddr_storage* out,
                        unsigned int scope_id=0) except -1:
    """IPv4 or IPv6 literal and port into a zeroed sockaddr_storage."""
    memset(out, 0, sizeof(sockaddr_storage))
    cdef bytes b_host = host.encode()
    cdef sockaddr_in* v4 = <sockaddr_in*>out
    cdef sockaddr_in6* v6 = <sockaddr_in6*>out
    if inet_pton(AF_INET, b_host, &v4.sin_addr) == 1:
        v4.sin_family = AF_INET
        v4.sin_port = htons(<unsigned short>port)
        return 0
    if inet_pton(AF_INET6, b_host, &v6.sin6_addr) == 1:
        v6.sin6_family = AF_INET6
        v6.sin6_port = htons(<unsigned short>port)
        v6.sin6_scope_id = scope_id
        return 0
    raise ValueError(f"Invalid IP address: {host}")


_log = _logging.getLogger("aiopquic")

_PMTUD_POLICIES = {
    "basic": picoquic_pmtud_basic,
    "delayed": picoquic_pmtud_delayed,
    "blocked": picoquic_pmtud_blocked,
}


def _ipv6_bind_error(int port=0):
    """None if an IPv6-only UDP socket can bind [::]:port, else the error.
    picoquic opens neither socket of a dual-stack pair when one fails."""
    if not _socket.has_ipv6:
        return OSError(_errno.EAFNOSUPPORT, "IPv6 not available")
    try:
        with _socket.socket(_socket.AF_INET6, _socket.SOCK_DGRAM) as s:
            s.setsockopt(_socket.IPPROTO_IPV6, _socket.IPV6_V6ONLY, 1)
            s.bind(("::", port))
        return None
    except OSError as exc:
        return exc


def _ipv6_usable() -> bool:
    """Whether an IPv6 UDP socket can bind here."""
    return _ipv6_bind_error() is None


def _bind_addresses(host, int ip_family):
    """(local_af, [(family, address, scope_id)]) for a listener's host.

    None, "" and "::" keep the wildcard over the families ip_family
    selects; "0.0.0.0" is the IPv4 wildcard; anything else resolves to at
    most one address per family.
    """
    if host is None or host in ("", "::"):
        return ip_family, []
    if host == "0.0.0.0":
        if ip_family == AF_INET6:
            raise ValueError("host '0.0.0.0' is IPv4 but ip_family is AF_INET6")
        return AF_INET, []
    found = {}
    for family, _, _, _, sockaddr in _socket.getaddrinfo(
            host, None, type=_socket.SOCK_DGRAM, flags=_socket.AI_PASSIVE):
        if family not in (_socket.AF_INET, _socket.AF_INET6) or family in found:
            continue
        if ip_family > 0 and family != ip_family:
            continue
        scope_id = sockaddr[3] if family == _socket.AF_INET6 else 0
        found[family] = (sockaddr[0].split("%")[0], scope_id)
    if not found:
        raise ValueError(f"host {host!r} has no address in the requested family")
    addrs = [(family, address, scope_id)
             for family, (address, scope_id) in found.items()]
    return (addrs[0][0] if len(addrs) == 1 else 0), addrs


def _bind_preflight(addrs, int port):
    """Raise the OSError picoquic's own bind would hit in its thread."""
    for family, address, scope_id in addrs:
        with _socket.socket(family, _socket.SOCK_DGRAM) as s:
            if family == _socket.AF_INET6:
                s.setsockopt(_socket.IPPROTO_IPV6, _socket.IPV6_V6ONLY, 1)
                s.bind((address, port, 0, scope_id))
            else:
                s.bind((address, port))


cdef class TransportContext:
    """
    Manages the picoquic context and network thread.

    This is the core bridge between the C picoquic library and Python.
    It owns the SPSC rings and the eventfd used for async notification.

    Constructor arguments size the two event rings, in entries, rounded up
    to a power of two; 0 takes the default:
        tx_ring_cap: TX event ring, asyncio to worker (default 2048).
        rx_data_ring_cap: RX event ring, worker to asyncio (default 16384).
            Not a byte ring: start(rx_data_ring_cap=) sizes each stream's
            RX bytes.
        ring_capacity: both, where the specific argument is 0.
        tx_event_ring_low_water_pct: TX ring fill, in percent, below which a
            parked writer is woken (default 50).
    """
    # Make cdef class weakref-able so the SIGUSR2 counter-dump registry
    # (_TRANSPORT_REGISTRY at module level above) can hold WeakRef
    # references without keeping ctx objects alive past their natural
    # lifetime.
    cdef object __weakref__
    cdef aiopquic_ctx_t* _ctx
    cdef picoquic_quic_t* _quic
    cdef picoquic_network_thread_ctx_t* _thread_ctx
    cdef picoquic_packet_loop_param_t _param
    cdef bint _started
    cdef uint32_t _max_connections
    # WT server-mode storage; must persist for picoquic's lifetime.
    cdef bytes _wt_path_bytes
    # Server WT subprotocol allowlist (CSV). Held here so the borrowed
    # pointer handed to the bridge (ctx->wt_supported_protocols) stays
    # valid for picoquic's lifetime.
    cdef bytes _wt_supported_csv
    # Raw-QUIC ALPN list (CSV), input to aiopquic_ctx_set_alpn_list which
    # parses it into a bridge-owned array of copies (client offer + server
    # allowlist). Retained only to keep the buffer alive across that call.
    cdef bytes _alpn_list_csv
    # Strings picoquic keeps borrowed pointers to.
    cdef bytes _ticket_file
    cdef bytes _web_folder
    cdef bytes _cc_options
    cdef picohttp_server_path_item_t _wt_path_item
    cdef picohttp_server_parameters_t _wt_params
    # Forensic counters for the atomic send_stream_data path.
    # All updated from the asyncio thread (single producer); reads
    # from Python don't need atomicity beyond the GIL.
    cdef uint64_t _send_calls
    cdef uint64_t _send_busy_event_ring
    cdef uint64_t _send_busy_stream_ring
    cdef uint64_t _send_alloc_fail
    # Connection-global TX-ring drain wakeup. Lazy-allocated on first
    # access (needs a running event loop); see tx_event_ring_drain_event.
    cdef object _tx_event_ring_drain_event
    # Test-friendly low-level pull primitive: per-(cnx, sid) sc_ptr
    # tracker for tx_send_stream(). Production code uses
    # QuicConnection.send_stream_data which manages its own per-cnx
    # _stream_ctxs dict; this dict is for the bare-TransportContext
    # test path where there's no QuicConnection wrapper.
    cdef object _test_stream_ctxs
    # Per-cnx aiopquic_cnx_snapshot_t bytes, keyed by cnx ptr; closed
    # cnxs whose snapshot drops at the next drain; cnxs already sent a
    # refresh this drain cycle.
    cdef dict _cnx_snapshots
    cdef list _snapshot_drops
    cdef set _refresh_posted
    # References the last drain_rx batch holds; see release_batch().
    cdef batch_ref_t* _batch_refs
    cdef size_t _batch_refs_n
    cdef size_t _batch_refs_cap

    def __cinit__(self,
                  uint32_t ring_capacity=0,
                  uint32_t tx_ring_cap=0,
                  uint32_t rx_data_ring_cap=0,
                  uint32_t tx_event_ring_low_water_pct=0):
        # Resolution order for each SPSC cap:
        #   1. Explicit per-direction kwarg (tx_ring_cap / rx_data_ring_cap)
        #   2. Legacy shared ring_capacity (positional or kwarg)
        #   3. 0 → C-side picks AIOPQUIC_{TX,RX}_RING_CAP_DEFAULT
        # ring_capacity preserves the pre-0.3.5 positional signature
        # (TransportContext(262144) still works).
        cdef uint32_t tx_cap = tx_ring_cap if tx_ring_cap > 0 else ring_capacity
        cdef uint32_t rx_cap = rx_data_ring_cap if rx_data_ring_cap > 0 else ring_capacity
        if tx_cap > 0:
            tx_cap = aiopquic_ceil_pow2_u32(tx_cap)
        if rx_cap > 0:
            rx_cap = aiopquic_ceil_pow2_u32(rx_cap)
        self._ctx = aiopquic_ctx_create(tx_cap, rx_cap, tx_event_ring_low_water_pct)
        self._quic = NULL
        self._thread_ctx = NULL
        self._started = False
        self._send_calls = 0
        self._send_busy_event_ring = 0
        self._send_busy_stream_ring = 0
        self._send_alloc_fail = 0
        self._tx_event_ring_drain_event = None
        self._test_stream_ctxs = {}
        self._cnx_snapshots = {}
        self._snapshot_drops = []
        self._refresh_posted = set()
        self._batch_refs = NULL
        self._batch_refs_n = 0
        self._batch_refs_cap = 0
        if self._ctx is NULL:
            raise MemoryError("Failed to create transport context")
        # Register for module-level SIGUSR2 counter dump.
        _TRANSPORT_REGISTRY.add(self)

    def __dealloc__(self):
        self._shutdown()
        free(self._batch_refs)
        self._batch_refs = NULL
        if self._ctx is not NULL:
            self._release_undrained_rx()
            aiopquic_ctx_destroy(self._ctx)
            self._ctx = NULL
        # WeakSet auto-removes; no explicit discard needed.

    cdef void _release_undrained_rx(self):
        """Free the links of LINK_RELEASE events nobody drained and drop the
        sc references of undrained stream events. Runs after the worker
        stopped and picoquic was freed, so this thread is the ring's only
        user; ring destroy would skip these borrowed pointers."""
        cdef spsc_entry_t* entry
        while True:
            entry = spsc_ring_peek(self._ctx.rx_event_ring)
            if entry is NULL:
                if spsc_ring_refill_from_overflow(
                        self._ctx.rx_event_ring, &self._ctx.rx_overflow) == 0:
                    break
                continue
            if (entry.event_type == SPSC_EVT_WT_STREAM_LINK_RELEASE
                    and entry.data_buf is not NULL):
                aiopquic_wt_stream_link_destroy(
                    <aiopquic_wt_stream_link_t*>entry.data_buf)
            aiopquic_rx_event_release(entry)
            spsc_ring_pop(self._ctx.rx_event_ring)

    cdef void _shutdown(self):
        """Stop the network thread and free picoquic context."""
        if self._thread_ctx is not NULL:
            # Clear the C-side mirror BEFORE freeing so any in-flight
            # aiopquic_push_fc_credit calls see NULL and skip wake.
            if self._ctx is not NULL:
                self._ctx.thread_ctx = NULL
            picoquic_delete_network_thread(self._thread_ctx)
            self._thread_ctx = NULL
        if self._ctx is not NULL:
            aiopquic_dgram_ring_release_undrained(self._ctx)
            aiopquic_tx_sc_release_undrained(self._ctx)
        self._release_batch_refs()
        if self._quic is not NULL and self._ticket_file is not None:
            picoquic_save_session_tickets(self._quic, self._ticket_file)
        if self._quic is not NULL:
            picoquic_free(self._quic)
            self._quic = NULL
        self._started = False

    @property
    def eventfd(self):
        """File descriptor for asyncio add_reader() registration."""
        return self._ctx.eventfd

    @property
    def rx_event_ring_count(self):
        """Number of events pending in the RX ring."""
        return spsc_ring_count(self._ctx.rx_event_ring)

    @property
    def rx_clears(self):
        """clear_rx calls so far: advances once per drain."""
        return self._ctx.cnt_rx_clears

    def wake_trace(self, int last=64):
        """The latest wake-protocol events of both threads, oldest first:
        (ts_ns, side, kind, a, b). side is "worker" or "asyncio"; kind is
        "notify" (a: wake write errno, b: ring count), "drain" (a: events
        popped, b: ring count after) or "clear" (a: flags 1 was pending,
        2 re-armed, 4 wake fd read empty, 8 re-arm write failed; b: ring
        left << 32 | counter read). Read without locks: diagnostic only."""
        cdef list out = []
        _wake_trace_tail(&self._ctx.worker_trace, "worker", last, out)
        _wake_trace_tail(&self._ctx.asyncio_trace, "asyncio", last, out)
        out.sort()
        return out[-last:]

    @property
    def tx_event_ring_count(self):
        """Number of events pending in the TX ring."""
        return spsc_ring_count(self._ctx.tx_event_ring)

    @property
    def counters(self):
        """Snapshot of forensic counters from the C-side context.

        Counter names mirror callback.h fields. Use for hang-diagnosis
        via SIGUSR2 dump (aiomoqt taskdump wires this up). The dict
        also includes live ring counts for quick comparison against
        cumulative push/pop totals.

        Key counters and what mismatches reveal:
          tx_event_ring_pushes vs tx_event_ring_pops: drain lag
          tx_event_ring_arms vs tx_event_ring_fires: missed ring-drain wakes
          set_priority_applied vs set_priority_rejected: picoquic accepted or
            refused the priority; set_priority_last_err carries the code.
            Ring drain alone cannot tell these from a dead-cnx drop
          tx_event_dropped_dead_cnx > 0: events whose cnx was freed between
            push and pop — silently discarded, every event type
          tx_wrong_direction_dropped > 0: RESET_STREAM / STOP_SENDING requested
            on a stream without that direction; dropped
          tx_event_ring_fire_dropped > 0: rx_event_ring full at fire time (re-arm path)
          wake_calls vs wake_skipped_coalesced: wake-coalescing efficiency
          rx_notify_pending_now 1 with events queued (rx_event_ring_count_now
            or rx_overflow_depth_now) while asyncio sleeps: a lost RX wake.
            loop_callbacks still moving: the worker is running
          prepare_to_send_calls vs prepare_to_send_pulled_bytes: worker
            actually drained sc->tx vs ran with nothing to send
          last_tx_event_ring_arm_ns > last_tx_event_ring_fire_ns: an arm without
            matching fire is currently pending (still in flight or lost)
        """
        if self._ctx is NULL:
            return {}
        return {
            'tx_event_ring_pushes': self._ctx.cnt_tx_event_ring_pushes,
            'tx_event_ring_pops': self._ctx.cnt_tx_event_ring_pops,
            'tx_event_ring_arms': self._ctx.cnt_tx_event_ring_arms,
            'tx_event_ring_fires': self._ctx.cnt_tx_event_ring_fires,
            'tx_event_ring_fire_dropped': self._ctx.cnt_tx_event_ring_fire_dropped,
            'wake_calls': self._ctx.cnt_wake_calls,
            'wake_skipped_coalesced': self._ctx.cnt_wake_skipped_coalesced,
            'tx_wake_lost': self._ctx.cnt_tx_wake_lost,
            'prepare_to_send_calls': self._ctx.worker_prepare_to_send_calls,
            'prepare_to_send_pulled_bytes': self._ctx.worker_prepare_to_send_pulled_bytes,
            'prepare_to_send_empty': self._ctx.cnt_prepare_to_send_empty,
            'mark_active_processed': self._ctx.worker_mark_active_processed,
            'set_priority_applied': self._ctx.worker_set_priority_applied,
            'set_priority_rejected': self._ctx.worker_set_priority_rejected,
            'set_priority_last_err': self._ctx.worker_set_priority_last_err,
            'set_dgram_priority_applied': self._ctx.worker_set_dgram_priority_applied,
            'tx_event_dropped_dead_cnx': self._ctx.cnt_tx_event_dropped_dead_cnx,
            'cnx_live_walks': self._ctx.cnt_cnx_live_walks,
            'live_cnxs_hooked': self._ctx.live_cnxs_hooked,
            'tx_park_kept_active': self._ctx.cnt_tx_park_kept_active,
            'tx_mark_active_skipped': self._ctx.cnt_tx_mark_active_skipped,
            'tx_wrong_direction_dropped': self._ctx.cnt_tx_wrong_direction_dropped,
            'tx_reattach_after_close': self._ctx.cnt_tx_reattach_after_close,
            'stream_cb_after_close': self._ctx.cnt_stream_cb_after_close,
            'rx_event_drops': self._ctx.worker_rx_event_drops,
            'rx_event_drops_stream_data': self._ctx.worker_rx_event_drops_stream_data,
            'rx_overflow_pushed': self._ctx.rx_overflow.pushed,
            'rx_overflow_max_depth': self._ctx.rx_overflow.max_depth,
            'rx_overflow_depth_now': self._ctx.rx_overflow.depth,
            'rx_notify_pending_now': self._ctx.rx_notify_pending,
            'rx_notify_flips': self._ctx.cnt_rx_notify_flips,
            'rx_notify_skips': self._ctx.cnt_rx_notify_skips,
            'rx_notify_write_errs': self._ctx.cnt_rx_notify_write_errs,
            'rx_notify_last_errno': self._ctx.last_rx_notify_errno,
            'rx_clears': self._ctx.cnt_rx_clears,
            'rx_clear_read_empty': self._ctx.cnt_rx_clear_read_empty,
            'rx_rearms': self._ctx.cnt_rx_rearms,
            'loop_callbacks': self._ctx.cnt_loop_cb,
            'rx_data_event_coalesced': self._ctx.cnt_rx_data_event_coalesced,
            'rx_byte_ring_overflow': self._ctx.worker_rx_byte_ring_overflow,
            'last_tx_event_ring_arm_ns': self._ctx.last_tx_event_ring_arm_ns,
            'last_tx_event_ring_fire_ns': self._ctx.last_tx_event_ring_fire_ns,
            'tx_event_ring_count_now': spsc_ring_count(self._ctx.tx_event_ring),
            'rx_event_ring_count_now': spsc_ring_count(self._ctx.rx_event_ring),
            'tx_event_ring_drain_pending_now': self._ctx.tx_event_ring_drain_pending,
            'tx_worker_idle_now': self._ctx.tx_worker_idle,
            # RX flow-control observability (added 2026-05-25)
            'fc_credit_pushed': self._ctx.cnt_fc_credit_pushed,
            'fc_credit_handled': self._ctx.cnt_fc_credit_handled,
            'fc_credit_dropped': self._ctx.cnt_fc_credit_dropped,
            # WT sc/link leak diagnostic (added 2026-06-06).
            # Growth rate ~ sc leak rate per cnx.
            'wt_callback_free_skipped': self._ctx.cnt_wt_callback_free_skipped,
            'wt_control_released': self._ctx.cnt_wt_control_released,
            # Per-site sc create/ref/destroy counters (added 2026-06-06).
            # See stream_ctx.h block comment for the balance invariant.
            'sc_create_raw_quic': self._ctx.cnt_sc_create_raw_quic,
            'sc_create_wt_link': self._ctx.cnt_sc_create_wt_link,
            'sc_ref_fc_credit': self._ctx.cnt_sc_ref_fc_credit,
            'sc_destroy_wt_link_callback_free': self._ctx.cnt_sc_destroy_wt_link_callback_free,
            'sc_destroy_wt_link_close_walker': self._ctx.cnt_sc_destroy_wt_link_close_walker,
            'sc_destroy_fc_credit_pushfail': self._ctx.cnt_sc_destroy_fc_credit_pushfail,
            'sc_destroy_fc_credit_worker': self._ctx.cnt_sc_destroy_fc_credit_worker,
            'sc_destroy_fc_credit_dead_cnx':
                self._ctx.cnt_sc_destroy_fc_credit_dead_cnx,
            'sc_ref_chunk_wrap_total': aiopquic_cnt_sc_ref_chunk_wrap_load(),
            'sc_destroy_chunk_dealloc_total': aiopquic_cnt_sc_destroy_chunk_dealloc_load(),
            'sc_destroy_rx_event_total': aiopquic_cnt_sc_destroy_rx_event_load(),
            'sc_create_python_helper_total': aiopquic_cnt_sc_create_python_helper_load(),
            'sc_destroy_python_helper_total': aiopquic_cnt_sc_destroy_python_helper_load(),
            # Process-wide stream / chunk lifecycle (leak detection)
            'sc_created_total': aiopquic_cnt_sc_created_load(),
            'sc_destroyed_total': aiopquic_cnt_sc_destroyed_load(),
            'sc_alive_total': (aiopquic_cnt_sc_created_load()
                               - aiopquic_cnt_sc_destroyed_load()),
            'chunks_alive_total': aiopquic_cnt_chunks_alive_load(),
            'sc_rx_bytes_pushed_total':
                aiopquic_cnt_sc_rx_bytes_pushed_load(),
            'sc_rx_bytes_popped_total':
                aiopquic_cnt_sc_rx_bytes_popped_load(),
            'sc_rx_bytes_in_flight': (
                aiopquic_cnt_sc_rx_bytes_pushed_load()
                - aiopquic_cnt_sc_rx_bytes_popped_load()),
            # Aggregate TX data-ring flow (process-wide). queued =
            # pushed - pulled - discarded; the gate primitive.
            'tx_data_bytes_pushed_total':
                aiopquic_tx_data_bytes_pushed_load(),
            'tx_data_bytes_pulled_total':
                aiopquic_tx_data_bytes_pulled_load(),
            'tx_data_bytes_discarded_total':
                aiopquic_tx_data_bytes_discarded_load(),
            'tx_data_bytes_queued': aiopquic_tx_data_bytes_queued(),
            # Datagram ring lifecycle: releases the worker processed, rings
            # its cnx table holds, and live rings process-wide.
            'dgram_ring_release_processed':
                self._ctx.worker_dgram_ring_release_processed,
            'dgram_table_live': self._ctx.dgram_table.live,
            'dgram_rings_alive_total': aiopquic_dgram_rings_alive_load(),
        }


    def stream_counters(self, uintptr_t sc_ptr):
        """Snapshot of per-stream sc->tx drain counters for the
        stream_ctx at sc_ptr. Returns {} for NULL pointer."""
        if sc_ptr == 0:
            return {}
        cdef aiopquic_stream_ctx_t* sc = <aiopquic_stream_ctx_t*><void*>sc_ptr
        return {
            'drain_arms': sc.cnt_drain_arms,
            'drain_fires': sc.cnt_drain_fires,
            'drain_dropped': sc.cnt_drain_dropped,
            'last_drain_arm_ns': sc.last_drain_arm_ns,
            'last_drain_fire_ns': sc.last_drain_fire_ns,
            'tx_used_now': aiopquic_stream_buf_used(sc.tx) if sc.tx is not NULL else 0,
            'tx_drain_pending_now': sc.tx_drain_pending,
        }

    def dump_counters(self, file=None, label=None, stream_ctxs=None, cnx_ptrs=None):
        """Print counters to stderr (or given file). Used by SIGUSR2.

        Includes the connection-global counters, plus per-stream
        counters when `stream_ctxs` (a dict mapping stream_id → sc_ptr)
        is supplied, plus per-cnx picoquic path_quality (cwin, bif,
        sRTT, pacing_rate, loss counts, bytes sent/received) when
        `cnx_ptrs` (an iterable of picoquic_cnx_t* uintptrs) is
        supplied. dump_all_counters() harvests both maps from
        gc-visible QuicConnection / WebTransportSession instances and
        passes them in automatically; manual callers can pass explicit
        arguments.

        Per-cnx output flags suspect BBR freeze when cwin is small
        and bytes_in_transit pegs at cwin — the diagnostic signature
        of the picoquic-internal #2118 cwnd-lock on low-RTT loopback.
        """
        import sys, time
        if file is None:
            file = sys.stderr
        prefix = f"[{label}] " if label else ""
        now_ns = aiopquic_now_ns()
        print(f"=== {prefix}aiopquic counters (now_ns={now_ns}) ===",
              file=file, flush=True)
        cdef dict c = self.counters
        for k in sorted(c.keys()):
            print(f"  {k:32s} = {c[k]}", file=file, flush=True)
        # Derived: arm/fire delta
        arms = c.get('tx_event_ring_arms', 0)
        fires = c.get('tx_event_ring_fires', 0)
        if arms != fires:
            print(f"  ** tx_event_ring arm/fire delta: arms={arms} fires={fires} "
                  f"diff={arms - fires} **", file=file, flush=True)
        arm_ns = c.get('last_tx_event_ring_arm_ns', 0)
        fire_ns = c.get('last_tx_event_ring_fire_ns', 0)
        if arm_ns > fire_ns and arm_ns > 0:
            print(f"  ** outstanding tx_event_ring arm: armed {(now_ns - arm_ns) / 1e6:.1f}ms ago, "
                  f"no fire since **", file=file, flush=True)

        # Per-stream counters, if a {stream_id: sc_ptr} map was passed.
        # Each row: stream_id, drain arms/fires/dropped, current
        # sc->tx bytes pending, pending flag, and a "STUCK" warning
        # when the most-recent arm has no matching fire.
        if stream_ctxs and self._quic is not NULL:
            stuck = []
            print(f"  --- per-stream ({len(stream_ctxs)} streams) ---",
                  file=file, flush=True)
            for sid in sorted(stream_ctxs.keys()):
                sc_ptr = stream_ctxs[sid]
                if not sc_ptr:
                    continue
                sc = self.stream_counters(sc_ptr)
                if not sc:
                    continue
                arms = sc['drain_arms']
                fires = sc['drain_fires']
                dropped = sc['drain_dropped']
                arm_ns = sc['last_drain_arm_ns']
                fire_ns = sc['last_drain_fire_ns']
                tx_used = sc['tx_used_now']
                pending = sc['tx_drain_pending_now']
                # Status flag — STUCK if there's an outstanding arm
                # OR pending=1 with sc->tx still holding bytes.
                status = ""
                if arm_ns > fire_ns and arm_ns > 0:
                    delta_ms = (now_ns - arm_ns) / 1e6
                    status = f"  ** STUCK arm {delta_ms:.1f}ms ago **"
                    stuck.append((sid, delta_ms, tx_used))
                print(f"  sid={sid:<5} sc=0x{sc_ptr:x} "
                      f"arms={arms} fires={fires} dropped={dropped} "
                      f"tx_used={tx_used} pending={pending}{status}",
                      file=file, flush=True)
            if stuck:
                print(f"  ** {len(stuck)} stream(s) with outstanding arm — "
                      f"oldest {max(d for _, d, _ in stuck):.1f}ms **",
                      file=file, flush=True)

        # Per-cnx picoquic path_quality snapshot, if cnx_ptrs supplied.
        # Each row: cwin / bif / sRTT / pacing_rate / loss / data sent
        # and received. Flag suspect freeze when cwin is small AND
        # bytes_in_transit pegs at cwin — the BBR-cwnd-lock signature
        # of picoquic upstream issue #2118 on low-RTT loopback.
        if cnx_ptrs and self._quic is not NULL:
            cnx_list = [p for p in cnx_ptrs if p]
            if cnx_list:
                print(f"  --- per-cnx path_quality "
                      f"({len(cnx_list)} cnx) ---",
                      file=file, flush=True)
                for ptr in cnx_list:
                    q = self.path_quality(ptr)
                    if not q:
                        continue
                    cwin = q['cwin']
                    bif = q['bytes_in_transit']
                    rtt_us = q['rtt']
                    pacing_bps = q['pacing_rate']
                    pacing_mbps = (pacing_bps * 8 / 1e6
                                    if pacing_bps else 0.0)
                    lost = q['lost']
                    sent = q['bytes_sent']
                    recv = q['bytes_received']
                    suspect = ""
                    # Heuristic: cwin under 10 typical MSS (14 KB) AND
                    # bif/cwin > 0.9. Possible causes (not exclusive):
                    # peer gone post-disconnect (no acks → cwin can't
                    # grow), picoquic #2118 BBR loopback freeze on
                    # sub-128µs RTT, fast-retransmit pinning, or other
                    # stalled-cnx condition. The bif/cwin ratio
                    # distinguishes "tight at cwin" (~1.0) from "stuck
                    # with backlog" (>>1.0).
                    if (cwin > 0 and cwin < 14400
                            and bif / cwin > 0.9):
                        suspect = (
                            f"  ** SUSPECT CWIN PINNED: "
                            f"cwin={cwin} bif={bif} "
                            f"bif/cwin={bif/cwin:.2f} "
                            f"(stalled cnx) **")
                    print(f"  cnx=0x{ptr:x} cwin={cwin} bif={bif} "
                          f"sRTT={rtt_us}us "
                          f"pacing={pacing_mbps:.1f}Mbps "
                          f"lost={lost} sent={sent} recv={recv}"
                          f"{suspect}", file=file, flush=True)

        print(f"=== end counters ===", file=file, flush=True)

    def enable_sigusr2_dump(self, stream_ctxs_callable=None):
        """Install a SIGUSR2 handler that calls dump_counters().

        Must be called from the main thread (signal.signal limitation).
        If a handler is already installed for SIGUSR2, it is replaced.
        Returns the previous handler so the caller can chain if desired.

        `stream_ctxs_callable`, if provided, is invoked at signal time
        to gather a {stream_id: sc_ptr} dict (usually `lambda:
        my_conn._stream_ctxs.copy()`). Without it the dump shows only
        connection-global counters."""
        import signal
        def _handler(*_args):
            stream_ctxs = stream_ctxs_callable() if stream_ctxs_callable else None
            self.dump_counters(stream_ctxs=stream_ctxs)
        prev = signal.signal(signal.SIGUSR2, _handler)
        return prev

    def tx_data_ring_used(self, uintptr_t sc_ptr):
        """Bytes currently sitting in a given stream's sc->tx data
        ring, not yet consumed by the picoquic worker's
        prepare_to_send.

        This is the load-bearing back-pressure signal in the pull
        model: payload bytes live in the per-stream data ring;
        connection-global event-ring metrics describe MARK_ACTIVE
        notifications and carry no payload. Callers can compare this
        against an absolute byte budget (latency-bound queue depth)
        on a per-stream basis.

        sc_ptr is the opaque pointer kept in the Python connection's
        per-stream wrapper map (`_stream_ctxs[stream_id]`). Returns 0
        for NULL or a stream that has not yet allocated sc->tx.
        """
        if sc_ptr == 0:
            return 0
        cdef aiopquic_stream_ctx_t* sc = <aiopquic_stream_ctx_t*><void*>sc_ptr
        if sc.tx is NULL:
            return 0
        return aiopquic_stream_buf_used(sc.tx)

    def tx_data_ring_sent(self, uintptr_t sc_ptr):
        """Cumulative bytes picoquic has taken from a stream's sc->tx ring
        into packets; monotonic. 0 for NULL or a stream without sc->tx."""
        if sc_ptr == 0:
            return 0
        cdef aiopquic_stream_ctx_t* sc = <aiopquic_stream_ctx_t*><void*>sc_ptr
        if sc.tx is NULL:
            return 0
        return aiopquic_stream_buf_sent(sc.tx)

    def set_tx_data_drain_pending(self, uintptr_t sc_ptr):
        """Arm the per-stream sc->tx drain signal so the next worker
        drain of sc->tx (in prepare_to_send) fires SPSC_EVT_STREAM_TX_DRAINED
        and wakes the producer waiting on the per-stream asyncio.Event.

        Use with the clear-arm-recheck-wait pattern on the per-stream
        event when waiting on a soft byte threshold below sc->tx full —
        e.g. a tx_max_inflight_bytes cap whose wakeup must align with
        sc->tx drain, NOT the connection-global SPSC ring drain. Pairs
        with `tx_data_ring_used(sc_ptr)` for the byte measurement.
        """
        if sc_ptr == 0:
            return
        cdef aiopquic_stream_ctx_t* sc = <aiopquic_stream_ctx_t*><void*>sc_ptr
        aiopquic_set_tx_data_drain_pending(sc)

    def clear_tx_data_drain_pending(self, uintptr_t sc_ptr):
        """Clear the per-stream sc->tx drain signal. Called by the
        producer when a recheck shows pressure dropped between arm and
        wait, to avoid spurious wakes."""
        if sc_ptr == 0:
            return
        cdef aiopquic_stream_ctx_t* sc = <aiopquic_stream_ctx_t*><void*>sc_ptr
        aiopquic_clear_tx_data_drain_pending(sc)

    # -- connection snapshots ------------------------------------------
    # picoquic cnx state belongs to the worker thread, which frees it. The
    # worker sends copies (aiopquic_cnx_snapshot_t) with READY, with a
    # server's ALMOST_READY, with WT session READY, with SPSC_EVT_CNX_STACK,
    # ahead of WT NEW_SESSION and in answer to SPSC_EVT_TX_CNX_REFRESH; the
    # accessors below read only those copies.

    cdef object _store_snapshot(self, uintptr_t cnx_ptr, void* buf,
                                Py_ssize_t length):
        if length == sizeof(aiopquic_cnx_snapshot_t):
            self._cnx_snapshots[cnx_ptr] = PyBytes_FromStringAndSize(
                <char*>buf, length)
        free(buf)

    cdef object _forget_snapshot(self, uintptr_t cnx_ptr):
        """Drop a closed cnx's snapshot at the next drain, so this drain's
        handlers still read final values. Skipped if a new cnx at the same
        address has replaced it by then."""
        snap = self._cnx_snapshots.get(cnx_ptr)
        if snap is not None:
            self._snapshot_drops.append((cnx_ptr, snap))

    cdef object _begin_drain_cycle(self):
        """Apply snapshot drops deferred from the last drain, reopen
        refreshes for every cnx and post ring releases a full TX ring
        refused."""
        if self._ctx.dgram_release_owed_n:
            aiopquic_dgram_ring_release_flush(self._ctx)
        if self._refresh_posted:
            self._refresh_posted.clear()
        if not self._snapshot_drops:
            return
        for cnx_ptr, snap in self._snapshot_drops:
            if self._cnx_snapshots.get(cnx_ptr) is snap:
                del self._cnx_snapshots[cnx_ptr]
        self._snapshot_drops = []

    cdef object _post_refresh(self, uintptr_t cnx_ptr):
        """Ask the worker for a fresh snapshot, at most once per cnx per
        drain cycle. With the TX event ring full this refresh is skipped;
        a later call asks again."""
        cdef spsc_entry_t entry
        if self._thread_ctx is NULL or cnx_ptr in self._refresh_posted:
            return
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_CNX_REFRESH
        entry.cnx = <void*>cnx_ptr
        if spsc_ring_push(self._ctx.tx_event_ring, &entry, NULL, 0) != 0:
            return
        self._refresh_posted.add(cnx_ptr)
        self._ctx.cnt_tx_event_ring_pushes += 1
        if aiopquic_tx_wake_needed(self._ctx):
            picoquic_wake_up_network_thread(self._thread_ctx)

    cdef object _snapshot(self, uintptr_t cnx_ptr, bint refresh):
        """The cached snapshot bytes for a cnx, or None. Posts a refresh
        when asked to, or when nothing is cached yet."""
        snap = self._cnx_snapshots.get(cnx_ptr)
        if refresh or snap is None:
            self._post_refresh(cnx_ptr)
        return snap

    def session_resumed(self, uintptr_t cnx_ptr):
        """Whether the cnx's TLS handshake resumed a session (PSK). False
        on a NULL cnx or before its first snapshot."""
        if cnx_ptr == 0:
            return False
        snap = self._snapshot(cnx_ptr, False)
        if snap is None:
            return False
        cdef const aiopquic_cnx_snapshot_t* s = <const aiopquic_cnx_snapshot_t*><const char*>snap
        return s.session_resumed != 0

    def get_negotiated_alpn(self, uintptr_t cnx_ptr):
        """The ALPN protocol TLS actually negotiated for this cnx.

        picoquic settles the real ALPN at handshake; this returns it so
        callers don't have to assume their first offered protocol was
        selected (it isn't, when offering multiple). Returns None on a
        NULL cnx or before the cnx's first snapshot (READY, or
        SPSC_EVT_CNX_STACK under single-port dispatch).
        """
        if cnx_ptr == 0:
            return None
        snap = self._snapshot(cnx_ptr, False)
        if snap is None:
            return None
        cdef const aiopquic_cnx_snapshot_t* s = <const aiopquic_cnx_snapshot_t*><const char*>snap
        if s.alpn[0] == 0:
            return None
        return (<bytes>(<char*>s.alpn)).decode('ascii', 'replace')

    def transport_parameters(self, uintptr_t cnx_ptr, bint local=False):
        """Negotiated transport parameters as a dict — the REMOTE
        side's advertisement by default (local=False), i.e. what the
        peer sent in its TLS extension. The probe/fingerprinting
        surface: reads the values picoquic parsed, no qlog round trip.

        Limitations (picoquic parses into a struct): unknown/GREASE
        parameter ids are dropped and wire ORDER is not preserved —
        fall back to qlog/keylog+tshark for those signals.
        """
        if cnx_ptr == 0:
            return None
        snap = self._snapshot(cnx_ptr, False)
        if snap is None:
            return None
        cdef const aiopquic_cnx_snapshot_t* s = <const aiopquic_cnx_snapshot_t*><const char*>snap
        if not (s.has_tp_local if local else s.has_tp_remote):
            return None
        cdef const picoquic_tp_t* tp = &s.tp_local if local else &s.tp_remote
        return {
            'initial_max_data': tp.initial_max_data,
            'initial_max_stream_data_bidi_local':
                tp.initial_max_stream_data_bidi_local,
            'initial_max_stream_data_bidi_remote':
                tp.initial_max_stream_data_bidi_remote,
            'initial_max_stream_data_uni': tp.initial_max_stream_data_uni,
            'initial_max_streams_bidi': tp.initial_max_stream_id_bidir,
            'initial_max_streams_uni': tp.initial_max_stream_id_unidir,
            'max_idle_timeout': tp.max_idle_timeout,
            'max_udp_payload_size': tp.max_packet_size,
            'max_ack_delay': tp.max_ack_delay,
            'ack_delay_exponent': tp.ack_delay_exponent,
            'active_connection_id_limit': tp.active_connection_id_limit,
            'disable_active_migration': bool(tp.migration_disabled),
            'max_datagram_frame_size': tp.max_datagram_frame_size,
            'min_ack_delay': tp.min_ack_delay,
            'grease_quic_bit': bool(tp.do_grease_quic_bit),
            'enable_loss_bit': tp.enable_loss_bit,
            'enable_time_stamp': tp.enable_time_stamp,
        }

    def connection_ids(self, uintptr_t cnx_ptr):
        """Connection IDs as bytes: local, remote (peer's), and the
        client's initial DCID, as of the last worker snapshot; each call
        asks for a fresh one. QUIC-LB / routable-CID detection. None
        before the first snapshot."""
        if cnx_ptr == 0:
            return None
        snap = self._snapshot(cnx_ptr, True)
        if snap is None:
            return None
        cdef const aiopquic_cnx_snapshot_t* s = <const aiopquic_cnx_snapshot_t*><const char*>snap
        cdef const picoquic_connection_id_t* lo = &s.cid_local
        cdef const picoquic_connection_id_t* re = &s.cid_remote
        cdef const picoquic_connection_id_t* ini = &s.cid_initial
        return {
            'local': PyBytes_FromStringAndSize(<char*>lo.id, lo.id_len),
            'remote': PyBytes_FromStringAndSize(<char*>re.id, re.id_len),
            'initial': PyBytes_FromStringAndSize(<char*>ini.id, ini.id_len),
        }

    def peer_address(self, uintptr_t cnx_ptr):
        """The peer's (host, port) as of the last worker snapshot; each
        call asks for a fresh one. None on a NULL cnx, before the first
        snapshot, or while unknown."""
        if cnx_ptr == 0:
            return None
        snap = self._snapshot(cnx_ptr, True)
        if snap is None:
            return None
        cdef const aiopquic_cnx_snapshot_t* s = <const aiopquic_cnx_snapshot_t*><const char*>snap
        return _format_sockaddr(s.peer_addr.family,
                                PyBytes_FromStringAndSize(<char*>s.peer_addr.addr, 16),
                                s.peer_addr.port)

    def local_address(self, uintptr_t cnx_ptr):
        """This side's (host, port) on the connection's path, as
        peer_address()."""
        if cnx_ptr == 0:
            return None
        snap = self._snapshot(cnx_ptr, True)
        if snap is None:
            return None
        cdef const aiopquic_cnx_snapshot_t* s = <const aiopquic_cnx_snapshot_t*><const char*>snap
        return _format_sockaddr(s.local_addr.family,
                                PyBytes_FromStringAndSize(<char*>s.local_addr.addr, 16),
                                s.local_addr.port)

    def path_quality(self, uintptr_t cnx_ptr):
        """Snapshot of picoquic's path-quality metrics for the cnx.

        Returns a dict matching picoquic_path_quality_t. The
        load-bearing CC + FC observability surface: cwnd, in-flight
        bytes, smoothed RTT, pacing rate, loss counts, bytes
        sent/received. Use to detect BBR/CC pathologies (e.g. cwnd
        frozen at minimal value while bif tracks it 1:1 — the
        diagnostic signature of the BBR Startup-exit freeze observed
        on raw-QUIC P=1 loopback).

        Values are as of the last worker snapshot; each call asks for a
        fresh one. Returns an empty dict on NULL cnx_ptr (cnx torn down
        or never opened) or before the first snapshot; callers should
        treat empty as 'no data'.
        """
        if cnx_ptr == 0:
            return {}
        snap = self._snapshot(cnx_ptr, True)
        if snap is None:
            return {}
        cdef const aiopquic_cnx_snapshot_t* s = <const aiopquic_cnx_snapshot_t*><const char*>snap
        cdef const picoquic_path_quality_t* q = &s.path_quality
        return {
            'receive_rate_estimate': q.receive_rate_estimate,
            'pacing_rate': q.pacing_rate,
            'cwin': q.cwin,
            'rtt': q.rtt,
            'rtt_sample': q.rtt_sample,
            'rtt_variant': q.rtt_variant,
            'rtt_min': q.rtt_min,
            'rtt_max': q.rtt_max,
            'sent': q.sent,
            'lost': q.lost,
            'timer_losses': q.timer_losses,
            'spurious_losses': q.spurious_losses,
            'max_spurious_rtt': q.max_spurious_rtt,
            'max_reorder_delay': q.max_reorder_delay,
            'max_reorder_gap': q.max_reorder_gap,
            'bytes_in_transit': q.bytes_in_transit,
            'bytes_sent': q.bytes_sent,
            'bytes_received': q.bytes_received,
        }

    @property
    def tx_event_ring_capacity(self):
        """TX ring entry capacity (constant; for free-space pre-checks)."""
        return self._ctx.tx_event_ring.capacity

    @property
    def tx_event_ring_drain_event(self):
        """Connection-global asyncio.Event signaled when the worker
        observes the TX SPSC ring fill drop to/below the low-water
        mark while a Python writer has armed tx_event_ring_drain_pending.

        Used by stream_write_drain / send_stream_data_drained to
        avoid the per-stream-event hard-wait deadlock at the
        connection-global pressure threshold (the per-stream
        STREAM_TX_DRAINED only fires when sc->tx is full, NOT when
        the SPSC ring is full — so awaiting it under a
        ring-pressure check could hang forever).

        Lazy-allocated on first access so __cinit__ doesn't require
        a running event loop. """
        import asyncio
        if self._tx_event_ring_drain_event is None:
            self._tx_event_ring_drain_event = asyncio.Event()
        return self._tx_event_ring_drain_event

    def arm_tx_event_ring_drain_pending(self):
        """Arm SPSC_EVT_TX_EVENT_RING_DRAINED, fired once the TX event ring
        is at or below tx_event_ring_low_water. Returns True when the caller
        may await tx_event_ring_drain_event, False when the ring is already
        there (retry instead; the arm stays and may wake later).

            event = tx.tx_event_ring_drain_event
            event.clear()
            if tx.arm_tx_event_ring_drain_pending():
                await event.wait()
        """
        return aiopquic_arm_tx_event_ring_drain_pending(self._ctx) != 0

    def clear_tx_event_ring_drain_pending(self):
        """Clear the arm without waiting. Unsafe while another waiter
        relies on the same arm."""
        aiopquic_clear_tx_event_ring_drain_pending(self._ctx)

    cdef int _hold_batch_ref(self, void* ptr, bint is_link) except -1:
        cdef size_t cap
        cdef batch_ref_t* grown
        if self._batch_refs_n == self._batch_refs_cap:
            cap = self._batch_refs_cap * 2 if self._batch_refs_cap else 64
            grown = <batch_ref_t*>realloc(self._batch_refs,
                                          cap * sizeof(batch_ref_t))
            if grown is NULL:
                raise MemoryError("drain_rx batch references")
            self._batch_refs = grown
            self._batch_refs_cap = cap
        self._batch_refs[self._batch_refs_n].ptr = ptr
        self._batch_refs[self._batch_refs_n].is_link = is_link
        self._batch_refs_n += 1
        return 0

    cdef void _release_batch_refs(self) noexcept:
        cdef size_t i
        cdef size_t n = self._batch_refs_n
        self._batch_refs_n = 0
        for i in range(n):
            if self._batch_refs[i].is_link:
                if self._ctx is not NULL:
                    self._ctx.cnt_sc_destroy_wt_link_callback_free += 1
                aiopquic_wt_stream_link_destroy(
                    <aiopquic_wt_stream_link_t*>self._batch_refs[i].ptr)
            else:
                aiopquic_stream_ctx_destroy(
                    <aiopquic_stream_ctx_t*>self._batch_refs[i].ptr)

    def release_batch(self):
        """Drop the references the last drain_rx batch holds. Call once
        every event of the batch has been handled; the next drain_rx and
        stop() also release them."""
        self._release_batch_refs()

    def drain_rx(self, int max_events=256):
        """
        Drain events from the RX ring.

        Returns a list of
            (event_type, stream_id, data, is_fin, error_code,
             cnx_ptr, stream_ctx_ptr, sc_ptr).

        sc_ptr is the BORROWED per-stream aiopquic_stream_ctx_t pointer
        (as uintptr_t) for events that carry one — STREAM_DATA,
        STREAM_FIN, STREAM_CREATED, NEW_STREAM. 0 otherwise. WT callers
        stash this in their _stream_tx_ctxs[sid] dict to feed back into
        push_stream_data; raw-QUIC callers can ignore it (their sc is
        already on entry.stream_ctx).

        `data` is a memoryview over an internal StreamChunk, or None for
        events without payload. The chunk owns its buffer; the memoryview
        keeps it alive via PEP 3118 buffer protocol refcount. No copy
        after picoquic.

        SPSC_EVT_WT_STREAM_LINK_RELEASE is handled internally and never
        emitted.

        Every stream context and WT link the batch names stays alive until
        release_batch(), the next drain_rx or stop(): the references its
        events carried, STREAM_DESTROY's and LINK_RELEASE's included, are
        held rather than dropped while the batch is built. A handler may
        then act on any stream of the batch, even one retired by a later
        event in it.

        Order matters: drain entries FIRST, then call aiopquic_clear_rx
        which atomically (a) clears the producer-skip flag, (b) drains
        the wake-fd counter, (c) re-arms via a fresh wake-fd write if
        the ring is still non-empty (race recovery for producers that
        observed pending=1 and skipped their own wake while we were
        partway through draining).
        """
        events = []
        cdef int i
        cdef spsc_entry_t* entry
        cdef void* buf
        cdef Py_ssize_t length
        cdef uintptr_t sc_ptr

        cdef aiopquic_stream_ctx_t* sc
        cdef aiopquic_stream_buf_t* rx_sb
        cdef uint32_t avail
        # Per-cycle FC dedupe: collect (sc_ptr → (cnx_ptr, stream_id))
        # while draining; emit at most one OPEN_FLOW_CONTROL push per
        # stream per cycle, after the loop. Combined with the
        # hysteresis check inside _push_fc_credit, this keeps
        # tx_event_ring traffic at ~max(streams_per_cycle, advance_rate
        # / hysteresis_bytes) instead of per-chunk.
        cdef dict pending_fc = {}
        self._release_batch_refs()
        self._begin_drain_cycle()
        spsc_ring_refill_from_overflow(self._ctx.rx_event_ring,
                                       &self._ctx.rx_overflow)
        cdef uint64_t consumed0 = aiopquic_rx_consumed(self._ctx)
        for i in range(max_events):
            entry = spsc_ring_peek(self._ctx.rx_event_ring)
            if entry is NULL:
                if spsc_ring_refill_from_overflow(
                        self._ctx.rx_event_ring, &self._ctx.rx_overflow) == 0:
                    break
                continue

            # LINK_RELEASE is internal: free the link with the batch.
            if entry.event_type == SPSC_EVT_WT_STREAM_LINK_RELEASE:
                if entry.data_buf is not NULL:
                    self._hold_batch_ref(entry.data_buf, True)
                spsc_ring_pop(self._ctx.rx_event_ring)
                continue

            # WT_STREAM_DESTROY: surface to user code for dict cleanup.
            # Pushed just before LINK_RELEASE so Python sees it while
            # the link + sc are still alive. stream_ctx carries the
            # session pointer for dispatcher routing (NOT an sc), so
            # no internal destroy — LINK_RELEASE owns the sc ref drop.
            if entry.event_type == SPSC_EVT_WT_STREAM_DESTROY:
                events.append((
                    entry.event_type,
                    entry.stream_id,
                    None,
                    0,
                    0,
                    <uintptr_t>entry.cnx,
                    <uintptr_t>entry.stream_ctx,
                    <uintptr_t>0,
                ))
                spsc_ring_pop(self._ctx.rx_event_ring)
                continue

            # STREAM_DESTROY fires once per stream when picoquic
            # considers it fully retired. Surface to user code so the
            # consumer (QuicConnection / WebTransportSession) can pop
            # its per-stream dicts. stream_ctx_ptr names the sc whose
            # stream-lifetime ref the batch drops; the consumer must not
            # keep the pointer past the batch.
            if entry.event_type == SPSC_EVT_STREAM_DESTROY:
                events.append((
                    entry.event_type,
                    entry.stream_id,
                    None,
                    0,
                    0,
                    <uintptr_t>entry.cnx,
                    <uintptr_t>entry.stream_ctx,
                    <uintptr_t>0,
                ))
                if entry.stream_ctx is not NULL:
                    aiopquic_cnt_sc_destroy_rx_event_inc()
                    self._hold_batch_ref(entry.stream_ctx, False)
                spsc_ring_pop(self._ctx.rx_event_ring)
                continue

            # TX_RING_DRAINED is internal: set the connection-global
            # asyncio.Event so any awaiting writer wakes. Worker fired
            # this because tx_event_ring_drain_pending was armed and the
            # ring count just dropped below tx_event_ring_low_water.
            if entry.event_type == SPSC_EVT_TX_EVENT_RING_DRAINED:
                if self._tx_event_ring_drain_event is not None:
                    self._tx_event_ring_drain_event.set()
                spsc_ring_pop(self._ctx.rx_event_ring)
                continue

            # A cnx snapshot answering a refresh: cache it, never deliver.
            if entry.event_type == SPSC_EVT_CNX_SNAPSHOT:
                if entry.data_length > 0 and entry.data_buf is not NULL:
                    length = entry.data_length
                    self._store_snapshot(<uintptr_t>entry.cnx,
                                         spsc_ring_take_data(entry), length)
                spsc_ring_pop(self._ctx.rx_event_ring)
                continue

            data = None
            sc_ptr = 0
            if entry.data_length > 0 and entry.data_buf is not NULL:
                # Inline-payload path (datagrams, NEW_SESSION path bytes,
                # etc.) — not tied to a per-stream sc, no FC accounting.
                length = entry.data_length
                buf = spsc_ring_take_data(entry)
                if (entry.event_type == SPSC_EVT_READY or
                        entry.event_type == SPSC_EVT_ALMOST_READY or
                        entry.event_type == SPSC_EVT_CNX_STACK or
                        entry.event_type == SPSC_EVT_WT_SESSION_READY):
                    # A cnx snapshot: cache it; deliver the event bare.
                    self._store_snapshot(<uintptr_t>entry.cnx, buf, length)
                else:
                    data = memoryview(StreamChunk._wrap(
                        buf, length, NULL, NULL, NULL, 0))
            elif (entry.event_type == SPSC_EVT_STREAM_DATA or
                  entry.event_type == SPSC_EVT_STREAM_FIN) and \
                  entry.stream_ctx is not NULL:
                # Canonical raw-QUIC RX path: bytes live on the per-stream
                # ring. Pop into a StreamChunk wired with sc back-pointer
                # so __dealloc__ can re-open peer FC when the consumer
                # releases. Per-stream backpressure: peer's effective
                # window = sc->rx_buf_free - sc->bytes_pending_release.
                sc = <aiopquic_stream_ctx_t*>entry.stream_ctx
                # RX data-event coalescing: clear BEFORE popping so a
                # worker arrival racing the pop re-arms a fresh
                # notification (worst case one harmless empty event).
                aiopquic_stream_ctx_rx_event_pending_clear(sc)
                rx_sb = sc.rx
                if rx_sb is not NULL:
                    avail = aiopquic_stream_buf_used(rx_sb)
                    if avail > 0:
                        length = avail
                        buf = malloc(<size_t>length)
                        if buf is not NULL:
                            aiopquic_stream_buf_pop(
                                rx_sb, <uint8_t*>buf, <uint32_t>length)
                            aiopquic_sc_rx_bytes_popped_add(<uint64_t>length)
                            data = memoryview(StreamChunk._wrap(
                                buf, length, self._ctx, sc,
                                <void*>entry.cnx, entry.stream_id))
                            aiopquic_stream_ctx_rx_consumed_add(
                                sc, <uint64_t>length)
                            _pending_fc_add(pending_fc, sc, entry.cnx, entry.stream_id)
            elif entry.data_buf is not NULL and entry.data_length == 0:
                # BORROWED-sc convention: data_buf is an aiopquic_stream_ctx_t*
                # we don't own. Used by WT STREAM_DATA / STREAM_FIN (bytes
                # in sc->rx) and by NEW_STREAM / STREAM_CREATED (sc passed
                # up so Python can stash it in _stream_tx_ctxs[sid]).
                # Expose sc_ptr in the tuple for all of them.
                sc = <aiopquic_stream_ctx_t*>entry.data_buf
                sc_ptr = <uintptr_t>sc
                if (entry.event_type == SPSC_EVT_WT_STREAM_DATA or
                        entry.event_type == SPSC_EVT_WT_STREAM_FIN):
                    # RX data-event coalescing: clear BEFORE popping so a
                    # worker arrival racing the pop re-arms a fresh
                    # notification.
                    aiopquic_stream_ctx_rx_event_pending_clear(sc)
                    rx_sb = sc.rx
                    if rx_sb is not NULL:
                        avail = aiopquic_stream_buf_used(rx_sb)
                        if avail > 0:
                            length = avail
                            buf = malloc(<size_t>length)
                            if buf is not NULL:
                                aiopquic_stream_buf_pop(
                                    rx_sb, <uint8_t*>buf, <uint32_t>length)
                                aiopquic_sc_rx_bytes_popped_add(<uint64_t>length)
                                data = memoryview(StreamChunk._wrap(
                                    buf, length, self._ctx, sc,
                                    <void*>entry.cnx, entry.stream_id))
                                aiopquic_stream_ctx_rx_consumed_add(
                                    sc, <uint64_t>length)
                                _pending_fc_add(pending_fc, sc, entry.cnx, entry.stream_id)

            # Cython-side coalescing: when the picoquic worker fires
            # multiple stream_data callbacks for the same stream
            # rapidly, each pushes an SPSC event but the FIRST drain
            # pops all of sc->rx. Subsequent events for that stream
            # carry data=None — pure dispatch waste. Skip them. FIN
            # events still emit since they signal end-of-stream
            # regardless of data presence.
            if (data is None and
                (entry.event_type == SPSC_EVT_STREAM_DATA or
                 entry.event_type == SPSC_EVT_WT_STREAM_DATA)):
                aiopquic_rx_event_release(entry)
                spsc_ring_pop(self._ctx.rx_event_ring)
                continue

            events.append((
                entry.event_type,
                entry.stream_id,
                data,
                entry.is_fin,
                entry.error_code,
                <uintptr_t>entry.cnx,
                <uintptr_t>entry.stream_ctx,
                sc_ptr,
            ))
            if (entry.event_type == SPSC_EVT_CLOSE or
                    entry.event_type == SPSC_EVT_APP_CLOSE or
                    entry.event_type == SPSC_EVT_WT_SESSION_CLOSED or
                    entry.event_type == SPSC_EVT_WT_SESSION_REFUSED):
                self._forget_snapshot(<uintptr_t>entry.cnx)
            if (entry.stream_ctx is not NULL and
                    aiopquic_rx_event_owns_sc(entry.event_type)):
                self._hold_batch_ref(entry.stream_ctx, False)
            spsc_ring_pop(self._ctx.rx_event_ring)

        # Per-cycle FC dedupe flush: emit at most one push per stream
        # for the work just performed. Hysteresis inside
        # _push_fc_credit filters further.
        self._flush_pending_fc(pending_fc)
        aiopquic_wake_trace_add(
            &self._ctx.asyncio_trace, AIOPQUIC_WAKE_DRAIN,
            <uint32_t>(aiopquic_rx_consumed(self._ctx) - consumed0),
            spsc_ring_count(self._ctx.rx_event_ring))
        aiopquic_clear_rx(self._ctx)
        return events

    cdef int _flush_pending_fc(self, dict pending_fc) except -1:
        """One credit push per stream noted this cycle, then drop the
        reference each note holds."""
        cdef uintptr_t sc_uint
        cdef uintptr_t cnx_uint
        cdef uint64_t sid_uint
        for sc_uint, (cnx_uint, sid_uint) in pending_fc.items():
            self._push_fc_credit(
                <void*><uintptr_t>cnx_uint, sid_uint,
                <aiopquic_stream_ctx_t*><void*><uintptr_t>sc_uint)
            aiopquic_stream_ctx_destroy(
                <aiopquic_stream_ctx_t*><void*><uintptr_t>sc_uint)
        pending_fc.clear()
        return 0

    cdef inline void _push_fc_credit(self, void* cnx,
                                       uint64_t stream_id,
                                       aiopquic_stream_ctx_t* sc):
        """Push SPSC_EVT_TX_OPEN_FLOW_CONTROL onto tx_event_ring so
        the picoquic worker re-evaluates peer's MAX_STREAM_DATA for
        this stream.

        Hysteresis gate: skip the push unless the stream's rx_consumed
        has advanced by at least ring capacity >> 4 since the last
        push. Prevents a per-chunk FC storm — unthrottled, a multi-Gbps
        flow emits hundreds of thousands of OPEN_FLOW_CONTROL events
        per second, saturating the asyncio thread until it cannot
        drain the rx_event_ring and STREAM_DATA events drop.

        Hysteresis cost: peer's MAX_STREAM_DATA advances in
        ring_cap/16 steps instead of continuously. Peer has up to a
        full ring_cap of headroom at all times, so it never actually
        waits at typical rates.

        The worker (in the SPSC handler) computes effective_free
        = sc->rx_buf_free - sc->bytes_pending_release and calls
        picoquic_open_flow_control(grant). picoquic itself is
        monotonic — passing a value that doesn't advance is a no-op.

        Called only from drain_rx data paths (regular credit
        replenishment as peer data lands). StreamChunk.__getbuffer__
        used to also push, but per-chunk pushes were the storm root
        cause; getbuffer now only accounts pending_sub. """
        # Hysteresis: require rx_consumed to advance by at least
        # HYSTERESIS_BYTES (1/16 of advertise_cap, ~256KB at default
        # 4MB cap) before pushing. Tighter than ring_cap/4 so latency
        # stays low under continuous load (peer's window advances in
        # ~256KB steps = ~0.8ms at 2.5Gbps, well under typical p99
        # targets). Still ~256× lower event rate than per-chunk push.
        cdef uint64_t consumed = aiopquic_stream_ctx_rx_consumed_load(sc)
        cdef uint64_t last_push = aiopquic_stream_ctx_last_fc_push_consumed_load(sc)
        cdef uint64_t hysteresis = self._ctx.rx_data_ring_cap
        if hysteresis > 0:
            hysteresis >>= 4  # 1/16 of advertise_cap (~256KB default)
        else:
            hysteresis = 1 << 18  # 256 KB fallback
        if consumed - last_push < hysteresis:
            return
        aiopquic_stream_ctx_last_fc_push_consumed_store(sc, consumed)
        aiopquic_push_fc_credit(self._ctx, cnx, stream_id, <void*>sc)

    def drain_rx_callback(self, handler, int max_events=256):
        """Drain events and call handler() per entry — zero list/tuple
        allocation compared with drain_rx.

        handler is a callable invoked per ring entry as:
            handler(evt_type, stream_id, data, is_fin, error_code,
                    cnx_ptr, stream_ctx_ptr, sc_ptr)

        sc_ptr is the BORROWED per-stream aiopquic_stream_ctx_t pointer
        (uintptr_t) for events that carry one (WT STREAM_DATA/FIN,
        NEW_STREAM, STREAM_CREATED); 0 otherwise.

        SPSC_EVT_WT_STREAM_LINK_RELEASE is handled internally: drain_rx
        calls aiopquic_wt_stream_link_destroy and never invokes the
        handler. SPSC FIFO ordering guarantees every preceding
        STREAM_DATA/FIN/RESET for that stream has been processed first.

        Returns the number of entries drained (LINK_RELEASE counted).
        Same per-entry semantics as drain_rx (StreamChunk memoryview
        construction, byte-ring pop, rx_consumed advance, no-data
        coalescing).
        """
        cdef int i
        cdef int count = 0
        cdef spsc_entry_t* entry
        cdef void* buf
        cdef Py_ssize_t length
        cdef uintptr_t sc_ptr
        cdef aiopquic_stream_ctx_t* sc
        cdef aiopquic_stream_buf_t* rx_sb
        cdef uint32_t avail
        cdef dict pending_fc = {}
        self._begin_drain_cycle()
        spsc_ring_refill_from_overflow(self._ctx.rx_event_ring,
                                       &self._ctx.rx_overflow)
        for i in range(max_events):
            entry = spsc_ring_peek(self._ctx.rx_event_ring)
            if entry is NULL:
                if spsc_ring_refill_from_overflow(
                        self._ctx.rx_event_ring, &self._ctx.rx_overflow) == 0:
                    break
                continue

            if entry.event_type == SPSC_EVT_WT_STREAM_LINK_RELEASE:
                if entry.data_buf is not NULL:
                    self._ctx.cnt_sc_destroy_wt_link_callback_free += 1
                    aiopquic_wt_stream_link_destroy(
                        <aiopquic_wt_stream_link_t*>entry.data_buf)
                spsc_ring_pop(self._ctx.rx_event_ring)
                count += 1
                continue

            if entry.event_type == SPSC_EVT_WT_STREAM_DESTROY:
                # See matching block in drain_rx for rationale.
                handler(
                    entry.event_type,
                    entry.stream_id,
                    None,
                    0,
                    0,
                    <uintptr_t>entry.cnx,
                    <uintptr_t>entry.stream_ctx,
                    <uintptr_t>0,
                )
                spsc_ring_pop(self._ctx.rx_event_ring)
                count += 1
                continue

            if entry.event_type == SPSC_EVT_STREAM_DESTROY:
                # Surface to user code before dropping the ref. See
                # matching block in drain_rx for rationale.
                handler(
                    entry.event_type,
                    entry.stream_id,
                    None,
                    0,
                    0,
                    <uintptr_t>entry.cnx,
                    <uintptr_t>entry.stream_ctx,
                    <uintptr_t>0,
                )
                if entry.stream_ctx is not NULL:
                    aiopquic_cnt_sc_destroy_rx_event_inc()
                    aiopquic_stream_ctx_destroy(
                        <aiopquic_stream_ctx_t*>entry.stream_ctx)
                spsc_ring_pop(self._ctx.rx_event_ring)
                count += 1
                continue

            if entry.event_type == SPSC_EVT_TX_EVENT_RING_DRAINED:
                if self._tx_event_ring_drain_event is not None:
                    self._tx_event_ring_drain_event.set()
                spsc_ring_pop(self._ctx.rx_event_ring)
                count += 1
                continue

            if entry.event_type == SPSC_EVT_CNX_SNAPSHOT:
                if entry.data_length > 0 and entry.data_buf is not NULL:
                    length = entry.data_length
                    self._store_snapshot(<uintptr_t>entry.cnx,
                                         spsc_ring_take_data(entry), length)
                spsc_ring_pop(self._ctx.rx_event_ring)
                count += 1
                continue

            data = None
            sc_ptr = 0
            if entry.data_length > 0 and entry.data_buf is not NULL:
                length = entry.data_length
                buf = spsc_ring_take_data(entry)
                if (entry.event_type == SPSC_EVT_READY or
                        entry.event_type == SPSC_EVT_ALMOST_READY or
                        entry.event_type == SPSC_EVT_CNX_STACK or
                        entry.event_type == SPSC_EVT_WT_SESSION_READY):
                    # A cnx snapshot: cache it; deliver the event bare.
                    self._store_snapshot(<uintptr_t>entry.cnx, buf, length)
                else:
                    data = memoryview(StreamChunk._wrap(
                        buf, length, NULL, NULL, NULL, 0))
            elif (entry.event_type == SPSC_EVT_STREAM_DATA or
                  entry.event_type == SPSC_EVT_STREAM_FIN) and \
                  entry.stream_ctx is not NULL:
                sc = <aiopquic_stream_ctx_t*>entry.stream_ctx
                # RX data-event coalescing: clear BEFORE popping (see
                # drain_rx twin).
                aiopquic_stream_ctx_rx_event_pending_clear(sc)
                rx_sb = sc.rx
                if rx_sb is not NULL:
                    avail = aiopquic_stream_buf_used(rx_sb)
                    if avail > 0:
                        length = avail
                        buf = malloc(<size_t>length)
                        if buf is not NULL:
                            aiopquic_stream_buf_pop(
                                rx_sb, <uint8_t*>buf, <uint32_t>length)
                            aiopquic_sc_rx_bytes_popped_add(<uint64_t>length)
                            data = memoryview(StreamChunk._wrap(
                                buf, length, self._ctx, sc,
                                <void*>entry.cnx, entry.stream_id))
                            aiopquic_stream_ctx_rx_consumed_add(
                                sc, <uint64_t>length)
                            _pending_fc_add(pending_fc, sc, entry.cnx, entry.stream_id)
            elif entry.data_buf is not NULL and entry.data_length == 0:
                sc = <aiopquic_stream_ctx_t*>entry.data_buf
                sc_ptr = <uintptr_t>sc
                if (entry.event_type == SPSC_EVT_WT_STREAM_DATA or
                        entry.event_type == SPSC_EVT_WT_STREAM_FIN):
                    # RX data-event coalescing: clear BEFORE popping so a
                    # worker arrival racing the pop re-arms a fresh
                    # notification.
                    aiopquic_stream_ctx_rx_event_pending_clear(sc)
                    rx_sb = sc.rx
                    if rx_sb is not NULL:
                        avail = aiopquic_stream_buf_used(rx_sb)
                        if avail > 0:
                            length = avail
                            buf = malloc(<size_t>length)
                            if buf is not NULL:
                                aiopquic_stream_buf_pop(
                                    rx_sb, <uint8_t*>buf, <uint32_t>length)
                                aiopquic_sc_rx_bytes_popped_add(<uint64_t>length)
                                data = memoryview(StreamChunk._wrap(
                                    buf, length, self._ctx, sc,
                                    <void*>entry.cnx, entry.stream_id))
                                aiopquic_stream_ctx_rx_consumed_add(
                                    sc, <uint64_t>length)
                                _pending_fc_add(pending_fc, sc, entry.cnx, entry.stream_id)

            if (data is None and
                (entry.event_type == SPSC_EVT_STREAM_DATA or
                 entry.event_type == SPSC_EVT_WT_STREAM_DATA)):
                aiopquic_rx_event_release(entry)
                spsc_ring_pop(self._ctx.rx_event_ring)
                continue

            # The entry keeps its sc reference through the handler, which
            # may drop every other one (a close frees the connection's).
            try:
                handler(
                    entry.event_type,
                    entry.stream_id,
                    data,
                    entry.is_fin,
                    entry.error_code,
                    <uintptr_t>entry.cnx,
                    <uintptr_t>entry.stream_ctx,
                    sc_ptr,
                )
            except BaseException:
                self._flush_pending_fc(pending_fc)
                raise
            if (entry.event_type == SPSC_EVT_CLOSE or
                    entry.event_type == SPSC_EVT_APP_CLOSE or
                    entry.event_type == SPSC_EVT_WT_SESSION_CLOSED or
                    entry.event_type == SPSC_EVT_WT_SESSION_REFUSED):
                self._forget_snapshot(<uintptr_t>entry.cnx)
            aiopquic_rx_event_release(entry)
            spsc_ring_pop(self._ctx.rx_event_ring)
            count += 1

        # Per-cycle FC dedupe flush (same pattern as drain_rx).
        self._flush_pending_fc(pending_fc)
        aiopquic_clear_rx(self._ctx)
        return count

    def push_tx_event(self, uint32_t event_type, uint64_t stream_id,
                bytes data=None, uint64_t error_code=0,
                uintptr_t cnx_ptr=0, uintptr_t stream_ctx=0,
                uint8_t is_fin=0, uint32_t aux=0):
        """
        Push a command into the TX ring (asyncio → picoquic thread).

        stream_ctx is forwarded as the v_stream_ctx pointer for events
        that consume it (SPSC_EVT_TX_MARK_ACTIVE → picoquic_mark_active_stream).
        For the PULL-model send path it carries an aiopquic_stream_buf_t*.
        An sc on a reset, stop-sending, mark-active or flow-control event
        is referenced while the event is queued.

        is_fin is also reused as a small auxiliary flag: e.g.,
        SPSC_EVT_TX_SET_APP_FLOW_CONTROL uses it as the
        `use_app_flow_control` argument to picoquic_set_app_flow_control.
        aux is the reliable size of an SPSC_EVT_TX_STREAM_RESET.

        After pushing, caller should call wake_up() to signal the network thread.
        """
        cdef spsc_entry_t entry
        cdef const uint8_t* data_ptr = NULL
        cdef uint32_t data_len = 0

        entry.event_type = event_type
        entry.stream_id = stream_id
        entry.is_fin = is_fin
        entry.cnx = <void*>cnx_ptr
        entry.stream_ctx = <void*>stream_ctx
        entry.error_code = error_code
        entry.aux = aux

        if data is not None:
            data_ptr = <const uint8_t*>data
            data_len = <uint32_t>len(data)

        cdef int ret = aiopquic_tx_push_sc(self._ctx, &entry, data_ptr, data_len)
        if ret == 0:
            self._ctx.cnt_tx_event_ring_pushes += 1
        else:
            raise BufferError("TX ring buffer is full")

    def _test_push_rx(self, uint32_t event_type, uint64_t stream_id,
                      uintptr_t cnx_ptr=0, uintptr_t stream_ctx=0,
                      uint64_t error_code=0):
        """Test path: queue an RX event as the worker does, sc reference
        included. Only while no worker runs: it is the ring's producer."""
        if self._thread_ctx is not NULL:
            raise RuntimeError("worker running")
        cdef spsc_entry_t entry
        memset(&entry, 0, sizeof(entry))
        entry.event_type = event_type
        entry.stream_id = stream_id
        entry.cnx = <void*>cnx_ptr
        entry.stream_ctx = <void*>stream_ctx
        entry.error_code = error_code
        if aiopquic_rx_push_sc(self._ctx, &entry, NULL, 0) != 0:
            raise MemoryError("RX event push failed")

    def tx_send_atomic(self, uint64_t stream_id, bytes data,
                        bint end_stream, uintptr_t cnx_ptr,
                        uintptr_t stream_ctx,
                        uint32_t stream_ring_cap):
        """Atomic send_stream_data primitive — all-or-nothing.

        Composes ensure-tx-ring + tx-event-ring capacity check + per-
        stream byte-ring push + TX_MARK_ACTIVE event push + worker
        wake-up into one Cython call. Holds the GIL through all four
        steps so no other Python coroutine can interleave between the
        bytes-commit and the event-push that the previous Python-level
        composition exposed.

        On a retryable failure (return 1 or 2), no bytes are committed
        to sc->tx — caller may safely re-call with the SAME data buffer
        without risk of duplicating bytes on the wire.

        Returns:
            0   success — bytes pushed to sc->tx, MARK_ACTIVE event
                queued, worker notified
            1   TX event ring full (caller retries)
            2   per-stream send ring full (caller retries)
           -1   allocation failure (sc->tx couldn't be created)
        """
        cdef aiopquic_stream_ctx_t* sc = <aiopquic_stream_ctx_t*>stream_ctx
        cdef const uint8_t* data_ptr = NULL
        cdef uint32_t data_len = 0
        cdef spsc_entry_t entry
        cdef int rc

        self._send_calls += 1

        if data is not None:
            data_ptr = <const uint8_t*>data
            data_len = <uint32_t>len(data)

        # PRE-CHECK 1: TX event ring must have room for the
        # MARK_ACTIVE event we'll push after committing bytes.
        # Without this, retry semantics duplicate bytes on the wire.
        # Single-producer (asyncio thread) ⇒ no TOCTOU window.
        if (spsc_ring_count(self._ctx.tx_event_ring) >= self._ctx.tx_event_ring.capacity
                and aiopquic_arm_tx_event_ring_drain_pending(self._ctx)):
            # Armed before returning rc=1, so the caller can await
            # tx_event_ring_drain_event without losing the wakeup. An arm
            # that finds the ring already drained falls through.
            self._send_busy_event_ring += 1
            return 1

        # COMMIT: push bytes to per-stream ring (atomic, all-or-nothing
        # internally; rc=0 means ring full, rc<0 alloc fail).
        rc = aiopquic_stream_ctx_send_data(
            sc, data_ptr, data_len, stream_ring_cap, end_stream)
        if rc == -2:
            raise ValueError(
                f"write of {data_len} bytes exceeds the stream ring "
                f"(stream={stream_id}, cap={stream_ring_cap})")
        if rc == 0:
            self._send_busy_stream_ring += 1
            return 2
        if rc < 0:
            self._send_alloc_fail += 1
            return -1
        if data_len > 0:
            aiopquic_tx_data_bytes_pushed_add(<uint64_t>data_len)

        # An armed stream is active in picoquic, which pulls these bytes
        # without a MARK_ACTIVE or a wake.
        if not aiopquic_stream_ctx_tx_arm(sc):
            self._ctx.cnt_tx_mark_active_skipped += 1
            return 0

        # Push MARK_ACTIVE event. Pre-check above guarantees room
        # under the single-producer asyncio invariant. The post-check
        # below catches invariant violations rather than masking them.
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_MARK_ACTIVE
        entry.stream_id = stream_id
        entry.cnx = <void*>cnx_ptr
        entry.stream_ctx = <void*>sc
        rc = aiopquic_tx_push_sc(self._ctx, &entry, NULL, 0)
        if rc == 0:
            self._ctx.cnt_tx_event_ring_pushes += 1
        else:
            aiopquic_stream_ctx_tx_disarm(sc)
            # Single-producer invariant violated — bytes are committed
            # to sc->tx but MARK_ACTIVE didn't post. Caller's retry
            # would re-commit and duplicate bytes. Arm the drain
            # signal so the caller wakes; the rc=1 path will trigger
            # again until the producer invariant is restored.
            aiopquic_arm_tx_event_ring_drain_pending(self._ctx)
            self._send_busy_event_ring += 1
            return 1

        # Wake only an idle worker; a running one drains the ring
        # before it waits.
        if self._thread_ctx is not NULL:
            if aiopquic_tx_wake_needed(self._ctx):
                picoquic_wake_up_network_thread(self._thread_ctx)

        return 0

    def tx_send_stream(self, uintptr_t cnx_ptr, uint64_t stream_id,
                        bytes data, bint end_stream=False,
                        uint32_t stream_ring_cap=AIOPQUIC_TX_DATA_RING_CAP_DEFAULT):
        """Test-friendly low-level pull-model send primitive.

        Wraps tx_send_atomic with per-(cnx, sid) stream-context lifecycle
        management. The first call for a given (cnx_ptr, stream_id)
        allocates an aiopquic_stream_ctx_t via the C helper; subsequent
        calls reuse it. The dict is process-local to this TransportContext.

        Production code should use QuicConnection.send_stream_data, which
        manages its own per-cnx _stream_ctxs dict and exposes a richer
        BufferError-based backpressure API. This method exists for the
        bare-TransportContext test path (tests/test_loopback.py and
        derived integration / bench tests) so tests don't need to wrap
        every TransportContext in a QuicConnection.

        Raises:
            BufferError: TX event ring or per-stream send ring is full
                — caller may retry the SAME data without risk of
                duplicating bytes on the wire (tx_send_atomic guarantees
                all-or-nothing on retryable failures).
            MemoryError: per-stream send ring allocation failed, or
                aiopquic_stream_ctx_create returned NULL on first use.
        """
        cdef aiopquic_stream_ctx_t* sc
        cdef uintptr_t sc_ptr
        cdef int rc
        key = (cnx_ptr, stream_id)
        cached = self._test_stream_ctxs.get(key)
        if cached is None:
            sc = aiopquic_stream_ctx_create()
            if sc is NULL:
                raise MemoryError("aiopquic_stream_ctx_create returned NULL")
            aiopquic_cnt_sc_create_python_helper_inc()
            sc_ptr = <uintptr_t>sc
            self._test_stream_ctxs[key] = sc_ptr
        else:
            sc_ptr = <uintptr_t>cached
        rc = self.tx_send_atomic(stream_id, data, end_stream,
                                  cnx_ptr, sc_ptr, stream_ring_cap)
        if rc == 1:
            raise BufferError(
                f"TX event ring full (stream={stream_id})"
            )
        if rc == 2:
            raise BufferError(
                f"per-stream send ring full "
                f"(stream={stream_id}, need={len(data) if data else 0})"
            )
        if rc < 0:
            raise MemoryError(
                f"tx_send_stream alloc failed (stream={stream_id})"
            )

    # ------------------------------------------------------------------
    # Pull-model datagram TX. The per-connection record ring is owned by
    # the caller (QuicConnection) via an opaque pointer; the worker's
    # cnx→ring table takes its own reference on first MARK. Payload
    # never rides the shared TX event ring.
    # ------------------------------------------------------------------

    def dgram_ring_create(self, uint32_t capacity, uint32_t max_record):
        """Allocate a per-connection datagram TX record ring.

        capacity is rounded up to a power of two; max_record is the
        producer-enforced payload cap (a QUIC DATAGRAM frame cannot be
        fragmented, so records larger than a fresh packet's space could
        never drain). Returns an opaque pointer; release with
        dgram_ring_release exactly once.
        """
        cdef aiopquic_dgram_buf_t* db = aiopquic_dgram_buf_create(
            capacity, max_record)
        if db is NULL:
            raise MemoryError("aiopquic_dgram_buf_create failed")
        return <uintptr_t>db

    def dgram_ring_release(self, uintptr_t db_ptr, uintptr_t cnx_ptr=0):
        """Drop the caller's reference; the last reference frees.

        With the worker running, the worker drops it after every MARK
        queued before this call, together with cnx_ptr's table entry
        while that still holds this ring. Otherwise it is dropped now.
        """
        aiopquic_dgram_ring_release(self._ctx, <void*>cnx_ptr,
                                    <aiopquic_dgram_buf_t*>db_ptr)

    def dgram_mark_ready(self, uintptr_t cnx_ptr, uintptr_t db_ptr):
        """Post (or re-post) the MARK_DATAGRAM_READY event for a ring
        with committed records. Returns 0 posted, 1 TX event ring full
        (retry later)."""
        cdef spsc_entry_t entry
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_MARK_DATAGRAM_READY
        entry.cnx = <void*>cnx_ptr
        entry.stream_ctx = <void*>db_ptr
        while spsc_ring_push(self._ctx.tx_event_ring, &entry, NULL, 0) != 0:
            if aiopquic_arm_tx_event_ring_drain_pending(self._ctx):
                return 1
        self._ctx.cnt_tx_event_ring_pushes += 1
        if self._thread_ctx is not NULL:
            if aiopquic_tx_wake_needed(self._ctx):
                picoquic_wake_up_network_thread(self._thread_ctx)
        return 0

    def dgram_send(self, uintptr_t cnx_ptr, uintptr_t db_ptr, bytes data):
        """Commit one datagram record and arm the scheduler.

        Returns:
          1  accepted (record committed, mark posted)
          2  accepted, mark NOT posted (TX event ring full) — caller
             must re-post via dgram_mark_ready before going idle, else
             the record may sit unscheduled
          0  record ring full — backpressure; retry the SAME payload
             after SPSC_EVT_DATAGRAM_TX_DRAINED (drain signal armed)
         -1  payload exceeds max_record — permanent, do not retry
        """
        cdef aiopquic_dgram_buf_t* db = <aiopquic_dgram_buf_t*>db_ptr
        cdef const uint8_t* buf = <const uint8_t*>PyBytes_AsString(data)
        cdef uint32_t n = <uint32_t>len(data)
        cdef int rc = aiopquic_dgram_buf_push_record(db, buf, n)
        if rc == 0:
            return 0
        if rc < 0:
            return -1
        if self.dgram_mark_ready(cnx_ptr, db_ptr) != 0:
            return 2
        return 1

    def set_stream_priority(self, uintptr_t cnx_ptr, uint64_t stream_id,
                            uint8_t priority):
        """Relative send priority for one stream (RFC 9000 §2.3). 0 is
        highest; picoquic's default is 9. Returns 0 posted, 1 TX event
        ring full (retry)."""
        cdef spsc_entry_t entry
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_SET_STREAM_PRIORITY
        entry.cnx = <void*>cnx_ptr
        entry.stream_id = stream_id
        entry.error_code = priority
        while spsc_ring_push(self._ctx.tx_event_ring, &entry, NULL, 0) != 0:
            if aiopquic_arm_tx_event_ring_drain_pending(self._ctx):
                return 1
        self._ctx.cnt_tx_event_ring_pushes += 1
        if self._thread_ctx is not NULL:
            if aiopquic_tx_wake_needed(self._ctx):
                picoquic_wake_up_network_thread(self._thread_ctx)
        return 0

    def set_default_stream_priority(self, uint8_t priority):
        """Priority newly created streams start at (picoquic default 9).
        Applies to streams created after the call."""
        if self._quic is NULL:
            raise ConnectionError("quic context not started")
        picoquic_set_default_priority(self._quic, priority)

    def set_max_connections(self, uint32_t n):
        """Refuse new connections while the context holds n or more; n is
        at most start()'s max_connections, and 0 refuses all. A refused
        client gets CONNECTION_REFUSED at once; existing connections are
        kept. Returns 0 posted, 1 TX event ring full (retry)."""
        cdef spsc_entry_t entry
        if self._thread_ctx is NULL:
            raise ConnectionError("network thread not running")
        if n > self._max_connections:
            raise ValueError(
                f"{n} is above start()'s max_connections {self._max_connections}")
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_SET_MAX_CONNECTIONS
        entry.error_code = n
        while spsc_ring_push(self._ctx.tx_event_ring, &entry, NULL, 0) != 0:
            if aiopquic_arm_tx_event_ring_drain_pending(self._ctx):
                return 1
        self._ctx.cnt_tx_event_ring_pushes += 1
        if aiopquic_tx_wake_needed(self._ctx):
            picoquic_wake_up_network_thread(self._thread_ctx)
        return 0

    def set_datagram_priority(self, uintptr_t cnx_ptr, uint8_t priority):
        """Datagram send priority against this connection's streams, on
        the stream scale (0 highest, picoquic default 9). Returns 0 posted,
        1 TX event ring full (retry)."""
        cdef spsc_entry_t entry
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_SET_DATAGRAM_PRIORITY
        entry.cnx = <void*>cnx_ptr
        entry.error_code = priority
        while spsc_ring_push(self._ctx.tx_event_ring, &entry, NULL, 0) != 0:
            if aiopquic_arm_tx_event_ring_drain_pending(self._ctx):
                return 1
        self._ctx.cnt_tx_event_ring_pushes += 1
        if self._thread_ctx is not NULL:
            if aiopquic_tx_wake_needed(self._ctx):
                picoquic_wake_up_network_thread(self._thread_ctx)
        return 0

    def set_default_datagram_priority(self, uint8_t priority):
        """Datagram priority new connections start at (picoquic default 9).
        Applies to connections created after the call."""
        if self._quic is NULL:
            raise ConnectionError("quic context not started")
        picoquic_set_default_datagram_priority(self._quic, priority)

    def dgram_push(self, uintptr_t db_ptr, bytes data):
        """Commit one datagram record WITHOUT arming a scheduler — the
        WebTransport path arms per control stream, not per connection.

        Returns len accepted, 0 ring full (drain signal armed), -1 when
        the payload exceeds max_record.
        """
        cdef aiopquic_dgram_buf_t* db = <aiopquic_dgram_buf_t*>db_ptr
        cdef const uint8_t* buf = <const uint8_t*>PyBytes_AsString(data)
        cdef uint32_t n = <uint32_t>len(data)
        cdef int rc = aiopquic_dgram_buf_push_record(db, buf, n)
        if rc == 0:
            return 0
        if rc < 0:
            return -1
        return <int>n

    def dgram_ring_stats(self, uintptr_t db_ptr):
        """Producer/consumer counters for one datagram ring."""
        cdef aiopquic_dgram_buf_t* db = <aiopquic_dgram_buf_t*>db_ptr
        return {
            'capacity': db.capacity,
            'max_record': db.max_record,
            'used': aiopquic_dgram_buf_used(db),
            'records_pushed': db.records_pushed,
            'push_full': db.push_full,
            'push_oversize': db.push_oversize,
            'records_popped': db.records_popped,
            'bytes_popped': db.bytes_popped,
            'head_deferred': db.head_deferred,
        }

    def datagram_payload_ceiling(self, uintptr_t cnx_ptr):
        """Guaranteed max datagram payload for this connection:
        min(local TP, remote TP, 1200). 0 = peer did not negotiate
        datagrams (doubles as the capability check). Read from the
        cnx snapshot taken at READY; TPs are immutable after the
        handshake."""
        if cnx_ptr == 0:
            return 0
        snap = self._snapshot(cnx_ptr, False)
        if snap is None:
            return 0
        cdef const aiopquic_cnx_snapshot_t* s = <const aiopquic_cnx_snapshot_t*><const char*>snap
        return s.dgram_ceiling

    def reset_stream_at_negotiated(self, uintptr_t cnx_ptr):
        """Both ends advertised reset_stream_at, so a reset keeps its
        reliable bytes. Read from the cnx snapshot, like
        datagram_payload_ceiling."""
        if cnx_ptr == 0:
            return False
        snap = self._snapshot(cnx_ptr, False)
        if snap is None:
            return False
        cdef const aiopquic_cnx_snapshot_t* s = <const aiopquic_cnx_snapshot_t*><const char*>snap
        return bool(s.has_tp_local and s.has_tp_remote
                    and s.tp_local.is_reset_stream_at_enabled
                    and s.tp_remote.is_reset_stream_at_enabled)

    def cnx_data_counters(self, uintptr_t cnx_ptr):
        """(bytes placed on the wire, bytes received from the wire) for
        the cnx, picoquic-side accounting, as of the last worker snapshot;
        each call asks for a fresh one. (0, 0) before the first snapshot.
        """
        if cnx_ptr == 0:
            return (0, 0)
        snap = self._snapshot(cnx_ptr, True)
        if snap is None:
            return (0, 0)
        cdef const aiopquic_cnx_snapshot_t* s = <const aiopquic_cnx_snapshot_t*><const char*>snap
        return (s.data_sent, s.data_received)

    @property
    def worker_dgram_mark_ready_processed(self):
        return self._ctx.worker_dgram_mark_ready_processed

    @property
    def worker_dgram_prepare_calls(self):
        return self._ctx.worker_dgram_prepare_calls

    @property
    def worker_dgram_records_sent(self):
        return self._ctx.worker_dgram_records_sent

    @property
    def worker_dgram_bytes_sent(self):
        return self._ctx.worker_dgram_bytes_sent

    @property
    def send_calls(self):
        """Total tx_send_atomic invocations."""
        return self._send_calls

    @property
    def send_busy_event_ring(self):
        """Times tx_send_atomic returned 1 (TX event ring full)."""
        return self._send_busy_event_ring

    @property
    def send_busy_stream_ring(self):
        """Times tx_send_atomic returned 2 (per-stream byte ring full)."""
        return self._send_busy_stream_ring

    @property
    def send_alloc_fail(self):
        """Times tx_send_atomic returned -1 (allocation failure)."""
        return self._send_alloc_fail

    @property
    def worker_mark_active_processed(self):
        """Worker thread: count of TX_MARK_ACTIVE events drained from
        tx_event_ring and dispatched to picoquic_mark_active_stream. If this
        is < send_calls, MARK_ACTIVE events are being lost in the ring
        between Python push and worker dequeue (which would be a real
        SPSC bug)."""
        return self._ctx.worker_mark_active_processed

    @property
    def worker_prepare_to_send_calls(self):
        """Worker thread: count of picoquic_callback_prepare_to_send
        invocations on this context. Compare against
        worker_mark_active_processed to see whether picoquic ever
        actually polled the streams it was asked to mark active."""
        return self._ctx.worker_prepare_to_send_calls

    @property
    def worker_prepare_to_send_pulled_bytes(self):
        """Worker thread: cumulative bytes pulled from sc->tx rings via
        prepare_to_send. Should equal total bytes Python pushed across
        all streams once everything is drained."""
        return self._ctx.worker_prepare_to_send_pulled_bytes

    @property
    def worker_rx_event_drops(self):
        """Worker thread: count of events dropped because the RX
        event ring (rx_event_ring) was full at push time. For stream_data
        events the bytes ARE in sc->rx but Python is never notified —
        Python only pops sc->rx if a LATER event for the same stream
        pushes successfully. This is the stream-loss bug root cause."""
        return self._ctx.worker_rx_event_drops

    @property
    def worker_rx_event_drops_stream_data(self):
        """Subset of worker_rx_event_drops that were stream_data /
        stream_fin events (vs control events like datagram/close)."""
        return self._ctx.worker_rx_event_drops_stream_data

    @property
    def worker_rx_byte_ring_overflow(self):
        """Worker thread: count of per-stream RX byte-ring overflow
        events. Indicates the peer sent more bytes than its
        flow-control window allowed (spec violation). Silent unless
        AIOPQUIC_RX_LOG=1 is set in the env."""
        return self._ctx.worker_rx_byte_ring_overflow

    def start(self, int port=0, cert_file=None, key_file=None,
              alpn=None, bint is_client=True, uint64_t idle_timeout_ms=30000,
              uint32_t max_datagram_frame_size=0,
              wt_path=None, debug_log=None, keylog_filename=None,
              uint32_t rx_data_ring_cap=0, congestion_control_algorithm=None,
              uint64_t initial_max_data=0,
              uint64_t initial_max_streams_uni=0,
              uint64_t initial_max_streams_bidi=0,
              uint64_t keep_alive_interval_ms=0,
              int socket_buffer_size=0,
              qlog_dir=None,
              wt_supported_protocols=None,
              alpn_list=None,
              bint dual=False,
              bint verify_peer=True,
              ca_file=None,
              key_exchange_groups=None,
              uint32_t max_connections=256,
              bint retry=False,
              int cipher_suite=0,
              uint64_t key_update_interval=0,
              ticket_file=None,
              web_folder=None,
              int ip_family=-1,
              pmtud_policy=None,
              host=None,
              bint reset_stream_at=True,
              congestion_control_options=None,
              bint packet_train_mode=False):
        """
        Create the picoquic context and start the network thread.

        Args:
            port: Local UDP port (0 = ephemeral for clients).
            cert_file: Path to TLS certificate (server mode).
            key_file: Path to TLS private key (server mode).
            alpn: Default ALPN string (e.g. "h3", "moq-chat").
            is_client: Client mode; servers do not verify peers.
            verify_peer: Client mode: verify the server's certificate chain
                and its name against the SNI. False accepts any
                certificate.
            ca_file: Client mode: PEM bundle of trusted roots. Default:
                certifi's bundle. A file with no loadable certificate
                raises rather than leaving verification off.
            key_exchange_groups: TLS key-exchange groups in preference
                order, IANA ids (KEX_X25519MLKEM768 first gives a
                post-quantum key share). Default: classic first,
                DEFAULT_KEY_EXCHANGE_GROUPS. picoquic keeps one order
                per process, so the last start() wins.
            idle_timeout_ms: Idle timeout in milliseconds.
            max_connections: Most connections the context holds at once;
                picoquic refuses new ones past it (CONNECTION_REFUSED).
            retry: Server mode: answer every first Initial with a Retry.
            cipher_suite: Restrict TLS to one IANA cipher suite (e.g.
                0x1303, ChaCha20-Poly1305); 0 offers all. Unknown values
                raise ValueError.
            key_update_interval: Packets per 1-RTT key phase; 0 keeps
                picoquic's default.
            ticket_file: Client mode: session ticket store, loaded at start
                and saved at stop, for resumption and 0-RTT.
            web_folder: Server mode with wt_path: serve files from this
                directory to HTTP/3 GET requests outside the WT path.
            pmtud_policy: picoquic path MTU discovery policy: "basic" (probe
                opportunistically), "delayed" (only with a lot to send) or
                "blocked"; None keeps picoquic's default (basic).
            ip_family: AF_INET, AF_INET6, or 0 for both; -1 picks both when
                an IPv6 socket can bind [::]:port, else AF_INET (with a
                warning unless the host has no IPv6).
            host: Listener address. None, "" or "::" bind the wildcard of
                the families ip_family selects; "0.0.0.0" the IPv4
                wildcard; an IP literal (IPv6 may carry a scope) only that
                address; a hostname at most one address per family. A
                bind failure raises OSError.
            rx_data_ring_cap: Per-stream RX byte ring, in bytes, and the
                advertised stream window. 0: a 4 MiB ring and picoquic's
                default window.
            reset_stream_at: Advertise RESET_STREAM_AT
                (draft-ietf-quic-reliable-stream-reset). WebTransport
                always advertises it.
            congestion_control_algorithm: picoquic algorithm name, matched
                exactly; an unknown name raises ValueError. None keeps
                picoquic's default (newreno).
            congestion_control_options: Option string for that algorithm,
                passed to picoquic as is, e.g. "Q0.02" for bbr.
            packet_train_mode: When pacing holds a connection back, wait
                for up to 10 packets of credit and send them together.
            max_datagram_frame_size: Max DATAGRAM frame size (0 = disabled).
            wt_path: Server-mode WebTransport path (e.g. "/moq").
                When set, uses h3zero_callback as picoquic's default
                callback and routes CONNECT-on-path to the WT bridge.
            keylog_filename: Path to write TLS secrets in NSS Key Log
                Format (Wireshark-compatible). When set, picoquic emits
                client/server randoms + master secrets per connection so
                packet captures can be decrypted offline. Requires
                picoquic built without PICOQUIC_WITHOUT_SSLKEYLOG.
        """
        if self._started:
            raise RuntimeError("Transport already started")
        check_congestion_control_algorithm(congestion_control_algorithm)
        check_congestion_control_options(congestion_control_options,
                                         congestion_control_algorithm)

        # Stash per-stream RX ring capacity on the C ctx so the
        # stream_data callback sizes per-stream byte rings to match the
        # configured max_stream_data window. The C-side ring allocator
        # handles power-of-two rounding internally; we just pass the
        # configured window verbatim. 0 leaves the C default in place.
        if rx_data_ring_cap > 0:
            self._ctx.rx_data_ring_cap = aiopquic_ceil_pow2_u32(rx_data_ring_cap)

        cdef const char* c_cert = NULL
        cdef const char* c_key = NULL
        cdef const char* c_alpn = NULL
        cdef const char* c_cert_root = NULL
        cdef bytes b_cert, b_key, b_alpn, b_alpn_csv, b_cert_root
        cdef uint16_t* c_groups = NULL
        cdef size_t n_groups = 0
        cdef size_t gi

        if is_client and verify_peer:
            if ca_file is None:
                import certifi
                ca_file = certifi.where()
            # picoquic silently falls back to no verification when its
            # root store comes up empty, so prove the bundle loads first.
            import ssl
            ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT).load_verify_locations(
                cafile=ca_file)
            b_cert_root = (ca_file.encode() if isinstance(ca_file, str)
                           else ca_file)
            c_cert_root = b_cert_root

        if cert_file is not None:
            b_cert = cert_file.encode() if isinstance(cert_file, str) else cert_file
            c_cert = b_cert
        if key_file is not None:
            b_key = key_file.encode() if isinstance(key_file, str) else key_file
            c_key = b_key
        if alpn is not None:
            b_alpn = alpn.encode() if isinstance(alpn, str) else alpn
            c_alpn = b_alpn
        # Multi-ALPN raw-QUIC: offer/allow a preference-ordered list
        # (newest first). default_alpn MUST be NULL so picoquic asks the
        # client callback for the ClientHello offer (request_alpn_list)
        # and lets the server's alpn_select_fn choose. Overrides any single
        # 'alpn' above. The select_fn is installed after picoquic_create.
        if alpn_list:
            b_alpn_csv = ",".join(alpn_list).encode()
            self._alpn_list_csv = b_alpn_csv
            aiopquic_ctx_set_alpn_list(self._ctx, <char*>self._alpn_list_csv)
            c_alpn = NULL

        cdef picoquic_stream_data_cb_fn default_cb_fn = aiopquic_stream_cb
        cdef void* default_cb_ctx = <void*>self._ctx
        cdef bytes wt_path_b
        if wt_path is not None and not is_client:
            wt_path_b = wt_path.encode() if isinstance(wt_path, str) else wt_path
            # Empty server path → picoquic's "*" wildcard (PR #2085).
            if wt_path_b == b"":
                wt_path_b = b"*"
            self._wt_path_bytes = wt_path_b
            self._wt_path_item.path = self._wt_path_bytes
            self._wt_path_item.path_length = len(self._wt_path_bytes)
            self._wt_path_item.path_callback = aiopquic_wt_server_path_callback
            self._wt_path_item.path_app_ctx = <void*>self._ctx
            # An extended CONNECT needs a route that names its :protocol;
            # h3zero takes either WebTransport token for this one.
            self._wt_path_item.connect_protocol = b"webtransport-h3"
            self._wt_path_item.connect_protocol_length = 15
            if web_folder is not None:
                self._web_folder = (web_folder.encode() if isinstance(web_folder, str)
                                    else web_folder)
                self._wt_params.web_folder = self._web_folder
            else:
                self._wt_params.web_folder = NULL
            self._wt_params.path_table = &self._wt_path_item
            self._wt_params.path_table_nb = 1
            if dual:
                # Single-port dual stack: default callback dispatches
                # per connection by negotiated ALPN. The default ctx
                # stays the bridge (aiopquic_ctx_t*), which the ALPN
                # selector also expects; the shim bootstraps h3
                # connections from these server params.
                self._ctx.dual_wt_params = <void*>&self._wt_params
                default_cb_fn = aiopquic_dispatch_cb
            else:
                default_cb_fn = aiopquic_wt_server_bootstrap_cb
                default_cb_ctx = <void*>&self._wt_params
            # Server WT subprotocol allowlist (CSV, e.g. "moqt-18, moqt-16").
            # Held as bytes on self so the borrowed pointer the bridge reads
            # in the WT path callback stays valid for picoquic's lifetime.
            if wt_supported_protocols:
                self._wt_supported_csv = (
                    wt_supported_protocols.encode()
                    if isinstance(wt_supported_protocols, str)
                    else wt_supported_protocols)
                self._ctx.wt_supported_protocols = <char*>self._wt_supported_csv

        # Register picoquic's full CC algorithm catalog. Without this,
        # picoquic_get_congestion_algorithm() returns NULL for ANY name
        # (the algorithm registry is empty by default), so
        # picoquic_set_default_congestion_algorithm_by_name() silently
        # stores NULL → new cnxs have cnx->congestion_alg == NULL →
        # alg_init is never called → cwin stays pinned at
        # PICOQUIC_CWIN_INITIAL (10 × MSS = 15360) for the connection's
        # entire lifetime. picoquicdemo, pico_sim, pqbench, and every
        # picoquic test driver all call this at startup; aiopquic
        # didn't, which is what capped raw-QUIC loopback throughput.
        # Idempotent — repeats just overwrite the same static array.
        picoquic_register_all_congestion_control_algorithms()

        cdef const char* c_ticket = NULL
        if ticket_file is not None:
            self._ticket_file = (ticket_file.encode() if isinstance(ticket_file, str)
                                 else ticket_file)
            c_ticket = self._ticket_file

        # Create picoquic context with the chosen default callback.
        self._quic = picoquic_create(
            max_connections,
            c_cert, c_key,
            c_cert_root,    # trusted roots; NULL unless a verifying client
            c_alpn,
            default_cb_fn,
            default_cb_ctx,
            NULL, NULL,     # no cnx_id callback
            NULL,           # no reset seed
            picoquic_current_time(),
            NULL,           # not simulated time
            c_ticket,       # client ticket store, loaded here, saved at stop
            NULL, 0)        # server ticket key: picoquic draws one

        if self._quic is NULL:
            raise RuntimeError("Failed to create picoquic context")

        self._ctx.quic = self._quic
        aiopquic_live_cnx_attach(self._ctx, self._quic)

        # Multi-ALPN server: install the selector so picoquic picks the
        # highest mutual ALPN from the client's offer (default_alpn is
        # NULL → the selector is consulted). Clients drive their offer via
        # the request_alpn_list callback instead, so they need no install.
        if alpn_list and not is_client:
            picoquic_set_alpn_select_fn_v2(self._quic, aiopquic_alpn_select_cb)

        # Congestion control, checked above. None keeps picoquic's
        # compile-time default (newreno).
        cdef bytes _b_cc
        cdef const char* _c_cc
        if congestion_control_algorithm is not None:
            _b_cc = (congestion_control_algorithm.encode()
                     if isinstance(congestion_control_algorithm, str)
                     else congestion_control_algorithm)
            _c_cc = _b_cc
            if congestion_control_options is None:
                picoquic_set_default_congestion_algorithm_by_name(
                    self._quic, _c_cc)
            else:
                self._cc_options = congestion_control_options.encode()
                picoquic_set_default_congestion_algorithm_ex(
                    self._quic, picoquic_get_congestion_algorithm(_c_cc),
                    self._cc_options)
        if packet_train_mode:
            picoquic_set_packet_train_mode(self._quic, 1)

        cdef bytes _b_log
        # Textlog: per-cnx human-readable log of every packet, ACK, FC
        # frame, CC state. Tiny vs qlog, perfect for "what was the
        # worker last doing." Explicit debug_log arg wins; otherwise
        # AIOPQUIC_TEXTLOG_FILE env var.
        _textlog = debug_log
        if _textlog is None:
            import os
            _env_log = os.environ.get("AIOPQUIC_TEXTLOG_FILE")
            if _env_log:
                _textlog = _env_log
        if _textlog is not None:
            picoquic_set_log_level(self._quic, 1)
            _b_log = _textlog.encode() if isinstance(_textlog, str) else _textlog
            picoquic_set_textlog(self._quic, _b_log)

        cdef bytes _b_keylog
        if keylog_filename is not None:
            _b_keylog = (keylog_filename.encode()
                         if isinstance(keylog_filename, str)
                         else keylog_filename)
            picoquic_enable_sslkeylog(self._quic, 1)
            picoquic_set_key_log_file(self._quic, _b_keylog)

        # qlog: per-cnx JSON traces of CC state, RTT, FC frames, etc.
        # picoquic writes one .qlog file per connection (named by initial
        # CID) into the given directory. Explicit qlog_dir arg wins; if
        # not provided, fall back to AIOPQUIC_QLOG_DIR env var so qlog
        # can be enabled from the shell without code changes. Directory
        # must already exist; picoquic doesn't create it.
        cdef bytes _b_qlog
        _qlog_dir = qlog_dir
        if _qlog_dir is None:
            import os
            _env_qlog = os.environ.get("AIOPQUIC_QLOG_DIR")
            if _env_qlog:
                _qlog_dir = _env_qlog
        if _qlog_dir is not None:
            _b_qlog = (_qlog_dir.encode()
                       if isinstance(_qlog_dir, str)
                       else _qlog_dir)
            picoquic_set_qlog(self._quic, _b_qlog)

        # picoquic sorts its key exchanges once per process, on the
        # first context; a different order here re-sorts for every
        # context, so the last start() wins.
        global _applied_key_exchange_groups
        groups = (DEFAULT_KEY_EXCHANGE_GROUPS if key_exchange_groups is None
                  else tuple(int(g) for g in key_exchange_groups))
        if groups and groups != _applied_key_exchange_groups:
            n_groups = len(groups)
            c_groups = <uint16_t*>malloc(n_groups * sizeof(uint16_t))
            if c_groups is NULL:
                raise MemoryError()
            try:
                for gi in range(n_groups):
                    c_groups[gi] = <uint16_t>groups[gi]
                picoquic_sort_key_exchange_algorithms(c_groups, n_groups)
            finally:
                free(c_groups)
            _applied_key_exchange_groups = groups

        if is_client and not verify_peer:
            picoquic_set_null_verifier(self._quic)

        if wt_path is not None and not is_client:
            picowt_set_default_transport_parameters(self._quic)

        if idle_timeout_ms > 0:
            picoquic_set_default_idle_timeout(self._quic, idle_timeout_ms)

        if retry and not is_client:
            picoquic_set_cookie_mode(self._quic, 1)
        if pmtud_policy is not None:
            picoquic_set_default_pmtud_policy(self._quic, _PMTUD_POLICIES[pmtud_policy])
        if cipher_suite != 0 and picoquic_set_cipher_suite(self._quic, cipher_suite) != 0:
            picoquic_free(self._quic)
            self._quic = NULL
            raise ValueError(f"unsupported cipher suite {cipher_suite:#06x}")
        if key_update_interval > 0:
            picoquic_set_default_crypto_epoch_length(self._quic, key_update_interval)

        # Keep-alive: stored on the ctx; the worker thread enables it
        # per-cnx at the ready callback (raw QUIC in callback.h, WT in
        # h3wt_callback.h). PING frames hold a quiet connection open
        # past the idle timeout — e.g. a flow-controlled subscriber
        # whose consumer stalled and back-pressured the sender silent.
        self._ctx.keep_alive_us = keep_alive_interval_ms * 1000

        # Default transport-parameter overrides. Both the per-stream
        # initial_max_stream_data window AND optional max_datagram_frame
        # are merged into the existing TP defaults. Setting the per-
        # stream window to match rx_data_ring_cap ensures the peer is told
        # at handshake time exactly how many bytes it may keep
        # unconsumed before MAX_STREAM_DATA must be extended — keeping
        # peer-allowed in-flight ≤ our RX ring capacity.
        cdef picoquic_tp_t tp
        cdef const picoquic_tp_t* cur_tp
        if (max_datagram_frame_size > 0 or rx_data_ring_cap > 0
                or initial_max_data > 0
                or initial_max_streams_uni > 0
                or initial_max_streams_bidi > 0):
            cur_tp = picoquic_get_default_tp(self._quic)
            if cur_tp != NULL:
                tp = cur_tp[0]
                if max_datagram_frame_size > 0:
                    tp.max_datagram_frame_size = max_datagram_frame_size
                if rx_data_ring_cap > 0:
                    tp.initial_max_stream_data_bidi_local = rx_data_ring_cap
                    tp.initial_max_stream_data_bidi_remote = rx_data_ring_cap
                    tp.initial_max_stream_data_uni = rx_data_ring_cap
                if initial_max_data > 0:
                    # Connection-level flow control. picoquic's default
                    # is 1 MiB which falls over hard on MP-loopback at
                    # multi-stream workloads — every 1 MiB of TX data
                    # forces a MAX_DATA roundtrip, capping throughput
                    # at ~1 MiB / RTT. Pass cfg.max_data here to size
                    # the connection window for sustained workloads.
                    tp.initial_max_data = initial_max_data
                if initial_max_streams_uni > 0:
                    # Per RFC 9000 §4.6 / §18.2: initial_max_streams_uni
                    # advertised to peer. Picoquic's struct uses
                    # initial_max_stream_id_unidir which is the
                    # equivalent field (max concurrent uni streams the
                    # peer may open against us). Picoquic enforces our
                    # outbound stream count against the peer's
                    # reciprocal advertisement, so this also indirectly
                    # bounds our open_uni_stream success rate.
                    tp.initial_max_stream_id_unidir = initial_max_streams_uni
                if initial_max_streams_bidi > 0:
                    tp.initial_max_stream_id_bidir = initial_max_streams_bidi
                picoquic_set_default_tp(self._quic, &tp)
        if initial_max_data > 0:
            # MAX_DATA slides at initial_max_data past bytes received
            # instead of growing with cwnd; bounds reorder memory (~6x).
            picoquic_set_max_data_control(self._quic, initial_max_data)
        if reset_stream_at:
            cur_tp = picoquic_get_default_tp(self._quic)
            if cur_tp != NULL:
                tp = cur_tp[0]
                tp.is_reset_stream_at_enabled = 1
                picoquic_set_default_tp(self._quic, &tp)

        # Configure packet loop parameters (must persist — picoquic stores a pointer)
        self._param.local_port = <unsigned short>port
        ip_family, bind_addrs = _bind_addresses(host, ip_family)
        if bind_addrs:
            if port:
                _bind_preflight(bind_addrs, port)
            for i, (family, address, scope_id) in enumerate(bind_addrs):
                _fill_sockaddr(address, port, &self._param.local_addr[i],
                               scope_id)
        elif ip_family < 0:
            v6_error = _ipv6_bind_error(port)
            if v6_error is None:
                ip_family = 0
            else:
                ip_family = AF_INET
                if v6_error.errno != _errno.EAFNOSUPPORT:
                    _log.warning("IPv6 bind on port %d failed (%s); using IPv4 only",
                                 port, v6_error)
        self._param.local_af = ip_family
        self._param.dest_if = 0
        # SO_RCVBUF/SO_SNDBUF request passed to picoquic. picoquic's own
        # default is 0 (kernel default, ~200 KB on Linux) — far too
        # small: at line-rate UDP loopback (~3 Gbps at QUIC MTU) 200 KB
        # drains in 0.5 ms, so bursty senders overrun the receive
        # buffer, the kernel drops packets, and whole streams disappear.
        # We default to 64 MiB; the kernel clamps the effective value to
        # net.core.rmem_max / wmem_max. Caller-overridable (0 = use the
        # 64 MiB default) — lower it to cap per-socket memory when
        # running many sockets, e.g. high subscriber-process fan-out.
        self._param.socket_buffer_size = (
            socket_buffer_size if socket_buffer_size > 0
            else 64 * 1024 * 1024)
        self._param.extra_socket_required = 0
        self._param.prefer_extra_socket = 0
        # GSO + max-send-length defaults are platform-specific. The
        # send_length_max field changes meaning depending on
        # do_not_use_gso:
        #   GSO on (Linux):  send_length_max caps the kernel-coalesced
        #     buffer size for UDP segmentation offload. 65535 = max
        #     stride; kernel splits into individual QUIC packets. Big
        #     win at high pps — fewer sendmmsg syscalls.
        #   GSO off (macOS, FreeBSD): send_length_max becomes the
        #     max size of a single UDP datagram passed to sendmsg.
        #     macOS net.inet.udp.maxdgram defaults to 9216 so anything
        #     larger hits EMSGSIZE. lo0 MTU is 16384.
        # Defaults: Linux gets GSO + 65535; Darwin gets GSO off +
        # picoquic's default (0). Env vars AIOPQUIC_GSO and
        # AIOPQUIC_SEND_LENGTH_MAX override either side.
        cdef bint _darwin = sys.platform == "darwin"
        cdef int _gso_default = 0 if _darwin else 1
        cdef size_t _slm_default = 0 if _darwin else 65535
        _gso_env = os.environ.get("AIOPQUIC_GSO")
        if _gso_env is not None:
            _gso_default = 0 if _gso_env in ("0", "false", "False") else 1
        _slm_env = os.environ.get("AIOPQUIC_SEND_LENGTH_MAX")
        if _slm_env is not None:
            try:
                _slm_default = <size_t>int(_slm_env)
            except (TypeError, ValueError):
                pass
        self._param.do_not_use_gso = 0 if _gso_default else 1
        self._param.send_length_max = _slm_default

        # Start the network thread
        cdef int ret = 0
        self._thread_ctx = picoquic_start_network_thread(
            self._quic, &self._param,
            aiopquic_loop_cb, <void*>self._ctx,
            &ret)

        if self._thread_ctx is NULL or ret != 0:
            picoquic_free(self._quic)
            self._quic = NULL
            raise RuntimeError(f"Failed to start network thread (ret={ret})")

        # Mirror the thread_ctx into the C-level ctx so C-side helpers
        # (aiopquic_push_fc_credit etc.) can wake the worker without
        # round-tripping through Python. picoquic_wake_up_network_thread
        # requires picoquic_network_thread_ctx_t*, NOT picoquic_quic_t*
        # — a type mismatch here is a silent UAF-class corruption.
        self._ctx.thread_ctx = self._thread_ctx

        self._max_connections = max_connections if max_connections > 0 else 1  # picoquic's floor
        self._started = True

    def stop(self, double drain_timeout=0.05):
        """Stop the network thread and free the picoquic context.

        Waits up to `drain_timeout` seconds for queued TX events to reach
        picoquic first. picoquic_delete_network_thread discards whatever
        is still in the ring, so a close pushed immediately before stop()
        would otherwise never be handed over at all.

        Draining the ring is not the same as the frames being sent:
        picoquic may still hold an unsent packet when the thread goes
        away. Callers that need the peer to see a clean close must wait
        on that themselves.

        __dealloc__ shuts down without this — sleeping during GC is not
        acceptable, and an abandoned context has no one left to wait for.
        """
        import time
        if self._thread_ctx is not NULL and self._ctx is not NULL:
            deadline = time.monotonic() + drain_timeout
            while spsc_ring_count(self._ctx.tx_event_ring) > 0:
                if time.monotonic() >= deadline:
                    break
                try:
                    self.wake_up()
                except Exception:
                    break
                time.sleep(0.001)
        self._shutdown()

    @property
    def started(self):
        """Whether the network thread is running."""
        return self._started

    @property
    def thread_ready(self):
        """Whether the network thread has completed initialization."""
        if self._thread_ctx is NULL:
            return False
        return self._thread_ctx.thread_is_ready != 0

    def wake_up(self):
        """Signal the network thread to process TX ring entries.

        Writes the wake only when the thread may be asleep: a running
        thread drains the ring before it waits.

        No-op when the network thread is stopped — teardown is a normal
        state for unsynchronized push_* callers (e.g. subgroup-task
        cancel handlers firing after the transport has shut down).
        """
        if self._thread_ctx is NULL or not aiopquic_tx_wake_needed(self._ctx):
            return
        cdef int ret = picoquic_wake_up_network_thread(self._thread_ctx)
        if ret != 0:
            raise RuntimeError(f"Failed to wake network thread (ret={ret})")

    def _tx_push_unwoken(self):
        """Queue a no-op TX event and skip the wake: a lost wake (test only)."""
        cdef spsc_entry_t entry
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_SET_STREAM_PRIORITY
        if spsc_ring_push(self._ctx.tx_event_ring, &entry, NULL, 0) != 0:
            raise BufferError("TX event ring full")
        self._ctx.cnt_tx_event_ring_pushes += 1

    def create_client_connection(self, str host, int port,
                                  str sni=None, str alpn=None,
                                  uint32_t desired_version=0):
        """
        Create a client QUIC connection (thread-safe).

        Pushes a CONNECT command to the TX ring; the network thread
        creates the connection and sends back an ALMOST_READY event
        with the cnx pointer via the RX ring.

        Args:
            host: Remote IPv4 or IPv6 address.
            port: Remote port.
            sni: Server Name Indication (defaults to host).
            alpn: ALPN to negotiate (uses context default if None).
            desired_version: QUIC version to move to by compatible version
                negotiation (e.g. 0x6b3343cf for QUIC v2); 0 stays in v1.
        """
        if not self._started:
            raise RuntimeError("Transport not started")

        # Payload: aiopquic_connect_params_t | sni | alpn
        cdef bytes b_sni = (sni or host).encode()
        cdef bytes b_alpn = alpn.encode() if alpn else b""

        cdef uint32_t sni_len = <uint32_t>len(b_sni)
        cdef uint32_t alpn_len = <uint32_t>len(b_alpn)
        cdef uint32_t hdr_size = sizeof(aiopquic_connect_params_t)
        cdef uint32_t total = hdr_size + sni_len + alpn_len

        cdef bytearray buf = bytearray(total)
        cdef uint8_t* p = <uint8_t*><char*>buf
        cdef aiopquic_connect_params_t* params = <aiopquic_connect_params_t*>p
        _fill_sockaddr(host, port, &params.addr)
        params.desired_version = desired_version
        params.sni_len = <uint16_t>sni_len
        params.alpn_len = <uint16_t>alpn_len
        p += hdr_size

        if sni_len > 0:
            memcpy(p, <const uint8_t*>b_sni, sni_len)
            p += sni_len
        if alpn_len > 0:
            memcpy(p, <const uint8_t*>b_alpn, alpn_len)

        # Push CONNECT command to TX ring
        cdef spsc_entry_t entry
        entry.event_type = SPSC_EVT_TX_CONNECT
        entry.stream_id = 0
        entry.is_fin = 0
        entry.cnx = NULL
        entry.stream_ctx = NULL
        entry.error_code = 0

        cdef bytes payload = bytes(buf)
        cdef int ret = spsc_ring_push(
            self._ctx.tx_event_ring, &entry,
            <const uint8_t*>payload, <uint32_t>len(payload))
        if ret != 0:
            raise BufferError("TX ring buffer is full")

        self._ctx.cnt_tx_event_ring_pushes += 1
        self.wake_up()


# =====================================================================
# WebTransport client session — Cython-side state holder.
#
# Owns one aiopquic_wt_session_t (allocated in C). Pushes WT TX commands
# into the TransportContext's tx_event_ring, then wakes the picoquic thread.
# Sync-only methods; the Python-level async wrapper in
# aiopquic.asyncio.webtransport handles futures + event routing.
# =====================================================================

cdef extern from "c/h3wt_callback.h":
    ctypedef struct aiopquic_wt_open_params_t:
        sockaddr_storage addr
        uint16_t sni_len
        uint16_t path_len
        uint16_t protocols_len
        uint8_t connect_protocol


# tp_clear would drop _transport, which __dealloc__ needs to tell whether
# picoquic still holds the session.
@cython.no_gc_clear
cdef class WebTransportSessionState:
    """C-side state for one WebTransport client session.

    Holds the aiopquic_wt_session_t pointer, which the picoquic-thread
    uses as the path_app_ctx in our WT path callback. Events for this
    session show up in drain_rx with stream_ctx_ptr == this pointer.
    """
    cdef aiopquic_wt_session_t* _wt
    cdef TransportContext _transport
    cdef bint _opened     # set after push_open; picoquic owns the
                           # session as path_app_ctx — must deregister
                           # before destroy.

    def __cinit__(self, TransportContext transport,
                  uintptr_t session_ptr=0):
        self._transport = transport
        if session_ptr != 0:
            self._wt = <aiopquic_wt_session_t*><void*>session_ptr
            self._opened = True
        else:
            self._wt = aiopquic_wt_session_create(transport._ctx)
            self._opened = False
            if self._wt is NULL:
                raise MemoryError("Failed to create WT session")

    def __dealloc__(self):
        """Free the session struct once picoquic cannot reach it.

        An opened session is named by picoquic (stream prefix, control
        stream, links) until TX_WT_DEREGISTER: a running worker frees it
        there. Once the worker is joined and picoquic freed, it is ours.
        Never opened, picoquic has no reference."""
        cdef spsc_entry_t entry
        cdef TransportContext tp = self._transport
        if self._wt is NULL:
            return
        if not self._opened:
            aiopquic_wt_session_destroy(self._wt)
        elif tp is None:
            # No way to tell whether picoquic still names it: leak.
            pass
        elif tp._thread_ctx is not NULL:
            memset(&entry, 0, sizeof(entry))
            entry.event_type = SPSC_EVT_TX_WT_DEREGISTER
            entry.cnx = <void*>self._wt
            entry.stream_ctx = <void*>self._wt
            # A full ring leaks the session rather than freeing it live.
            if spsc_ring_push(tp._ctx.tx_event_ring, &entry,
                              NULL, 0) == 0:
                tp._ctx.cnt_tx_event_ring_pushes += 1
            try:
                tp.wake_up()
            except Exception:
                pass
        elif tp._quic is NULL:
            aiopquic_wt_session_destroy(self._wt)
        self._wt = NULL

    @property
    def session_ptr(self):
        """Pointer to the aiopquic_wt_session_t struct (uintptr_t).

        Used by the asyncio dispatcher to route incoming events to
        the correct session: the picoquic-thread side stores this
        pointer in entry.stream_ctx for every WT event."""
        return <uintptr_t>self._wt

    @property
    def cnx_ptr(self):
        """Pointer to the picoquic_cnx_t (uintptr_t), valid after
        SESSION_READY. Used for TX_STREAM_DATA pushes that need cnx."""
        if self._wt is NULL or self._wt.cnx is NULL:
            return 0
        return <uintptr_t>self._wt.cnx

    @property
    def control_stream_id(self):
        if self._wt is NULL:
            return 0
        return self._wt.control_stream_id

    @property
    def negotiated_wt_protocol(self):
        """The WebTransport subprotocol negotiated for this session, or
        None. Server side: the first allowlist entry the client offered in
        WT-Available-Protocols.
        Client side: the WT-Protocol the server selected, read from the
        CONNECT response. Both are captured (copied) on the picoquic
        thread when the session is established, so this is safe to read
        after SESSION_READY (client) / NEW_SESSION (server)."""
        if self._wt is NULL or self._wt.wt_protocol is NULL:
            return None
        return (<bytes>self._wt.wt_protocol).decode('ascii', 'replace')

    def push_open(self, str host, int port, str path, str sni,
                  str wt_protocols="", int connect_protocol=0):
        """Push TX_WT_OPEN to the picoquic thread. Build the params
        payload (addr + sni + path + protocols), then push entry.

        wt_protocols is a comma-separated string of WT-Available-Protocols
        subprotocol identifiers (empty string = none, send NULL on wire).
        aiopquic does no interpretation; verbatim handed to picoquic.

        connect_protocol is AIOPQUIC_WT_CONNECT_*: 0 = "webtransport" with
        one "webtransport-h3" retry, 1 = "webtransport", 2 = "webtransport-h3".
        """
        cdef bytes b_sni = sni.encode()
        # Empty client path → "/" (HTTP/3 root, RFC 9114 §4.3.1).
        cdef bytes b_path = b"/" if path == "" else path.encode()
        cdef bytes b_protocols = wt_protocols.encode()
        cdef uint32_t sni_len = <uint32_t>len(b_sni)
        cdef uint32_t path_len = <uint32_t>len(b_path)
        cdef uint32_t protocols_len = <uint32_t>len(b_protocols)
        cdef uint32_t hdr_size = sizeof(aiopquic_wt_open_params_t)
        cdef uint32_t total = hdr_size + sni_len + path_len + protocols_len

        cdef bytearray buf = bytearray(total)
        cdef uint8_t* p = <uint8_t*><char*>buf
        # Layout: aiopquic_wt_open_params_t | sni | path | protocols
        cdef aiopquic_wt_open_params_t* params = <aiopquic_wt_open_params_t*>p
        _fill_sockaddr(host, port, &params.addr)
        params.sni_len = <uint16_t>sni_len
        params.path_len = <uint16_t>path_len
        params.protocols_len = <uint16_t>protocols_len
        params.connect_protocol = <uint8_t>connect_protocol
        memcpy(p + hdr_size, <const uint8_t*>b_sni, sni_len)
        memcpy(p + hdr_size + sni_len, <const uint8_t*>b_path, path_len)
        if protocols_len > 0:
            memcpy(p + hdr_size + sni_len + path_len,
                   <const uint8_t*>b_protocols, protocols_len)

        cdef spsc_entry_t entry
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_WT_OPEN
        entry.cnx = <void*>self._wt   # session ptr — C side downcasts
        entry.stream_ctx = <void*>self._wt
        cdef bytes payload = bytes(buf)
        cdef int ret = spsc_ring_push(
            self._transport._ctx.tx_event_ring, &entry,
            <const uint8_t*>payload, total)
        if ret != 0:
            raise BufferError("TX ring full (WT_OPEN)")
        self._opened = True
        self._transport._ctx.cnt_tx_event_ring_pushes += 1
        self._transport.wake_up()

    def push_create_stream(self, bint bidir, bytes initial=b"",
                           bint end_stream=False,
                           uint32_t stream_ring_cap=AIOPQUIC_TX_DATA_RING_CAP_DEFAULT,
                           int priority=-1):
        """Push TX_WT_CREATE_STREAM. Reply event WT_STREAM_CREATED
        carries the assigned stream_id in stream_id field. initial and
        end_stream queue behind the stream header; priority (0-255, -1
        for none) applies first."""
        cdef spsc_entry_t entry
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_WT_CREATE_STREAM
        entry.cnx = <void*>self._wt
        entry.stream_ctx = <void*>self._wt
        entry.is_fin = ((AIOPQUIC_WT_CREATE_BIDIR if bidir else 0)
                        | (AIOPQUIC_WT_CREATE_FIN if end_stream else 0))
        entry.aux = stream_ring_cap
        if priority >= 0:
            entry.error_code = <uint64_t>priority + 1
        cdef const uint8_t* data_ptr = NULL
        cdef uint32_t data_len = 0
        if initial:
            data_ptr = <const uint8_t*>initial
            data_len = <uint32_t>len(initial)
        cdef int ret = spsc_ring_push(
            self._transport._ctx.tx_event_ring, &entry, data_ptr, data_len)
        if ret == -2:
            raise MemoryError("WT_CREATE_STREAM data alloc failed")
        if ret != 0:
            raise BufferError("TX ring full (WT_CREATE_STREAM)")
        self._transport._ctx.cnt_tx_event_ring_pushes += 1
        self._transport.wake_up()

    def push_close(self, uint32_t error_code, bytes reason=b""):
        cdef spsc_entry_t entry
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_WT_CLOSE
        entry.cnx = <void*>self._wt
        entry.stream_ctx = <void*>self._wt
        entry.error_code = error_code
        cdef const uint8_t* data_ptr = NULL
        cdef uint32_t data_len = 0
        if reason:
            data_ptr = <const uint8_t*>reason
            data_len = <uint32_t>len(reason)
        cdef int ret = spsc_ring_push(
            self._transport._ctx.tx_event_ring, &entry, data_ptr, data_len)
        if ret != 0:
            raise BufferError("TX ring full (WT_CLOSE)")
        self._transport._ctx.cnt_tx_event_ring_pushes += 1
        self._transport.wake_up()

    def push_drain(self):
        cdef spsc_entry_t entry
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_WT_DRAIN
        entry.cnx = <void*>self._wt
        entry.stream_ctx = <void*>self._wt
        cdef int ret = spsc_ring_push(
            self._transport._ctx.tx_event_ring, &entry, NULL, 0)
        if ret != 0:
            raise BufferError("TX ring full (WT_DRAIN)")
        self._transport._ctx.cnt_tx_event_ring_pushes += 1
        self._transport.wake_up()

    def push_fin(self):
        """FIN our side of the CONNECT stream, answering a peer close."""
        cdef spsc_entry_t entry
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_WT_FIN
        entry.cnx = <void*>self._wt
        entry.stream_ctx = <void*>self._wt
        cdef int ret = spsc_ring_push(
            self._transport._ctx.tx_event_ring, &entry, NULL, 0)
        if ret != 0:
            raise BufferError("TX ring full (WT_FIN)")
        self._transport._ctx.cnt_tx_event_ring_pushes += 1
        self._transport.wake_up()

    def push_stream_data(self, uint64_t stream_id, uintptr_t sc_ptr,
                          bytes data,
                          bint end_stream=False,
                          uint32_t stream_ring_cap=AIOPQUIC_TX_DATA_RING_CAP_DEFAULT):
        """Send bytes on a WT data stream — pull model.

        sc_ptr is the per-stream aiopquic_stream_ctx_t pointer the
        caller stashed from a STREAM_CREATED (we initiated) or
        NEW_STREAM (peer initiated) event. The worker owns the link
        + sc lifetime via h3zero's stream_ctx; Python only borrows
        the pointer for writes and must drop its reference on
        FIN/RESET/STOP_SENDING.

        Atomic from the asyncio thread's perspective:
          1. PRE-CHECK the SPSC TX-event ring has room for the
             MARK_ACTIVE event we'll need to push.
          2. Atomically commit bytes into sc->tx (lazy-allocates the
             ring at stream_ring_cap on first push). All-or-nothing —
             on ring-full no bytes are committed; tx_drain_pending is
             armed so the picoquic worker emits one
             SPSC_EVT_STREAM_TX_DRAINED when it next drains.
          3. Push TX_MARK_ACTIVE (guaranteed room from step 1 under
             the single-producer asyncio model). Worker pops it,
             calls picoquic_mark_active_stream(cnx, sid, 1, NULL) —
             passing NULL so picoquic's app_stream_ctx doesn't clobber
             h3zero's stream lookup. picoquic then asks h3zero for
             bytes via prepare_to_send; h3zero invokes our
             aiopquic_wt_path_callback(provide_data) which drains
             sc->tx and emits the drain event via the same edge-
             triggered pattern raw-QUIC uses.

        Raises:
          BufferError: TX-event ring or sc->tx is full. Bytes from
              the failed call were NOT committed; caller can retry
              the SAME data buffer without risk of duplicating bytes.
          ConnectionError: the WT session is closed.
          RuntimeError: WT session not yet open, or sc_ptr is 0.
          ValueError: data is larger than the stream's ring.
          MemoryError: sc->tx ring allocation failed.
        """
        cdef picoquic_cnx_t* cnx = NULL
        if self._wt is not NULL:
            cnx = <picoquic_cnx_t*>self._wt.cnx
        if cnx is NULL:
            if self._wt is not NULL and self._wt.session_closing:
                raise ConnectionError("WT session closed")
            raise RuntimeError("WT session not yet open")

        cdef aiopquic_stream_ctx_t* sc = <aiopquic_stream_ctx_t*>sc_ptr
        if sc is NULL:
            raise RuntimeError(
                f"WT stream {stream_id} has no sc (closed or never created)"
            )

        cdef const uint8_t* data_ptr = NULL
        cdef uint32_t data_len = 0
        if data:
            data_ptr = <const uint8_t*>data
            data_len = <uint32_t>len(data)

        # PRE-CHECK 1: TX event ring must have room for the
        # MARK_ACTIVE event we'll push after committing bytes.
        # Without this, retry semantics could duplicate bytes.
        # Single-producer (asyncio thread) ⇒ no TOCTOU window.
        if (spsc_ring_count(self._transport._ctx.tx_event_ring) >=
                self._transport._ctx.tx_event_ring.capacity
                and aiopquic_arm_tx_event_ring_drain_pending(
                    self._transport._ctx)):
            # Armed before raising, so the caller can await
            # tx_event_ring_drain_event without losing the wakeup. An arm
            # that finds the ring already drained falls through.
            raise BufferError(
                f"TX event ring full (WT stream={stream_id})"
            )

        # COMMIT: push bytes to per-stream sc->tx (lazy-allocates
        # ring at stream_ring_cap if absent; atomic / all-or-nothing).
        cdef int rc = aiopquic_stream_ctx_send_data(
            sc, data_ptr, data_len, stream_ring_cap,
            <uint8_t>(1 if end_stream else 0))
        if rc == 0:
            # sc->tx full; tx_drain_pending armed inside helper.
            raise BufferError(
                f"WT TX ring full (stream={stream_id}, "
                f"need={data_len})"
            )
        if rc == -2:
            raise ValueError(
                f"write of {data_len} bytes exceeds the stream ring "
                f"(stream={stream_id}, cap={stream_ring_cap})")
        if rc < 0:
            raise MemoryError(
                f"WT sc->tx alloc failed (stream={stream_id})"
            )
        if data_len > 0:
            aiopquic_tx_data_bytes_pushed_add(<uint64_t>data_len)

        if not aiopquic_stream_ctx_tx_arm(sc):
            self._transport._ctx.cnt_tx_mark_active_skipped += 1
            return

        # MARK_ACTIVE: stream_ctx=NULL preserves h3zero's lookup-by-
        # sid behavior. h3zero handles NULL app_stream_ctx safely on
        # both prepare_to_send (h3zero_common.c:1640) and stream_data
        # (h3zero_common.c:1492) paths.
        cdef spsc_entry_t entry
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_MARK_ACTIVE
        entry.stream_id = stream_id
        entry.cnx = <void*>cnx
        entry.stream_ctx = NULL
        cdef int ret = spsc_ring_push(
            self._transport._ctx.tx_event_ring, &entry, NULL, 0)
        if ret != 0:
            aiopquic_stream_ctx_tx_disarm(sc)
            # Single-producer invariant violated. Arm the connection-
            # global drain signal so the caller's BufferError handler
            # waking on tx_event_ring_drain_event will fire when the ring
            # drains. Bytes are already in sc->tx; caller's retry must
            # check rc semantics so as not to duplicate. send_data is
            # all-or-nothing per call so the SAME buffer can be retried
            # without doubling, but pre-check + caller-retry should
            # converge to MARK_ACTIVE landing.
            aiopquic_arm_tx_event_ring_drain_pending(self._transport._ctx)
            raise BufferError(
                f"TX event ring full (WT MARK_ACTIVE stream={stream_id})"
            )
        self._transport._ctx.cnt_tx_event_ring_pushes += 1
        self._transport.wake_up()

    def push_reset_stream(self, uint64_t stream_id, uint64_t error_code,
                          uint32_t reliable_size=0):
        cdef spsc_entry_t entry
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_WT_RESET_STREAM
        entry.cnx = <void*>self._wt
        entry.stream_ctx = <void*>self._wt
        entry.stream_id = stream_id
        entry.error_code = error_code
        entry.aux = reliable_size
        cdef int ret = spsc_ring_push(
            self._transport._ctx.tx_event_ring, &entry, NULL, 0)
        if ret != 0:
            raise BufferError("TX ring full (WT_RESET_STREAM)")
        self._transport._ctx.cnt_tx_event_ring_pushes += 1
        self._transport.wake_up()

    def push_session_cleanup(self):
        """Terminate this session's streams in one worker-thread
        splay-tree walk: §6 RESET_STREAM / STOP_SENDING (WT_SESSION_GONE)
        in each stream's own direction, then release the per-stream
        wt_link sc's. One SPSC slot regardless of stream count; the link
        release does not wait on the wire, so it completes on a stalled
        cnx.

        Idempotent: a later walk skips streams already released.
        Does NOT tear down the session itself — __dealloc__ still
        pushes TX_WT_DEREGISTER for the full close + free."""
        cdef spsc_entry_t entry
        if self._wt is NULL:
            return
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_WT_SESSION_CLEANUP
        entry.cnx = <void*>self._wt
        entry.stream_ctx = <void*>self._wt
        cdef int ret = spsc_ring_push(
            self._transport._ctx.tx_event_ring, &entry, NULL, 0)
        if ret != 0:
            raise BufferError("TX ring full (WT_SESSION_CLEANUP)")
        self._transport._ctx.cnt_tx_event_ring_pushes += 1
        self._transport.wake_up()

    def push_dgram_ready(self, uintptr_t db_ptr):
        """Hand this session's datagram record ring to the worker and arm
        h3zero's scheduler for the session's control stream. Returns 0
        posted, 1 TX event ring full (records stay queued; retry)."""
        cdef spsc_entry_t entry
        if self._wt is NULL:
            raise ConnectionError("WT session closed")
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_MARK_WT_DATAGRAM_READY
        entry.cnx = <void*>self._wt
        entry.stream_ctx = <void*>self._wt
        entry.error_code = <uint64_t>db_ptr
        while spsc_ring_push(
                self._transport._ctx.tx_event_ring, &entry, NULL, 0) != 0:
            if aiopquic_arm_tx_event_ring_drain_pending(self._transport._ctx):
                return 1
        self._transport._ctx.cnt_tx_event_ring_pushes += 1
        self._transport.wake_up()
        return 0

    def push_stream_priority(self, uint64_t stream_id, uint8_t priority):
        """Relative send priority for one WT stream (RFC 9000 §2.3)."""
        cdef spsc_entry_t entry
        if self._wt is NULL:
            raise ConnectionError("WT session closed")
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_WT_SET_STREAM_PRIORITY
        entry.cnx = <void*>self._wt
        entry.stream_ctx = <void*>self._wt
        entry.stream_id = stream_id
        entry.error_code = priority
        while spsc_ring_push(
                self._transport._ctx.tx_event_ring, &entry, NULL, 0) != 0:
            # Armed before reporting full: a caller that awaits
            # tx_event_ring_drain_event on a 1 never wakes otherwise.
            if aiopquic_arm_tx_event_ring_drain_pending(self._transport._ctx):
                return 1
        self._transport._ctx.cnt_tx_event_ring_pushes += 1
        self._transport.wake_up()
        return 0

    def push_datagram_priority(self, uint8_t priority):
        """Datagram priority for this session's connection, on the stream
        scale. Returns 0 posted, 1 TX event ring full (retry)."""
        cdef spsc_entry_t entry
        if self._wt is NULL:
            raise ConnectionError("WT session closed")
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_WT_SET_DATAGRAM_PRIORITY
        entry.cnx = <void*>self._wt
        entry.stream_ctx = <void*>self._wt
        entry.error_code = priority
        while spsc_ring_push(
                self._transport._ctx.tx_event_ring, &entry, NULL, 0) != 0:
            if aiopquic_arm_tx_event_ring_drain_pending(self._transport._ctx):
                return 1
        self._transport._ctx.cnt_tx_event_ring_pushes += 1
        self._transport.wake_up()
        return 0

    def push_stop_sending(self, uint64_t stream_id, uint64_t error_code):
        cdef spsc_entry_t entry
        memset(&entry, 0, sizeof(entry))
        entry.event_type = SPSC_EVT_TX_WT_STOP_SENDING
        entry.cnx = <void*>self._wt
        entry.stream_ctx = <void*>self._wt
        entry.stream_id = stream_id
        entry.error_code = error_code
        cdef int ret = spsc_ring_push(
            self._transport._ctx.tx_event_ring, &entry, NULL, 0)
        if ret != 0:
            raise BufferError("TX ring full (WT_STOP_SENDING)")
        self._transport._ctx.cnt_tx_event_ring_pushes += 1
        self._transport.wake_up()


# ---------------------------------------------------------------------------
# Per-stream send buffer (PULL-model send path).
#
# Real backpressure: producer push returns # bytes accepted; 0 means full.
# picoquic pulls from the ring at wire rate via the prepare_to_send callback
# in aiopquic_stream_cb (when stream_ctx == buffer pointer).
#
# Lifecycle:
#   sb = stream_buf_create(capacity)         # capacity must be power of 2
#   transport.push_tx_event(SPSC_EVT_TX_MARK_ACTIVE,
#                     stream_id, cnx_ptr=cnx, stream_ctx=sb)
#   transport.wake_up()
#   stream_buf_push(sb, data)                # producer; returns bytes accepted
#   ...
#   stream_buf_set_fin(sb)                   # mark FIN follows on drain
#   transport.push_tx_event(SPSC_EVT_TX_MARK_ACTIVE,
#                     stream_id, cnx_ptr=cnx, stream_ctx=sb)  # ensure active
#   transport.wake_up()
#   ... wait for ring to drain ...
#   stream_buf_destroy(sb)
# ---------------------------------------------------------------------------

cdef extern from "c/test_access.h":
    int aiopquic_test_cnx_datagram_priority(picoquic_cnx_t* cnx)
    int aiopquic_test_default_datagram_priority(picoquic_quic_t* quic)
    const char* aiopquic_test_cnx_cc_options(picoquic_cnx_t* cnx)
    int aiopquic_test_cnx_packet_train_mode(picoquic_cnx_t* cnx)
    void aiopquic_test_take_perflog(picoquic_quic_t* quic)
    int aiopquic_test_hold_tx_wake(aiopquic_ctx_t* ctx)


def _datagram_priority(uintptr_t cnx_ptr):
    """picoquic's datagram priority for a connection, -1 for none (test only)."""
    return aiopquic_test_cnx_datagram_priority(<picoquic_cnx_t*>cnx_ptr)


def _take_perflog(TransportContext t):
    """Set the quic's perflog slot as picoquic_perflog_setup would (test only)."""
    aiopquic_test_take_perflog(t._quic)


def _hold_tx_wake(TransportContext t):
    """Take an idle worker's wake so TX pushes stay queued; True if the
    worker was idle (test only)."""
    return aiopquic_test_hold_tx_wake(t._ctx) != 0


def _live_cnx_attach(TransportContext t):
    """Re-run the delete-hook attach; only safe with no cnx (test only)."""
    aiopquic_live_cnx_attach(t._ctx, t._quic)


def _default_datagram_priority(TransportContext t):
    """The context's default datagram priority, -1 before start (test only)."""
    return aiopquic_test_default_datagram_priority(t._quic)


def _wt_datagram_priority(WebTransportSessionState st):
    """Datagram priority of a WT session's connection, -1 for none (test only)."""
    if st._wt is NULL:
        return -1
    return aiopquic_test_cnx_datagram_priority(st._wt.cnx)


cdef _cnx_cc_options(picoquic_cnx_t* cnx):
    cdef const char* s = aiopquic_test_cnx_cc_options(cnx)
    return None if s is NULL else s.decode()


def _cc_options(uintptr_t cnx_ptr):
    """picoquic's congestion-control option string for a connection, or None
    (test only)."""
    return _cnx_cc_options(<picoquic_cnx_t*>cnx_ptr)


def _wt_cc_options(WebTransportSessionState st):
    """The option string of a WT session's connection, or None (test only)."""
    if st._wt is NULL:
        return None
    return _cnx_cc_options(st._wt.cnx)


def _packet_train_mode(uintptr_t cnx_ptr):
    """1 if a connection's context paces in packet trains, else 0 (test only)."""
    return aiopquic_test_cnx_packet_train_mode(<picoquic_cnx_t*>cnx_ptr)


def _wt_packet_train_mode(WebTransportSessionState st):
    """Packet train mode of a WT session's context, -1 for none (test only)."""
    if st._wt is NULL:
        return -1
    return aiopquic_test_cnx_packet_train_mode(st._wt.cnx)


cdef extern from "c/litmus.h":
    int64_t aiopquic_litmus_run(int kind, uint64_t rounds) nogil

_LITMUS_KINDS = {
    'rx_notify': 0, 'tx_wake': 1, 'rx_event': 2,
    'tx_drain': 3, 'tx_ring': 4, 'dgram': 5, 'rx_drained': 6,
}


def _litmus(str kind, uint64_t n):
    """Race one wake protocol's two sides on two threads for n rounds.
    Returns the number of lost wakes (test only)."""
    cdef int k = _LITMUS_KINDS[kind]
    cdef int64_t lost
    with nogil:
        lost = aiopquic_litmus_run(k, n)
    if lost < 0:
        raise MemoryError("litmus setup failed")
    return lost


def _tx_wake_gate(uint32_t idle, uint64_t n):
    """Run n producer wake gates against a worker held idle (1) or running
    (0), with no worker thread. Returns (wakes, skipped) (test only)."""
    cdef aiopquic_ctx_t* ctx = aiopquic_ctx_create(16, 64, 50)
    cdef uint64_t i
    if ctx is NULL:
        raise MemoryError("ctx create failed")
    ctx.tx_worker_idle = idle
    for i in range(n):
        aiopquic_tx_wake_needed(ctx)
    r = (ctx.cnt_wake_calls, ctx.cnt_wake_skipped_coalesced)
    aiopquic_ctx_destroy(ctx)
    return r


def stream_buf_create(uint32_t capacity):
    """Allocate a per-stream send buffer of `capacity` bytes (power of 2).

    Returns an integer pointer (uintptr_t) that should be passed as
    stream_ctx to push_tx_event(SPSC_EVT_TX_MARK_ACTIVE, ...) and freed via
    stream_buf_destroy() when the stream is done.
    """
    cdef aiopquic_stream_buf_t* sb = aiopquic_stream_buf_create(capacity)
    if sb is NULL:
        raise ValueError(
            f"stream_buf_create({capacity}): bad capacity "
            "(must be power of 2 and non-zero) or out of memory")
    return <uintptr_t>sb


def stream_buf_destroy(uintptr_t sb_ptr):
    """Free a stream buffer. Caller must ensure picoquic has stopped
    referencing it (stream closed / reset / connection ended)."""
    if sb_ptr == 0:
        return
    aiopquic_stream_buf_destroy(<aiopquic_stream_buf_t*>sb_ptr)


def stream_buf_push(uintptr_t sb_ptr, bytes data):
    """Append bytes to the stream's send ring. Returns # bytes accepted.

    A return < len(data) indicates partial acceptance — the ring is at
    capacity. Caller should retry the unaccepted tail later (after the
    consumer has drained more).
    """
    if sb_ptr == 0 or not data:
        return 0
    cdef const uint8_t* p = <const uint8_t*>data
    return aiopquic_stream_buf_push(
        <aiopquic_stream_buf_t*>sb_ptr, p, <uint32_t>len(data))


def stream_buf_used(uintptr_t sb_ptr):
    """Bytes currently buffered (waiting for picoquic to pull)."""
    if sb_ptr == 0:
        return 0
    return aiopquic_stream_buf_used(<aiopquic_stream_buf_t*>sb_ptr)


def stream_buf_free(uintptr_t sb_ptr):
    """Bytes of capacity currently free (max producer can push next)."""
    if sb_ptr == 0:
        return 0
    return aiopquic_stream_buf_free(<aiopquic_stream_buf_t*>sb_ptr)


def stream_buf_set_fin(uintptr_t sb_ptr):
    """Mark FIN to be sent once the ring has been fully drained by picoquic."""
    if sb_ptr == 0:
        return
    aiopquic_stream_buf_set_fin(<aiopquic_stream_buf_t*>sb_ptr)


def stream_buf_stats(uintptr_t sb_ptr):
    """Return (pushed, popped, push_hash, pop_hash) for byte-conservation
    diagnostics. push_hash and pop_hash are FNV-1a accumulators that are
    updated when AIOPQUIC_TX_HASH=1 was set at stream_buf_create() time.
    Returns (0, 0, 0, 0) for a NULL pointer.
    """
    if sb_ptr == 0:
        return (0, 0, 0, 0)
    cdef aiopquic_stream_buf_t* sb = <aiopquic_stream_buf_t*>sb_ptr
    return (
        aiopquic_stream_buf_pushed(sb),
        aiopquic_stream_buf_popped(sb),
        aiopquic_stream_buf_push_hash(sb),
        aiopquic_stream_buf_pop_hash(sb),
    )


def stream_buf_pop_to_bytes(uintptr_t sb_ptr, uint32_t max_bytes):
    """Pop up to max_bytes from the per-stream byte ring as a fresh
    `bytes` object. Returns b'' when the ring is empty or sb_ptr is NULL.

    Used on the RX path: picoquic worker thread pushed bytes into this
    ring synchronously inside the stream_data callback; this drains
    them on the asyncio thread for delivery as StreamDataReceived.
    """
    if sb_ptr == 0 or max_bytes == 0:
        return b''
    cdef aiopquic_stream_buf_t* sb = <aiopquic_stream_buf_t*>sb_ptr
    cdef uint32_t avail = aiopquic_stream_buf_used(sb)
    if avail == 0:
        return b''
    cdef uint32_t to_read = max_bytes if max_bytes < avail else avail
    cdef bytes out = PyBytes_FromStringAndSize(NULL, to_read)
    cdef char* buf = PyBytes_AsString(out)
    cdef uint32_t actual = aiopquic_stream_buf_pop(
        sb, <uint8_t*>buf, to_read)
    if actual != to_read:
        # Shouldn't happen — head only advances on the consumer thread.
        return out[:actual]
    return out


# ---------------------------------------------------------------------------
# stream_ctx_t — per-stream wrapper. Allocated on first contact (TX or RX),
# bound to picoquic's app_stream_ctx slot so both prepare_to_send and
# stream_data callbacks find the same struct. Holds the per-direction
# byte rings + RX flow-control state.
# ---------------------------------------------------------------------------
def stream_ctx_create():
    """Allocate a fresh wrapper. Returns its address as uintptr_t.
    Both rings start NULL — call stream_ctx_ensure_tx / _ensure_rx to
    populate. Caller must eventually stream_ctx_destroy() to free."""
    cdef aiopquic_stream_ctx_t* sc = aiopquic_stream_ctx_create()
    if not sc:
        raise MemoryError("aiopquic_stream_ctx_create returned NULL")
    aiopquic_cnt_sc_create_python_helper_inc()
    return <uintptr_t>sc


def stream_ctx_destroy(uintptr_t sc_ptr):
    """Free the wrapper + both rings. Call only after the picoquic worker
    has stopped using this stream_ctx (i.e., after stream_reset/_fin and
    the next picoquic_packet_loop_wake-up cycle has completed). For now
    callers defer destroy until process exit to avoid use-after-free with
    the picoquic worker thread."""
    if sc_ptr == 0:
        return
    aiopquic_cnt_sc_destroy_python_helper_inc()
    aiopquic_stream_ctx_destroy(<aiopquic_stream_ctx_t*>sc_ptr)


def stream_ctx_ensure_tx(uintptr_t sc_ptr, uint32_t capacity):
    """Lazily allocate the TX ring on the wrapper. Idempotent — repeated
    calls with the ring already present are a no-op. Capacity must be
    a power of two. Returns 0 on success, raises on alloc failure."""
    if sc_ptr == 0:
        raise ValueError("stream_ctx_ensure_tx called with NULL pointer")
    cdef int ret = aiopquic_stream_ctx_ensure_tx(
        <aiopquic_stream_ctx_t*>sc_ptr, capacity)
    if ret != 0:
        raise MemoryError(f"aiopquic_stream_ctx_ensure_tx failed (ret={ret})")
    return 0


def stream_ctx_ensure_rx(uintptr_t sc_ptr, uint32_t capacity):
    """Lazily allocate the RX ring on the wrapper. Idempotent."""
    if sc_ptr == 0:
        raise ValueError("stream_ctx_ensure_rx called with NULL pointer")
    cdef int ret = aiopquic_stream_ctx_ensure_rx(
        <aiopquic_stream_ctx_t*>sc_ptr, capacity)
    if ret != 0:
        raise MemoryError(f"aiopquic_stream_ctx_ensure_rx failed (ret={ret})")
    return 0


def stream_ctx_get_tx(uintptr_t sc_ptr):
    """Return the TX ring pointer (or 0 if not yet ensured)."""
    if sc_ptr == 0:
        return 0
    cdef aiopquic_stream_ctx_t* sc = <aiopquic_stream_ctx_t*>sc_ptr
    return <uintptr_t>sc.tx


def stream_ctx_get_rx(uintptr_t sc_ptr):
    """Return the RX ring pointer (or 0 if not yet ensured)."""
    if sc_ptr == 0:
        return 0
    cdef aiopquic_stream_ctx_t* sc = <aiopquic_stream_ctx_t*>sc_ptr
    return <uintptr_t>sc.rx


def stream_ctx_rx_consumed(uintptr_t sc_ptr):
    """Cumulative RX bytes drained from the per-stream ring (atomic
    load). Useful for diagnostics; flow-control advancement is now a
    side-effect of the picoquic worker thread reading this counter
    inside its stream_data callback — no Python-side dispatch."""
    if sc_ptr == 0:
        return 0
    return aiopquic_stream_ctx_rx_consumed_load(
        <aiopquic_stream_ctx_t*>sc_ptr)


def stream_ctx_send_data(uintptr_t sc_ptr, bytes data,
                          uint32_t capacity, bint fin):
    """Combined send-data fast path — collapses ensure_tx + free-check
    + push + (optional) set_fin into one Cython call.

    Returns:
       1  pushed all bytes (and set FIN if requested)
       0  ring full — caller waits + retries the SAME data buffer
          (push is all-or-nothing; no partial commit happens).
      -1  allocation failure (caller raises MemoryError).

    Pull model unchanged: bytes go into the SPSC TX ring; picoquic
    pulls at wire rate via prepare_to_send. The MARK_ACTIVE event +
    wake_up still fire from QuicConnection.send_stream_data after a
    successful return.
    """
    if sc_ptr == 0:
        raise ValueError("stream_ctx_send_data called with NULL sc")
    cdef const uint8_t* p = <const uint8_t*>data if data else NULL
    cdef uint32_t length = <uint32_t>len(data) if data else 0
    return aiopquic_stream_ctx_send_data(
        <aiopquic_stream_ctx_t*>sc_ptr,
        p, length, capacity, <uint8_t>(1 if fin else 0),
    )


# Note: set_max_stream_data and enable_app_flow_control are issued from
# the connection.py drain path via push_tx_event(SPSC_EVT_TX_OPEN_FLOW_CONTROL,
# error_code=new_max) and push_tx_event(SPSC_EVT_TX_SET_APP_FLOW_CONTROL,
# is_fin=1). No direct Python wrappers needed — the existing push_tx_event
# API already delivers events to the picoquic worker thread.

