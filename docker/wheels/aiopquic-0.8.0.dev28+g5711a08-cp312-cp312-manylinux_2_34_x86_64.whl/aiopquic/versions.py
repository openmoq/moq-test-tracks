"""Version + build-info reporter for aiopquic.

Usage:
    python -m aiopquic.versions
    aiopquic-versions                    # console-script entry point

Prints aiopquic's installed version plus the picoquic / picotls
submodule revisions captured at build time. Reads `_build_info.py`
written by setup.py during wheel/editable install.

Each line reads `name:  REV (LOC) [DATE]`: parens hold a locator (the
install path for a package, the short SHA for picoquic), brackets the
date. For aiopquic, REV is the installed version and DATE its build
date+time. Submodules (vendored inside aiopquic) are indented under it
as `  - name:`; REV is the most specific identifier available — library
version (picoquic), else upstream branch, else `git describe` / short
SHA — and DATE its pinned-commit date.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from importlib import metadata as _md
from pathlib import Path

from aiopquic import __version__

_HASH_LEN = 8
_LABEL_W = 11


def _abbrev(path: str) -> str:
    """Replace a leading $HOME with ~ for a shorter display path."""
    home = os.path.expanduser("~")
    if path == home:
        return "~"
    if path.startswith(home + os.sep):
        return "~" + path[len(home):]
    return path


def _dist(name: str):
    """Return the importlib.metadata Distribution for `name`, preferring
    a site-packages `*.dist-info` over a source-tree `*.egg-info` when
    both are discoverable. importlib.metadata.distribution() returns
    the first match in sys.path order, which loses to stale egg-info
    left behind by older editable installs; explicit enumeration with
    a dist-info bias defends against that shadowing."""
    candidates = [
        d for d in _md.distributions()
        if (d.metadata["Name"] or "").lower() == name.lower()
    ]
    if not candidates:
        return None

    def _key(d):
        loc = getattr(d, "_path", None)
        is_dist_info = loc is not None and str(loc).endswith(".dist-info")
        ver = d.version or ""
        mtime = 0.0
        if loc is not None:
            p = Path(str(loc))
            for fname in ("RECORD", "METADATA"):
                try:
                    mtime = max(mtime, (p / fname).stat().st_mtime)
                except OSError:
                    continue
        return (is_dist_info, ver, mtime)

    candidates.sort(key=_key, reverse=True)
    return candidates[0]


def _is_editable(dist) -> bool:
    """True iff `dist` is a PEP 660 editable install. Reads
    `direct_url.json` written at install time. Falls back to False
    (treat as wheel) when the file or expected fields are absent —
    legacy installs without direct_url.json are treated as wheels."""
    try:
        raw = dist.read_text("direct_url.json")
    except (OSError, AttributeError):
        return False
    if not raw:
        return False
    try:
        data = json.loads(raw)
    except (ValueError, TypeError):
        return False
    return bool(data.get("dir_info", {}).get("editable", False))


def _dist_install_date(dist) -> str | None:
    """Install timestamp from a Distribution: mtime of RECORD (written
    last by pip), else METADATA. Returns 'YYYY-MM-DD HH:MM' or None
    when neither is readable."""
    loc = getattr(dist, "_path", None)
    if loc is None:
        return None
    p = Path(str(loc))
    for fname in ("RECORD", "METADATA"):
        try:
            return time.strftime(
                "%Y-%m-%d %H:%M",
                time.localtime((p / fname).stat().st_mtime),
            )
        except OSError:
            continue
    return None


def _source_newest_mtime(root: str) -> str | None:
    """Newest non-pyc file mtime under `root`. Reflects source-edit
    time for pure-Python editable installs and Cython rebuild time
    for native editable installs."""
    newest = 0.0
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for f in files:
            if f.endswith(".pyc"):
                continue
            try:
                newest = max(newest, os.path.getmtime(os.path.join(dirpath, f)))
            except OSError:
                continue
    if not newest:
        return None
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(newest))


def _build_date(module, name: str | None = None) -> str | None:
    """Best-effort install/build timestamp for a package.

    Wheel installs: dist-info RECORD mtime (the moment pip wrote the
    install) — answers 'when was this version installed' for bug
    reports. Editable installs: newest non-pyc mtime under the package
    dir — answers 'is the running code stale' for active development.
    `name` defaults to the top-level package of `module`."""
    if name is None:
        name = module.__name__.split(".")[0]
    dist = _dist(name)
    if dist is not None and not _is_editable(dist):
        stamped = _dist_install_date(dist)
        if stamped is not None:
            return stamped
    root = os.path.dirname(os.path.abspath(module.__file__))
    return _source_newest_mtime(root)


def _version(v: str) -> str:
    """Installed version with setuptools_scm's `.dYYYYMMDD` dirty-date
    stripped — that day-stamp is redundant with the bracketed build time."""
    return re.sub(r"\.d\d{8}", "", v)


def _meta(module, name: str | None = None) -> str:
    """Suffix after the version: ' (PATH) [BUILD]'. PATH is the
    abbreviated install dir (module.__file__'s parent — the actually-
    imported code, which for editable installs is the source tree and
    for wheels is site-packages/<pkg>). BUILD is the dist-info RECORD
    mtime for wheel installs, newest source mtime for editable installs.
    Either group is dropped when its value is unavailable."""
    out = ""
    src = _abbrev(os.path.dirname(module.__file__))
    if src:
        out += f" ({src})"
    built = _build_date(module, name)
    if built:
        out += f" [{built}]"
    return out


def _git(root: str, *args: str) -> str | None:
    """One `git -C root` invocation, or None on any failure."""
    try:
        out = subprocess.run(("git", "-C", root, *args),
                             capture_output=True, text=True, timeout=2.0,
                             env={k: v for k, v in os.environ.items()
                                  if not k.startswith("GIT_")})
    except (OSError, subprocess.SubprocessError):
        return None
    if out.returncode != 0:
        return None
    return out.stdout.strip() or None


def _own_source_tree(root: str, pkg: str) -> bool:
    """True iff `root` sits in a git tree that is `pkg`'s own source.

    Guards against reporting an unrelated enclosing repo: a wheel
    installed into a venv inside someone else's git project would
    otherwise have that project's revision attributed to it. Matching
    pyproject's `name` works for flat and src layouts alike."""
    top = _git(root, "rev-parse", "--show-toplevel")
    if top is None:
        return False
    try:
        text = (Path(top) / "pyproject.toml").read_text(encoding="utf-8")
    except OSError:
        return False
    return re.search(rf'(?m)^\s*name\s*=\s*["\']{re.escape(pkg)}["\']',
                     text) is not None


def _ext_stale(root: str) -> bool:
    """True when a hand-written native source under `root` is newer than
    the newest built extension.

    The binding is compiled, so a checked-out source is not necessarily
    the code being executed — editing a header without rebuilding leaves
    the old `.so` loaded, which silently invalidates any measurement
    taken against it. Generated `.c` is excluded: it is regenerated on
    build, so its mtime tracks the `.so` rather than an author's edit."""
    newest_so = newest_src = 0.0
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for f in files:
            try:
                mt = os.path.getmtime(os.path.join(dirpath, f))
            except OSError:
                continue
            if f.endswith(".so"):
                newest_so = max(newest_so, mt)
            elif f.endswith((".h", ".pyx", ".pxd")):
                newest_src = max(newest_src, mt)
    return bool(newest_so and newest_src and newest_src > newest_so)


def _git_state(root: str, ver: str, pkg: str) -> str | None:
    """Working-tree identity for a from-source install: ' git:REV BRANCH'.

    A from-source install imports from the tree, but its dist metadata
    version is written once at install time — it cannot track a branch
    switch or an uncommitted edit, so it is the wrong answer to "what am
    I running". `--dirty` is what surfaces uncommitted changes, and the
    version is marked stale when it names a commit that is not HEAD.
    Returns None for a wheel install, outside a repo, or without git."""
    if not _own_source_tree(root, pkg):
        return None
    desc = _git(root, "describe", "--tags", "--dirty", "--always")
    if desc is None:
        return None
    out = f" git:{desc}"
    branch = _git(root, "rev-parse", "--abbrev-ref", "HEAD")
    if branch and branch != "HEAD":
        out += f" {branch}"
    m = re.search(r"\+g([0-9a-f]{7,})", ver)
    head = _git(root, "rev-parse", "HEAD")
    if m and head and not head.startswith(m.group(1)):
        out += " (metadata version STALE)"
    if _ext_stale(root):
        out += " (EXTENSION STALE — rebuild)"
    return out


def _compact_describe(describe: str) -> str | None:
    """'v1.1.30-12-g2b1e14d5' -> '1.1.30-12-2b1e14d5'. Returns None when
    describe carries no reachable tag (a bare --always short SHA), so the
    caller falls back to a uniform short SHA."""
    s = describe[1:] if describe.startswith("v") else describe
    m = re.match(r"(.+)-(\d+)-g([0-9a-f]+)$", s)
    if not m:
        return None
    base, dist, sha = m.groups()
    return f"{base}-{dist}-{sha[:_HASH_LEN]}"


def _submodule_info(prefix: str) -> dict[str, str]:
    """Return a {sha, describe, date, subject} dict for the named
    submodule prefix ("PICOQUIC" or "PICOTLS"). Every field defaults
    to "unknown" so older _build_info.py files (sha-only) still work."""
    try:
        from aiopquic import _build_info as _bi
    except ImportError:
        return {"sha": "unknown", "describe": "unknown", "date": "unknown",
                "subject": "unknown", "version": "unknown",
                "branch": "unknown"}
    return {
        "sha":      getattr(_bi, f"{prefix}_SHA",      "unknown"),
        "describe": getattr(_bi, f"{prefix}_DESCRIBE", "unknown"),
        "date":     getattr(_bi, f"{prefix}_DATE",     "unknown"),
        "subject":  getattr(_bi, f"{prefix}_SUBJECT",  "unknown"),
        "version":  getattr(_bi, f"{prefix}_VERSION",  "unknown"),
        "branch":   getattr(_bi, f"{prefix}_BRANCH",   "unknown"),
    }


def _format_submodule(name: str, info: dict[str, str]) -> str:
    label = f"  - {name + ':':<{_LABEL_W}}"
    describe = info["describe"]
    rev = _compact_describe(describe) if describe != "unknown" else None
    if rev is None:
        sha = info["sha"]
        rev = sha[:_HASH_LEN] if sha != "unknown" else "unknown"
    version = info["version"]
    branch = info["branch"]
    if version != "unknown":
        rev = f"{version} ({rev})"
    elif branch != "unknown":
        rev = f"{branch} ({rev})"
    date = info["date"]
    if date != "unknown":
        return f"{label}{rev} [{date[:10]}]"
    return f"{label}{rev}"


def _openssl_info() -> tuple[str, str | None] | None:
    """Runtime OpenSSL the binding links: (version, resolved libcrypto
    path). Answers 'am I on the fast crypto?' — the actually-loaded
    libcrypto, which dominates throughput, not Python's `ssl` module
    (which can link a different OpenSSL than the extension). Best-effort;
    returns None when it can't be determined."""
    import ctypes
    try:
        from aiopquic._binding import _transport  # noqa: F401  (maps libcrypto)
    except Exception:
        pass
    path = None
    try:
        with open("/proc/self/maps") as fh:
            for line in fh:
                if "libcrypto" in line:
                    path = line.split()[-1]
                    break
    except OSError:
        pass
    try:
        lib = ctypes.CDLL(path) if path else ctypes.CDLL("libcrypto.so.3")
        lib.OpenSSL_version.restype = ctypes.c_char_p
        lib.OpenSSL_version.argtypes = [ctypes.c_int]
        ver = lib.OpenSSL_version(0).decode()  # OPENSSL_VERSION = 0
    except Exception:
        return None
    return (ver, path)


def _format_openssl(info: tuple[str, str | None]) -> str:
    """`  - openssl:  OpenSSL X.Y.Z (path)` — version trimmed of the
    trailing release date, path abbreviated with ~."""
    ver, path = info
    label = f"  - {'openssl:':<{_LABEL_W}}"
    short = " ".join(ver.split()[:2]) if ver else ver
    if path:
        return f"{label}{short} ({_abbrev(path)})"
    return f"{label}{short}"


def print_versions(file=sys.stdout) -> None:
    import aiopquic
    dist = _dist("aiopquic")
    ver = dist.version if dist is not None else __version__
    line = (f"{'aiopquic:':<{_LABEL_W}}{_version(ver)}"
            f"{_meta(aiopquic, 'aiopquic')}")
    if dist is None or _is_editable(dist):
        line += _git_state(os.path.dirname(os.path.abspath(aiopquic.__file__)),
                           ver, "aiopquic") or ""
    print(line, file=file)
    print(_format_submodule("picoquic", _submodule_info("PICOQUIC")), file=file)
    print(_format_submodule("picotls",  _submodule_info("PICOTLS")),  file=file)
    ossl = _openssl_info()
    if ossl is not None:
        print(_format_openssl(ossl), file=file)


def main() -> int:
    print_versions()
    return 0


if __name__ == "__main__":
    sys.exit(main())
