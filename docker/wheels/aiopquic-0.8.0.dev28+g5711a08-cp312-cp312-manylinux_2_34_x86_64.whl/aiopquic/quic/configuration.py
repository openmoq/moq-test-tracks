"""QUIC configuration — matches qh3.quic.configuration API."""

import socket
import ssl
from dataclasses import dataclass, field
from collections.abc import Sequence

QUIC_V1 = 0x00000001
QUIC_V2 = 0x6B3343CF
CIPHER_SUITES = (0x1301, 0x1302, 0x1303)


@dataclass
class QuicConfiguration:
    """Configuration for a QUIC connection.

    Defaults tuned for streaming-media workloads (MoQT, WT). Override
    individual fields where a different policy is needed.
    """
    alpn_protocols: list[str] | None = None
    # QUIC idle timeout in seconds: the connection closes if no packet
    # is exchanged for this long. 30 s matches picoquic's default and
    # leaves headroom for a flow-controlled receiver whose consumer
    # briefly stalls (a lower value drops such connections — enable
    # keep_alive_interval below for active liveness instead of relying
    # on a short idle timeout).
    idle_timeout: float = 30.0
    # QUIC keep-alive interval in seconds. None/0 = disabled (default).
    # When set, the peer sends PING frames at this interval to hold an
    # otherwise-quiet connection open past idle_timeout — important for
    # a flow-controlled receiver whose consumer stalls and
    # back-pressures the sender to silence (the connection would
    # otherwise idle-time-out and drop). Pick well under idle_timeout
    # (e.g. idle_timeout/3). App opts in; nothing is sent when None.
    keep_alive_interval: float | None = None
    # UDP socket SO_RCVBUF/SO_SNDBUF request in bytes. None = aiopquic's
    # 64 MiB default. The kernel clamps the effective value to
    # net.core.rmem_max / wmem_max (Linux also doubles internally), so
    # the real ceiling is the host sysctl. Lower this to cap per-socket
    # memory when running many sockets (e.g. high subscriber-process
    # fan-out, where N × clamped-buffer adds up).
    socket_buffer_size: int | None = None
    is_client: bool = True
    # Initial flow-control windows advertised to the peer at handshake.
    # The peer is bound by spec to never send more than max_stream_data
    # bytes unconsumed on a single stream (and max_data across all
    # streams) until we extend MAX_STREAM_DATA. The C-side per-stream
    # RX byte ring is sized to match this advertised cap at allocation
    # time, so the spec-permitted worst case (peer fills the entire
    # window before we drain a byte) is handled correctly. As the
    # consumer drains bytes the picoquic worker thread extends the
    # cap via picoquic_open_flow_control. Higher caps tolerate larger
    # peer bursts before backpressure kicks in; lower caps reduce
    # per-stream memory and bufferbloat. max_data stays a fixed window
    # past bytes received (picoquic_set_max_data_control), so it caps
    # inbound at ~max_data per RTT and out-of-order memory at ~6x.
    max_data: int = 16 * 1024 * 1024
    max_stream_data: int = 16 * 1024 * 1024
    # 65535: the QUIC max for the DATAGRAM frame extension (RFC 9221).
    # Enables datagrams by default (h3zero only advertises h3_datagram
    # + webtransport_max_sessions when this is non-zero).
    max_datagram_frame_size: int | None = 65535
    # Advertise RESET_STREAM_AT, so a reset can keep the first bytes of
    # its stream (reset_stream's reliable_size). WebTransport always does.
    reset_stream_at: bool = True
    # Per-connection datagram TX record ring (pull-model send path).
    # Bounded capacity IS the backpressure: send_datagram_frame returns
    # 0 when full instead of queueing unboundedly. Steady-state datagram
    # queuing latency ~ ring_bytes / throughput — unlike the stream TX
    # budgets this is meant to stay SMALL, because for datagram traffic
    # dropping at the producer is a legitimate policy, not an error.
    # Allocated lazily on first datagram send; stream-only connections
    # pay nothing.
    datagram_ring_bytes: int = 64 * 1024
    # Producer-enforced per-datagram payload cap. A DATAGRAM frame
    # cannot be fragmented, so a record that can't fit one fresh packet
    # could never drain and would wedge the ring. Conservative default
    # for a 1500-MTU path; raise only if the path MTU supports it.
    datagram_max_payload: int = 1200
    server_name: str | None = None
    certificate_file: str | None = None
    private_key_file: str | None = None
    # Client: None or ssl.CERT_REQUIRED verifies the server's chain and
    # name; ssl.CERT_NONE accepts any certificate.
    verify_mode: int | None = None
    # Client: PEM bundle of trusted roots; None uses certifi's bundle.
    cafile: str | None = None
    # TLS key-exchange groups in preference order, IANA ids. None is
    # classic first; KEX_X25519MLKEM768 first gives a post-quantum share.
    key_exchange_groups: Sequence[int] | None = None
    # NSS Key Log Format file (Wireshark-compatible). When set, picoquic
    # writes TLS secrets per connection so packet captures can be
    # decrypted offline. Honors the SSLKEYLOGFILE env var as a default.
    secrets_log_file: str | None = None
    # Directory for picoquic qlog traces (one JSON file per connection,
    # named by initial CID: CC state, RTT, FC frames). Directory must
    # already exist. The AIOPQUIC_QLOG_DIR env var serves as a
    # shell-level fallback when this is None.
    qlog_dir: str | None = None
    # Congestion-control algorithm for picoquic to use on this transport.
    # Default "bbr" (v3): holds its rate under random loss and jitter,
    # where loss-based algorithms fall behind, and has none of bbr1's
    # 10 s ProbeRTT stalls on low-RTT paths. Other values: "bbr1",
    # "newreno", "cubic", "prague" (L4S/ECN), "dcubic", "fast", "c4",
    # "reno" (= newreno).
    # Matched exactly; an unknown name raises ValueError here and at
    # transport start. None defers to picoquic's compile-time default
    # (newreno).
    congestion_control_algorithm: str | None = "bbr"
    # Option string for that algorithm, passed to picoquic as is. bbr:
    # "Q0.02" sends bursts of 20 ms of pacing rate (default 1 ms).
    congestion_control_options: str | None = None
    # When pacing holds a connection back, wait for up to 10 packets of
    # credit and send them in one train: fewer sends, burstier pacing.
    packet_train_mode: bool = False
    # SPSC TX/RX event ring capacity (entries — must be a power of 2).
    # Each event is an ~64 B notification between the picoquic worker
    # thread and the asyncio drain. None defers to the compile-time
    # defaults (TX 2048, RX 16384 — callback.h). Data-ready
    # notifications are coalesced to at most one outstanding per
    # stream, so RX occupancy scales with live stream count plus
    # lifecycle events, not packet rate. Bump for workloads with very
    # large live-stream counts; lower to shave memory.
    event_ring_capacity: int | None = None
    # Per-stream sc->tx data-ring capacity (bytes). Hard cap on bytes
    # Python may push to a single stream's send queue before
    # send_stream_data raises BufferError. Preserves QUIC stream
    # independence (HOLB-free backpressure). Constraint: must be
    # >= max object size on this connection. App-layer soft caps
    # (aiomoqt tx_max_inflight_bytes) MUST be below this to engage.
    stream_ring_cap: int = 4 * 1024 * 1024
    # Initial MAX_STREAMS advertised to peer at handshake — RFC 9000
    # §4.6 / §19.11: cumulative cap on highest stream ID the peer may
    # open (the peer extends with new MAX_STREAMS frames as streams
    # complete on its side). This is INITIAL credit; healthy
    # operation flows freely as the peer extends. The cap only bites
    # when the peer stops extending (blackhole disconnect): then
    # picoquic rejects further opens once the credit is consumed,
    # bounding stream-count growth during the idle_timeout window.
    # Lower for memory-constrained multi-tenant servers; raise for
    # workloads with very high stream-churn rates.
    max_streams_uni: int = 512
    max_streams_bidi: int = 512
    # Cap on bytes one connection (WebTransport: one session) has
    # committed to its stream TX data rings but the picoquic worker has
    # not yet pulled. Bounds producer run-ahead that per-stream caps
    # structurally miss:
    # short-stream churn resets the per-stream budget every rollover,
    # so an unpaced producer can spread unbounded backlog across
    # thousands of fresh streams while QUIC's own throttles (CC, FC,
    # MAX_STREAMS) all read green — CC paces the wire, not the app;
    # peer FC credits track delivery, which keeps up with the wire.
    # Enforced at stream-creation boundaries (WT create_stream, raw
    # QUIC first write to a new stream) with park/resume hysteresis
    # (park above cap, resume below cap/2). Steady-state added
    # latency ≈ 0.75 × cap / drain rate: 4 MiB ≈ 8 ms at ~3 Gbps.
    # Size ≥ path BDP to avoid starving the wire (4 MiB covers
    # 1 Gbps × 33 ms); raise for high-BDP WAN paths, lower for
    # tighter latency budgets. None or 0 disables.
    tx_max_queued_bytes: int | None = 4 * 1024 * 1024
    # Most connections one transport holds at once; a server refuses new
    # ones past it with CONNECTION_REFUSED.
    max_connections: int = 256
    # Restrict TLS to one cipher suite, IANA id: 0x1301 AES-128-GCM,
    # 0x1302 AES-256-GCM, 0x1303 ChaCha20-Poly1305. None offers all.
    cipher_suite: int | None = None
    # Packets per 1-RTT key phase before a key update. None keeps
    # picoquic's default.
    key_update_interval: int | None = None
    # Client: QUIC versions, most preferred first (QUIC_V1, QUIC_V2). The
    # connection starts in v1 and moves to the first entry by compatible
    # version negotiation (RFC 9368) when the server supports it.
    supported_versions: list[int] | None = None
    # Client: session ticket store, loaded when the transport starts and
    # saved when it stops. A later connection resumes the session and may
    # send 0-RTT data written before its handshake completes.
    session_ticket_file: str | None = None
    # Socket family: socket.AF_INET or socket.AF_INET6 only; None binds both
    # when IPv6 can bind the port, else IPv4.
    ip_family: int | None = None
    # picoquic path MTU discovery policy: "basic" probes opportunistically,
    # "delayed" only once there is a lot to send, "blocked" never.
    pmtud: str = "basic"

    def __post_init__(self) -> None:
        from aiopquic._binding._transport import (
            check_congestion_control_algorithm, check_congestion_control_options,
        )
        check_congestion_control_algorithm(self.congestion_control_algorithm)
        check_congestion_control_options(self.congestion_control_options,
                                         self.congestion_control_algorithm)
        if self.cipher_suite is not None and self.cipher_suite not in CIPHER_SUITES:
            raise ValueError(f"unsupported cipher suite {self.cipher_suite:#06x}")
        if self.pmtud not in ("basic", "delayed", "blocked"):
            raise ValueError(f"unsupported pmtud policy {self.pmtud!r}")
        if self.ip_family not in (None, socket.AF_INET, socket.AF_INET6):
            raise ValueError(f"unsupported ip_family {self.ip_family}")
        for version in self.supported_versions or ():
            if version not in (QUIC_V1, QUIC_V2):
                raise ValueError(f"unsupported QUIC version {version:#010x}")

    @property
    def desired_version(self) -> int:
        """Version to move to by compatible version negotiation; 0 stays in v1."""
        versions = self.supported_versions or ()
        return versions[0] if versions and versions[0] != QUIC_V1 else 0

    def load_cert_chain(self, certfile: str, keyfile: str | None = None,
                        password: str | None = None) -> None:
        """Load certificate and private key files."""
        self.certificate_file = certfile
        if keyfile is not None:
            self.private_key_file = keyfile

    @property
    def verify_peer(self) -> bool:
        """Whether a client verifies the server's certificate."""
        return self.verify_mode != ssl.CERT_NONE

    def load_verify_locations(self, cafile: str | None = None,
                              capath: str | None = None,
                              cadata: bytes | None = None) -> None:
        """Trust the roots in `cafile`, a PEM bundle, for verifying servers.

        picoquic loads a single PEM file, so `capath` and `cadata` are
        not supported.
        """
        if capath is not None or cadata is not None:
            raise NotImplementedError(
                "only cafile is supported: picoquic loads one PEM file")
        self.cafile = cafile
