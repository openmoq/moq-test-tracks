"""WebTransport asyncio API.

Three classes:
  WebTransportSession      — base; established-session API (create_stream,
                              send_stream_data, receive_stream_data,
                              events, close, drain, reset_stream, ...).
                              Holds .role ('client' or 'server') because
                              MoQT and other higher layers care.

  WebTransportClient(...)  — initiator subclass; adds open(). Used by
                              connect_webtransport(host, port, path).

  WebTransportServerSession(...) — acceptor subclass;
                              constructed from an incoming H3 CONNECT.

The cdef class WebTransportSessionState (in _binding._transport) is the
C-side state holder; both subclasses share one. A process-wide
_DispatcherRegistry routes drained SPSC events to the right session by
the wt_session pointer.
"""
from __future__ import annotations

import asyncio
import logging
import os
import socket
from collections import deque
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from aiopquic.quic.configuration import QuicConfiguration
from aiopquic.asyncio._rxwatch import clear_reader, set_reader
from aiopquic.quic.connection import drain_and_route
from aiopquic._binding._transport import (
    TransportContext, WebTransportSessionState,
    tx_data_bytes_queued,
)
from aiopquic.quic.events import (
    WebTransportSessionRefused,
    WebTransportSessionClosed, WebTransportSessionDraining,
    WebTransportStreamDataReceived, WebTransportStreamReset,
    WebTransportStopSending, WebTransportDatagramReceived,
    WebTransportNewStream,
)


# Must match spsc_ring.h SPSC_EVT_STREAM_TX_DRAINED — shared with
# the raw-QUIC path. Fired by the picoquic worker when sc->tx drains
# after a Python writer was blocked, edge-trigger via tx_drain_pending.
logger = logging.getLogger(__name__)

_EVT_STREAM_TX_DRAINED = 15
_EVT_STREAM_DESTROY = 17
_EVT_WT_STREAM_DESTROY = 18
_EVT_DATAGRAM_TX_DRAINED = 19

# Must match spsc_ring.h SPSC_EVT_WT_* values.
_EVT_WT_SESSION_READY = 64
_EVT_WT_SESSION_REFUSED = 65
_EVT_WT_SESSION_CLOSED = 66
# AIOPQUIC_WT_CLOSE_* in h3wt_callback.h.
_WT_CLOSE_SESSION = 0
_WT_CLOSE_TRANSPORT = 2
_CLOSE_LOCAL = 0x80  # AIOPQUIC_CLOSE_LOCAL in spsc_ring.h
_EVT_WT_SESSION_DRAINING = 67
_EVT_WT_STREAM_DATA = 68
_EVT_WT_STREAM_FIN = 69
_EVT_WT_STREAM_RESET = 70
_EVT_WT_STOP_SENDING = 71
_EVT_WT_DATAGRAM = 72
_EVT_WT_NEW_STREAM = 73
_EVT_WT_STREAM_CREATED = 74
_EVT_WT_NEW_SESSION = 75
_EVT_WT_CNX_CLOSED = 77

# Application-error code surfaced on RESET_STREAM for WT data streams when
# the WT session itself terminates. Per draft-ietf-webtrans-http3 §6, §9.5.
WT_SESSION_GONE = 0x170d7b68


class _Inbox(asyncio.Queue):
    """A stream's received events; `destroyed` once its native stream is gone."""
    destroyed = False


class WebTransportError(ConnectionError):
    """The session is unusable: closed, not open, refused or timed out.
    A ConnectionError, so a refused CONNECT is caught like a refused
    raw QUIC handshake."""


def _keylog_file(configuration: QuicConfiguration | None) -> str | None:
    """TLS secrets file: the configuration's, else SSLKEYLOGFILE."""
    if configuration is not None and configuration.secrets_log_file:
        return configuration.secrets_log_file
    return os.environ.get("SSLKEYLOGFILE")


async def _resolve_host(host: str) -> str:
    from aiopquic.asyncio.client import _resolve_host as resolve
    return await resolve(host)


def _varint_len(v: int) -> int:
    """Bytes in the QUIC variable-length encoding of v (RFC 9000 §16)."""
    return 1 if v < 0x40 else 2 if v < 0x4000 else 4 if v < 0x40000000 else 8


# =====================================================================
# Base: established-session API. Role-agnostic except for the .role
# property (preserved because MoQT-level code makes role-specific
# choices: who sends ClientSetup vs ServerSetup, etc.).
# =====================================================================

class WebTransportSession:
    """Established WebTransport session — common base for client and
    server. Subclasses provide the asymmetric setup."""

    def __init__(self, transport: TransportContext, role: str,
                 state: WebTransportSessionState | None = None):
        if role not in ("client", "server"):
            raise ValueError(f"role must be 'client' or 'server', got {role!r}")
        self._transport = transport
        self._role = role
        self._state = state or WebTransportSessionState(transport)
        self._loop: asyncio.AbstractEventLoop | None = None
        self._dispatcher_attached = False
        # Session-level signals
        self._session_ready: asyncio.Future | None = None
        self._session_closed = asyncio.Event()
        self._cnx_closed = asyncio.Event()
        self._fin_sent = False
        self._session_close_event: WebTransportSessionClosed | None = None
        self._draining = False
        # Stream creation: FIFO of pending futures. Each create_stream()
        # call appends a future; the WT_STREAM_CREATED handler popleft's
        # and resolves it. Picoquic processes the TX ring serially and
        # emits responses in the same order, so 1:1 pairing is correct.
        self._pending_creates: deque[asyncio.Future] = deque()
        self._orphan_stream_commands: deque[tuple[int, bool]] = deque()
        self._orphan_cleanup_task: asyncio.Task | None = None
        self._ring_parked_creates = 0
        # Per-stream incoming queues
        self._stream_inbox: dict[int, _Inbox] = {}
        # Live streams whose reader has taken the FIN or reset: their
        # inbox is gone and later events are dropped. Cleared at destroy.
        self._inbox_done: set[int] = set()
        # Datagram TX record ring, created on first send; a mark owed
        # when the TX event ring was full, and the writer's backpressure
        # event (starts set = writable), as on QuicConnection.
        self._dgram_ring: int = 0
        self._dgram_max_payload: int = 1200
        self._dgram_ring_bytes: int = 64 * 1024
        self._dgram_mark_owed: bool = False
        self._dgram_tx_drain_event = asyncio.Event()
        self._dgram_tx_drain_event.set()
        # Per-stream drain events. Set by _on_event when the picoquic
        # worker fires SPSC_EVT_STREAM_TX_DRAINED for a stream; awaited
        # by send_stream_data_drained / external callers via
        # get_tx_data_drain_event. Lazy-allocated per stream_id.
        self._stream_tx_drain_events: dict[int, asyncio.Event] = {}
        # Per-stream sc pointers (uintptr_t) the C side surfaces via
        # NEW_STREAM (peer-initiated) and STREAM_CREATED (we initiated).
        # send_stream_data() looks this up and passes the sc pointer
        # into Cython's push_stream_data. Removed on FIN/RESET/
        # STOP_SENDING/SESSION_CLOSED. The C side owns the underlying
        # aiopquic_stream_ctx_t lifetime via the per-stream link in
        # h3zero's path_callback_ctx; we only hold a borrowed integer.
        self._stream_tx_ctxs: dict[int, int] = {}
        # Datagrams + general event stream
        self._event_queue: asyncio.Queue = asyncio.Queue()

    # --- read-only state ----------------------------------------------

    @property
    def role(self) -> str:
        """'client' for the initiating side, 'server' for the
        accepting side. Higher layers (MoQT) use this to choose
        between client/server-specific protocol behavior."""
        return self._role

    @property
    def is_client(self) -> bool:
        return self._role == "client"

    @property
    def negotiated_protocol(self) -> str | None:
        """The WebTransport subprotocol (WT-Protocol) negotiated for this
        session, or None if none was negotiated. On the client this is the
        server's selection from the offered WT-Available-Protocols; on the
        server it is what this server chose from its allowlist. Valid once
        the session is established (after open() returns / acceptance)."""
        return self._state.negotiated_wt_protocol

    @property
    def is_server(self) -> bool:
        return self._role == "server"

    @property
    def session_ready(self) -> bool:
        return self._session_ready is not None and self._session_ready.done()

    @property
    def session_closed(self) -> bool:
        return self._session_closed.is_set()

    @property
    def is_draining(self) -> bool:
        return self._draining

    @property
    def control_stream_id(self) -> int:
        return self._state.control_stream_id

    @property
    def cnx_ptr(self) -> int:
        # Returns 0 once SESSION_CLOSED has been observed so the
        # dump_all_counters harvest sees a sentinel rather than the
        # dangling C ptr — picoquic may have already freed the cnx by
        # this point. Residual race: picoquic_delete_cnx returns
        # (freed) before this asyncio handler runs (gap = SPSC drain
        # latency, microseconds). Vastly narrower than the prior
        # "freed seconds ago" UAF in dump_all_counters.
        if self._session_closed.is_set():
            return 0
        return self._state.cnx_ptr

    # --- dispatcher attach (called by subclass setup paths) -----------

    def _attach_dispatcher(self) -> None:
        if self._dispatcher_attached:
            return
        if self._loop is None:
            self._loop = asyncio.get_event_loop()
        eventfd = self._transport.eventfd
        if eventfd >= 0:
            _get_dispatcher_registry().attach(
                self._loop, self._transport, self)
        self._dispatcher_attached = True

    # --- stream management --------------------------------------------

    # Aggregate TX gate budget (QuicConfiguration.tx_max_queued_bytes).
    # Class default matches the configuration default; instance attr
    # set by connect_webtransport / serve_webtransport when a
    # configuration is supplied. None/0 disables the gate.
    tx_max_queued_bytes: int | None = 4 * 1024 * 1024
    # Per-stream sc->tx ring cap forwarded to push_stream_data
    # (QuicConfiguration.stream_ring_cap). Class default matches the
    # C compile-time default; instance attr set by the entry points
    # when a configuration is supplied.
    stream_ring_cap: int = 4 * 1024 * 1024

    async def _await_tx_data_capacity(self) -> None:
        """Park while this session's TX-queued bytes exceed the budget.

        The budget is per session, so a stalled or vanished peer parks
        only its own session. The green-light is drain capacity (any of
        this session's streams draining frees budget), not any single
        stream's state. The process-wide total, one load, gates the
        per-stream sum. Hysteresis: park above cap, resume below cap/2;
        a 2 ms poll, since the producer is far ahead of the wire
        whenever this engages. Session close exits the park."""
        cap = self.tx_max_queued_bytes
        if (not cap or tx_data_bytes_queued() <= cap
                or self._tx_backlog() <= cap):
            return
        low = cap // 2
        while not self.session_closed and self._tx_backlog() > low:
            await asyncio.sleep(0.002)

    async def create_stream(self, bidir: bool = True,
                              timeout: float = 5.0, *,
                              initial: bytes = b"", end_stream: bool = False,
                              priority: int | None = None) -> int:
        """Open a new WT stream. Returns the assigned stream_id.

        initial and end_stream are the stream's first bytes and FIN: they
        travel with the create and leave in the same send as the stream
        header. priority, as in set_stream_priority, applies before them.

        Round-trips to the picoquic thread because picowt allocates
        the id internally. Multiple concurrent callers are safe:
        each appends a future to a FIFO and picoquic responds in
        the same order TX events were pushed. A full TX event ring
        waits for it to drain; timeout covers that wait too.

        Parks first while the session's TX-queued budget is exceeded
        (_await_tx_data_capacity) — the stream-creation boundary is
        the one point short-stream churn cannot bypass."""
        if self.session_closed:
            raise WebTransportError("WT session closed")
        if not self.session_ready:
            raise WebTransportError("session not ready")
        if len(initial) > self.stream_ring_cap:
            raise ValueError(
                f"initial write of {len(initial)} bytes exceeds the stream "
                f"ring (cap={self.stream_ring_cap})")
        if priority is not None and not 0 <= priority <= 255:
            raise ValueError(f"priority {priority} outside 0-255")
        await self._await_tx_data_capacity()
        # Do not submit more creates while abandoned streams await retirement.
        while self._orphan_cleanup_task is not None:
            await asyncio.shield(self._orphan_cleanup_task)
        if self.session_closed:
            raise WebTransportError("WT session closed")
        deadline = self._loop.time() + timeout
        ring_event = self._transport.tx_event_ring_drain_event
        while True:
            ring_event.clear()
            try:
                self._state.push_create_stream(
                    bidir, initial, end_stream, self.stream_ring_cap,
                    -1 if priority is None else priority)
                break
            except BufferError:
                if self._transport.arm_tx_event_ring_drain_pending():
                    self._ring_parked_creates += 1
                    try:
                        await asyncio.wait_for(
                            ring_event.wait(), deadline - self._loop.time())
                    finally:
                        self._ring_parked_creates -= 1
                else:
                    await asyncio.sleep(0)
            if self.session_closed:
                raise WebTransportError("WT session closed")
        # No await between the push and the append: replies pair in order.
        fut = self._loop.create_future()
        self._pending_creates.append(fut)
        try:
            sid = await asyncio.wait_for(
                fut, timeout=max(deadline - self._loop.time(), 0))
        except BaseException:
            # Submitted requests retain their FIFO slot until their reply.
            # A reply can also arrive just before cancellation reaches us.
            if fut.done() and not fut.cancelled() and fut.exception() is None:
                if sid := fut.result():
                    self._retire_orphan_stream(sid)
            else:
                fut.cancel()
            raise
        if sid == 0:
            raise WebTransportError("WT stream create rejected")
        return sid

    def _retire_orphan_stream(self, stream_id: int) -> None:
        """Retire an allocated stream whose create caller has gone away."""
        self._drop_stream_tx(stream_id)
        if self.session_closed:
            return  # Session cleanup owns all its streams.
        self._orphan_stream_commands.append((stream_id, False))
        if not stream_id & 2:
            self._orphan_stream_commands.append((stream_id, True))
        if self._orphan_cleanup_task is None:
            self._orphan_cleanup_task = self._loop.create_task(
                self._retire_orphan_streams())

    async def _retire_orphan_streams(self) -> None:
        """One retry task for abandoned streams; new creates wait behind it."""
        ring_event = self._transport.tx_event_ring_drain_event
        try:
            while self._orphan_stream_commands and not self.session_closed:
                sid, stop = self._orphan_stream_commands[0]
                push = (self._state.push_stop_sending if stop
                        else self._state.push_reset_stream)
                ring_event.clear()
                try:
                    push(sid, 0)
                except BufferError:
                    if self._transport.arm_tx_event_ring_drain_pending():
                        await ring_event.wait()
                except ConnectionError:
                    return  # Connection teardown owns the remaining streams.
                else:
                    self._orphan_stream_commands.popleft()
        finally:
            self._orphan_stream_commands.clear()
            self._orphan_cleanup_task = None

    def send_stream_data(self, stream_id: int, data: bytes,
                          end_stream: bool = False) -> None:
        """Send bytes on a WT stream.

        Writes into the stream's per-WT-stream sc->tx byte ring and
        marks the stream active. Picoquic pulls bytes at wire rate via
        prepare_to_send. All-or-nothing on backpressure: BufferError
        means no bytes committed and caller may retry the same buffer.
        Raises ConnectionError once the session is closed and
        ValueError for a write larger than the stream's ring.
        """
        if self.session_closed:
            raise ConnectionError("WT session closed")
        if not self.session_ready:
            raise WebTransportError("session not open")
        sc_ptr = self._stream_tx_ctxs.get(stream_id, 0)
        if sc_ptr == 0:
            raise WebTransportError(
                f"WT stream {stream_id} not available "
                "(never opened, closed, or reset)")
        self._state.push_stream_data(stream_id, sc_ptr, data, end_stream,
                                     stream_ring_cap=self.stream_ring_cap)

    def get_tx_data_drain_event(self, stream_id: int) -> asyncio.Event:
        """asyncio.Event signalled when the picoquic worker drains
        bytes from this stream's sc->tx after the ring was reported
        full. Caller pattern:
            event = wt.get_tx_data_drain_event(sid)
            event.clear()
            try:
                wt.send_stream_data(sid, data, end_stream)
            except BufferError:
                await event.wait()
                continue  # retry
        """
        event = self._stream_tx_drain_events.get(stream_id)
        if event is None:
            event = asyncio.Event()
            self._stream_tx_drain_events[stream_id] = event
        return event

    def tx_data_ring_used(self, stream_id: int) -> int:
        """Per-stream sc->tx bytes-in-flight — the load-bearing
        backpressure signal in the pull model.

        Returns the count of bytes currently queued in this WT
        stream's sc->tx ring waiting for the picoquic worker to pull
        them onto the wire. Companion of set_tx_data_drain_pending +
        get_tx_data_drain_event: read used → if over budget, arm the
        per-stream drain-pending flag and await the per-stream event.
        Unknown stream_id returns 0.

        Conceptually `used` is how full the per-stream byte pipe is
        between Python (producer) and picoquic (consumer):
          - bytes you've pushed via send_stream_data but not yet on
            the wire
          - drained monotonically by the worker; wake via the
            per-stream sc->tx drain event
          - cap_minus_used = headroom before next push raises
            BufferError
          - used / wire_rate ≈ latency this queue adds above wire RTT
        """
        sc_ptr = self._stream_tx_ctxs.get(stream_id, 0)
        if not sc_ptr:
            return 0
        return self._transport.tx_data_ring_used(sc_ptr)

    def tx_sent_bytes(self, stream_id: int) -> int:
        """Cumulative bytes of this WT stream picoquic has taken from its TX
        ring into packets; the stream header h3zero writes is not counted.
        Monotonic: a stream offset has left the ring once this exceeds it.
        0 for a stream with no TX ring yet, or one reset or retired."""
        sc_ptr = self._stream_tx_ctxs.get(stream_id, 0)
        if not sc_ptr:
            return 0
        return self._transport.tx_data_ring_sent(sc_ptr)

    def _tx_backlog(self) -> int:
        """Bytes queued in this session's stream rings, not yet pulled."""
        return sum(self._transport.tx_data_ring_used(sc_ptr)
                   for sc_ptr in list(self._stream_tx_ctxs.values()))

    def set_tx_data_drain_pending(self, stream_id: int) -> None:
        """Arm the per-stream sc->tx_drain_pending flag so the next
        worker drain of this stream's sc->tx fires
        SPSC_EVT_STREAM_TX_DRAINED — even if sc->tx wasn't full.
        Pair with get_tx_data_drain_event(stream_id) for the canonical
        clear-arm-recheck-wait pattern against a byte budget below
        sc->tx full. No-op on unknown stream_id."""
        sc_ptr = self._stream_tx_ctxs.get(stream_id, 0)
        if not sc_ptr:
            return
        self._transport.set_tx_data_drain_pending(sc_ptr)

    def clear_tx_data_drain_pending(self, stream_id: int) -> None:
        """Clear the per-stream sc->tx_drain_pending flag. Use when
        the producer observed the byte budget cleared between arm and
        wait (the race-recovery branch of clear-arm-recheck-wait).
        No-op on unknown stream_id."""
        sc_ptr = self._stream_tx_ctxs.get(stream_id, 0)
        if not sc_ptr:
            return
        self._transport.clear_tx_data_drain_pending(sc_ptr)

    def path_quality(self) -> dict:
        """Snapshot of picoquic path-quality metrics for the underlying
        cnx. Returns a dict with cwnd (cwin), bytes_in_transit,
        smoothed rtt, pacing_rate, lost packet counts, bytes
        sent/received. The load-bearing CC + FC observability surface
        for the WT session's underlying QUIC path. Returns empty dict
        if the session is not yet open or the underlying cnx is gone.
        Mirrors aiopquic.QuicConnection.path_quality()."""
        cnx_ptr = self.cnx_ptr
        if not cnx_ptr:
            return {}
        return self._transport.path_quality(cnx_ptr)

    def peer_address(self) -> tuple[str, int] | None:
        """The peer's (host, port) on the underlying connection, or None
        before it is known or after the session closes. An IPv4-mapped
        IPv6 address is returned as IPv4."""
        cnx_ptr = self.cnx_ptr
        if not cnx_ptr:
            return None
        return self._transport.peer_address(cnx_ptr)

    def local_address(self) -> tuple[str, int] | None:
        """This side's (host, port) on the underlying connection, as
        peer_address()."""
        cnx_ptr = self.cnx_ptr
        if not cnx_ptr:
            return None
        return self._transport.local_address(cnx_ptr)

    def tx_event_ring_fill(self) -> float:
        """TX event-ring fill ratio in [0.0, 1.0], connection-global
        (the SPSC TX ring is shared across all WT streams on this
        session). BufferError from send_stream_data is the hard
        backpressure signal; this is the soft companion for
        yield-threshold decisions in tight send loops.
        """
        cap = self._transport.tx_event_ring_capacity
        if not cap:
            return 0.0
        return self._transport.tx_event_ring_count / cap

    async def send_stream_data_drained(self, stream_id: int, data: bytes,
                                         end_stream: bool = False,
                                         *,
                                         soft_yield_at: float = 0.5,
                                         hard_wait_at: float = 0.9) -> None:
        """Send with built-in TX-ring backpressure for WT.

        Composes send_stream_data + get_tx_data_drain_event + tx_event_ring_fill so
        every WT caller gets worker-thread-aware pacing without copying
        the heuristic. Mirrors aiopquic.QuicConnection.send_stream_data_drained.

        Layers:
          - hard ring-saturation guard: await the connection-global
            tx_event_ring_drain_event when `tx_event_ring_fill > hard_wait_at`
            (default 0.9). Uses the clear-arm-recheck-wait pattern so
            there is no lost wakeup if the worker drains the ring
            between our threshold check and the wait.
          - send: atomic push to sc->tx + MARK_ACTIVE under one GIL hold.
          - soft post-send yield: `await asyncio.sleep(0)` when
            `tx_event_ring_fill > soft_yield_at` (default 0.5).
          - BufferError retry: await whichever drain event the Cython
            side armed (sc->tx-full arms per-stream event; TX-ring-full
            arms connection-global event). asyncio.wait FIRST_COMPLETED
            on both wakes us on whichever fires.

        Application-level policies (byte budgets, fairness) belong
        above this layer. The canonical per-stream byte-budget
        primitive trio is:
          - tx_data_ring_used(stream_id) — data-ring queue depth
            (where the payload actually lives in pull mode)
          - set_tx_data_drain_pending(stream_id) — request a wake
            on next sc->tx drain below sc->tx-full
          - get_tx_data_drain_event(stream_id) — the per-stream wake
        Pair these in a clear-arm-recheck-wait loop above the call
        to this helper.
        """
        sc_event = self.get_tx_data_drain_event(stream_id)
        ring_event = self._transport.tx_event_ring_drain_event
        while True:
            # Close-time guard: SESSION_CLOSED / per-stream-terminal
            # handlers set every drain event explicitly to unpark
            # waiters. Without this check the producer would observe
            # set() events, fall through, call send_stream_data on a
            # closed session, and propagate that failure into the
            # caller. Return cleanly instead.
            if self.session_closed:
                return
            # Connection-global ring pressure: tx_event_ring_fill reads the
            # SPSC TX event ring. Wait on the connection-global ring
            # event, NOT the per-stream sc->tx event (which is only
            # armed when sc->tx fills).
            if self.tx_event_ring_fill() > hard_wait_at:
                ring_event.clear()
                # Re-check after the arm: the worker may have drained since.
                if (not self._transport.arm_tx_event_ring_drain_pending()
                        or self.tx_event_ring_fill() <= hard_wait_at):
                    continue
                await ring_event.wait()
                continue
            # Clear both events BEFORE the send. If the worker fires
            # them during our send_stream_data call (race between the
            # Cython arming and us catching the exception), the set
            # will land AFTER our clear and be captured on the wait.
            # Clearing AFTER the BufferError loses that wakeup.
            sc_event.clear()
            ring_event.clear()
            try:
                self.send_stream_data(stream_id, data,
                                       end_stream=end_stream)
                if self.tx_event_ring_fill() > soft_yield_at:
                    await asyncio.sleep(0)
                return
            except BufferError:
                # Cython side armed the appropriate signal:
                # - sc->tx full → per-stream sc->tx_drain_pending
                # - TX event ring full → connection-global tx_event_ring_drain_pending
                # Events were cleared BEFORE the call so no lost wakeup.
                sc_wait = asyncio.create_task(sc_event.wait())
                ring_wait = asyncio.create_task(ring_event.wait())
                try:
                    await asyncio.wait(
                        [sc_wait, ring_wait],
                        return_when=asyncio.FIRST_COMPLETED)
                finally:
                    for task in (sc_wait, ring_wait):
                        task.cancel()
                    await asyncio.gather(sc_wait, ring_wait, return_exceptions=True)
                # Re-check close after the wait — the session-close
                # handler may have set our events to unpark us cleanly.
                if self.session_closed:
                    return

    def reset_stream(self, stream_id: int, error_code: int = 0,
                     reliable_size: int = 0) -> None:
        """Reset a WT stream we send on. Once reset_stream_at is
        negotiated the reset is a RESET_STREAM_AT that keeps the WT header
        of a stream we opened and the first reliable_size bytes written
        (capped at what was written); sends stop at them and the reset
        waits until they are sent. Else RESET_STREAM. Unsent bytes stop
        counting against the TX budget, and later or parked writes on the
        stream raise WebTransportError. On a stream we only receive on,
        the request is dropped and counted in tx_wrong_direction_dropped.

        error_code is a 32-bit application code, sent in the
        WT_APPLICATION_ERROR range (draft-ietf-webtrans-http3 §4.4); larger
        values are HTTP/3 codes (WT_SESSION_GONE) and go out unchanged.
        Received reset and STOP_SENDING codes are mapped back the same way;
        a code outside the range is delivered as received.

        Raises:
            ValueError: reliable_size outside 0..2**32-1."""
        if not 0 <= reliable_size <= 0xFFFFFFFF:
            raise ValueError("reset_stream: reliable_size out of range")
        self._state.push_reset_stream(stream_id, error_code, reliable_size)
        self._drop_stream_tx(stream_id)

    def reset_stream_at_negotiated(self) -> bool:
        """Both ends advertised RESET_STREAM_AT, so reset_stream keeps its
        reliable_size. False once the session is closed."""
        cnx = self.cnx_ptr
        if cnx == 0:
            return False
        return self._transport.reset_stream_at_negotiated(cnx)

    def stop_stream(self, stream_id: int, error_code: int = 0) -> None:
        """Send STOP_SENDING on a WT stream we receive on (the peer should
        reset it). On our own uni stream, the request is dropped and
        counted in tx_wrong_direction_dropped. error_code is mapped as in
        reset_stream()."""
        self._state.push_stop_sending(stream_id, error_code)

    def set_stream_priority(self, stream_id: int, priority: int) -> int:
        """Relative send priority for one WT stream (RFC 9000 §2.3).

        0 is highest, 255 lowest; picoquic's default is 9. Takes effect on
        an already-open stream, so a subscription re-prioritising
        mid-track applies to whatever has not been scheduled yet.

        The LSB selects the scheduling discipline among streams of EQUAL
        priority, it is not a priority bit: even means round robin (the
        stream sent on least recently), odd means FIFO (lowest stream id).
        Adjacent values therefore behave qualitatively differently. No
        policy is applied here — the caller owns that choice.

        Returns 0 posted, 1 TX event ring full. On 1 the priority is NOT
        applied and the stream keeps its current one; wait on the
        transport's tx_event_ring_drain_event and retry.

        Raises:
            ConnectionError: session closed.
        """
        if self._state is None or self._session_closed.is_set():
            raise ConnectionError("set_stream_priority: session closed")
        return self._state.push_stream_priority(stream_id, priority)

    def set_datagram_priority(self, priority: int) -> int:
        """Send priority of this session's datagrams against its streams.

        Same scale as stream priority (0 highest, picoquic default 9) and
        the same rules as QuicConnection.set_datagram_priority(); it sets
        the priority of the connection the session runs on.

        Returns 0 posted, 1 TX event ring full (nothing applied; retry).

        Raises:
            ConnectionError: session closed.
        """
        if self._state is None or self._session_closed.is_set():
            raise ConnectionError("set_datagram_priority: session closed")
        return self._state.push_datagram_priority(priority)

    def max_datagram_payload(self) -> int:
        """Largest payload send_datagram_frame accepts: the connection's
        ceiling (as QuicConnection.max_datagram_payload()) less the
        Quarter Stream ID varint h3 prefixes to each datagram (RFC 9297).
        0 = datagrams not negotiated or the session is closed."""
        cnx = self.cnx_ptr
        if cnx == 0:
            return 0
        cap = self._transport.datagram_payload_ceiling(cnx)
        if cap == 0:
            return 0
        return max(cap - _varint_len(self.control_stream_id >> 2), 0)

    def send_datagram_frame(self, data: bytes) -> int:
        """Queue one WebTransport datagram for the pull-model send path.

        h3zero frames the payload as an HTTP datagram on this session's
        control stream, so the caller passes the payload alone. Returns
        len(data) on success, 0 when the record ring is full —
        backpressure: wait on get_datagram_tx_drain_event() and retry
        the SAME payload.

        Raises:
            ValueError: payload is empty or exceeds
                max_datagram_payload(), or datagrams were not
                negotiated; such a record could never drain.
            ConnectionError: session closed.
        """
        if self._state is None or self._session_closed.is_set():
            raise ConnectionError("send_datagram_frame: session closed")
        if not data:
            raise ValueError("send_datagram_frame: empty payload")
        if self._dgram_ring == 0:
            # Records cap at the framed ceiling, so every one fits a
            # fresh packet with its stream-ID prefix.
            cap = self.max_datagram_payload()
            if cap == 0:
                raise ValueError(
                    "send_datagram_frame: datagrams not negotiated")
            self._dgram_max_payload = cap
            self._dgram_ring = self._transport.dgram_ring_create(
                self._dgram_ring_bytes, cap)
        if self._dgram_mark_owed:
            if self._state.push_dgram_ready(self._dgram_ring) == 0:
                self._dgram_mark_owed = False
        rc = self._transport.dgram_push(self._dgram_ring, data)
        if rc == 0:
            self._dgram_tx_drain_event.clear()
            return 0
        if rc < 0:
            raise ValueError(
                f"datagram payload {len(data)} exceeds "
                f"max_datagram_payload() = {self._dgram_max_payload}")
        # Records are committed. A full TX event ring leaves the mark
        # owed; it is re-posted at the next send or drain.
        if self._state.push_dgram_ready(self._dgram_ring) != 0:
            self._dgram_mark_owed = True
        return len(data)

    def get_datagram_tx_drain_event(self) -> asyncio.Event:
        """Event set when the worker drains room in the datagram record
        ring after a full send_datagram_frame (return 0), and on close
        so waiters never park forever."""
        return self._dgram_tx_drain_event

    async def receive_stream_data(self, stream_id: int):
        """Async-generator: yield WebTransportStreamDataReceived (and
        any final WebTransportStreamReset) for stream_id, then return
        on FIN or reset. Once it has yielded the FIN or reset, the
        stream's inbox is released and a later call returns at once; a
        reader closed before that leaves the inbox for a later call."""
        if stream_id in self._inbox_done:
            return
        q = self._stream_inbox.get(stream_id)
        if q is None:
            if self._session_closed.is_set():
                # The inboxes went with the session.
                yield WebTransportStreamReset(
                    stream_id=stream_id, error_code=WT_SESSION_GONE)
                return
            self._stream_inbox[stream_id] = q = _Inbox()
        done = False
        try:
            while not done:
                ev = await q.get()
                done = (isinstance(ev, WebTransportStreamReset)
                        or (isinstance(ev, WebTransportStreamDataReceived)
                            and ev.end_stream))
                yield ev
        finally:
            if done and self._stream_inbox.get(stream_id) is q:
                del self._stream_inbox[stream_id]
                if not q.destroyed:
                    self._inbox_done.add(stream_id)

    # --- session close ------------------------------------------------

    def _release_session_resources(self) -> None:
        """Release everything this session holds. Idempotent.

        Runs on either direction of termination. A session is terminated
        when a WT_CLOSE_SESSION capsule is sent *or* received
        (draft-ietf-webtrans-http3 §6), so a close we initiate must
        reclaim exactly what an inbound one does. Skipping it leaves
        inbox chunks pinned, and a chunk holds its stream context as a
        raw pointer — once the transport is torn down, deallocating that
        chunk frees memory that is already gone.
        """
        # A datagram writer parked on a full ring sees the close.
        self._dgram_tx_drain_event.set()
        if self._dgram_ring:
            # The worker's session holds its own reference until the
            # session struct is freed; ours is dropped behind any queued
            # MARK naming the ring.
            self._transport.dgram_ring_release(self._dgram_ring)
            self._dgram_ring = 0
        # One worker-thread walk (TX_WT_SESSION_CLEANUP) sends the §6
        # resets and stop-sendings and releases the session's wt_link
        # sc's; the release does not wait on the wire. O(1) ring cost.
        self._push_or_retry(self._state.push_session_cleanup, "cleanup")
        self._stream_tx_ctxs.clear()
        if self._orphan_cleanup_task is not None or self._ring_parked_creates:
            self._transport.tx_event_ring_drain_event.set()
        self._orphan_stream_commands.clear()
        while self._pending_creates:
            fut = self._pending_creates.popleft()
            if not fut.done():
                fut.set_exception(WebTransportError("WT session closed"))
        # Wake any producer parked in send_stream_data_drained awaiting a
        # per-stream sc_event or the connection-global ring_event. After
        # close the worker stops invoking drain callbacks for this
        # session's streams, so without these explicit sets the waiter
        # would deadlock until process exit. It wakes, loops, observes
        # session_closed and returns cleanly.
        for tx_ev in self._stream_tx_drain_events.values():
            tx_ev.set()
        ring_ev = getattr(self._transport,
                            '_tx_event_ring_drain_event', None)
        if ring_ev is not None:
            ring_ev.set()
        # Inbox queues are only popped on per-stream STREAM_DESTROY, so
        # without this every stream that arrived leaks its asyncio.Queue
        # and any undrained payload keeps a Cython chunk alive.
        for sid, q in self._stream_inbox.items():
            while True:
                try:
                    q.get_nowait()
                except asyncio.QueueEmpty:
                    break
            # §6: the session's streams end with WT_SESSION_GONE; a
            # reader parked on the queue returns on it.
            q.put_nowait(WebTransportStreamReset(
                stream_id=sid, error_code=WT_SESSION_GONE))
        self._stream_inbox.clear()
        self._inbox_done.clear()

    def _push_or_retry(self, push, what: str) -> None:
        """Queue a session command. A full TX ring reschedules it once
        the ring drains, so a close, a cleanup or a FIN is never lost
        to backpressure and never raises out of a close path."""
        try:
            push()
        except BufferError:
            loop = self._loop or asyncio.get_event_loop()
            loop.create_task(self._retry_push(push, what))
        except ConnectionError as exc:
            logger.debug("WT %s not queued: %s", what, exc)

    async def _retry_push(self, push, what: str) -> None:
        ring_ev = self._transport.tx_event_ring_drain_event
        for _ in range(3):
            ring_ev.clear()
            if self._transport.arm_tx_event_ring_drain_pending():
                try:
                    await asyncio.wait_for(ring_ev.wait(), 1.0)
                except asyncio.TimeoutError:
                    pass
            try:
                push()
                return
            except BufferError:
                continue
            except ConnectionError:
                return
        logger.warning("WT %s dropped: TX ring stayed full", what)

    def close(self, error_code: int = 0, reason: bytes = b"") -> None:
        if not self.session_closed:
            # Terminated the moment the capsule is queued, per §6, so the
            # state and the reclaim both happen here — an inbound
            # SESSION_CLOSED may never arrive for a close we initiated.
            self._session_closed.set()
            self._fin_sent = True
            self._push_or_retry(
                lambda: self._state.push_close(error_code, reason), "close")
            self._release_session_resources()
            # events() returns once it reads the close.
            self._event_queue.put_nowait(WebTransportSessionClosed(
                error_code=error_code, reason=memoryview(bytes(reason))))

    def drain(self) -> None:
        self._state.push_drain()
        self._draining = True

    async def wait_closed(self, timeout: float | None = None) -> None:
        if timeout is None:
            await self._session_closed.wait()
        else:
            await asyncio.wait_for(self._session_closed.wait(),
                                     timeout=timeout)

    async def aclose(self, error_code: int = 0, reason: bytes = b"",
                     *, timeout: float = 2.0) -> None:
        """Close the session and wait for the close to leave. A client
        waits for its connection to go, bounded by `timeout`; a server
        returns once the close is queued, the connection is the
        client's. A session that never opened returns at once."""
        if not self.session_closed:
            self.close(error_code, reason)
        if self._role == "server" or not self.session_ready:
            return
        try:
            await asyncio.wait_for(self._cnx_closed.wait(), timeout)
        except asyncio.TimeoutError:
            pass

    async def detach(self) -> None:
        """Release what this session holds in its transport's event
        dispatcher, which keeps the session, the transport and its wake fd
        alive until then. connect_webtransport does this on exit; a caller
        that builds the session itself calls it after aclose() and before
        stopping the transport.

        A dispatcher left with no session and no acceptor is retired: its
        acceptor tasks are cancelled and awaited and its reader removed.
        Other sessions and an acceptor on a shared transport keep theirs.
        Idempotent; a no-op for a session that never opened."""
        if not self._dispatcher_attached:
            return
        self._dispatcher_attached = False
        await _get_dispatcher_registry().detach_session(
            self._loop, self._transport, self)

    # --- event fan-out ------------------------------------------------

    async def events(self) -> AsyncGenerator:
        """Yield non-stream events: SessionDraining, NewStream,
        Datagram, etc., ending with the session's close. Stream data is
        delivered via receive_stream_data(stream_id) on demand."""
        while not self._session_closed.is_set():
            ev = await self._event_queue.get()
            yield ev

    # --- internal: dispatcher hook ------------------------------------

    def _drop_stream_tx(self, sid: int) -> None:
        """Wake any producer parked on this stream's tx drain event,
        then drop sc cache + event. Called from every per-stream
        terminal event (RESET, STOP_SENDING, STREAM_DESTROY,
        WT_STREAM_DESTROY). Without the wake the producer would
        deadlock — the popped Event is unreachable from this dict so
        no future STREAM_TX_DRAINED can set it. Idempotent / safe on
        unknown sid."""
        ev = self._stream_tx_drain_events.get(sid)
        if ev is not None:
            ev.set()
        self._stream_tx_ctxs.pop(sid, None)
        self._stream_tx_drain_events.pop(sid, None)

    def _on_session_closed(self, error_code, data,
                           source=_WT_CLOSE_SESSION) -> None:
        reason = data if data is not None else memoryview(b"")
        local_error, local_reason = 0, ""
        if source & _CLOSE_LOCAL:
            source &= ~_CLOSE_LOCAL
            local_error = error_code
            local_reason = bytes(reason).decode("utf-8", "replace")
            error_code, reason = 0, memoryview(b"")
        ev = WebTransportSessionClosed(
            error_code=error_code, reason=reason,
            connection_closed=source != _WT_CLOSE_SESSION,
            frame_type=0 if source == _WT_CLOSE_TRANSPORT else None,
            local_error=local_error, local_reason=local_reason)
        self._session_close_event = ev
        self._session_closed.set()
        self._release_session_resources()
        if (self._session_ready
                and not self._session_ready.done()):
            self._session_ready.set_exception(WebTransportError(
                "WT session closed before READY"))
        self._event_queue.put_nowait(ev)
        # §6: answer an inbound close with our FIN on CONNECT.
        if not self._fin_sent:
            self._fin_sent = True
            self._push_or_retry(self._state.push_fin, "FIN")
        if self._role == "server":
            # A closed server session leaves the dispatcher's table;
            # the dispatcher stays for the next CONNECT.
            _get_dispatcher_registry().release(
                self._loop, self._transport, self)

    def _on_event(self, ev_tuple) -> None:
        """Called by the dispatcher for every drained event whose
        stream_ctx_ptr matches this session.

        ev_tuple: (event_type, stream_id, data, is_fin, error_code,
                    cnx_ptr, stream_ctx_ptr, sc_ptr)."""
        evt_type, sid, data, _is_fin, error_code, _cnx_ptr, _, sc_ptr = (
            ev_tuple)
        # Hot branches first: data, FIN, and TX-drain wakes dominate
        # the event stream; session-lifecycle events are rare.
        if evt_type == _EVT_WT_STREAM_DATA:
            if self._session_closed.is_set():
                # Inbox queues are gone; a new one would pin the payload.
                return
            payload = data if data is not None else memoryview(b"")
            ev = WebTransportStreamDataReceived(
                stream_id=sid, data=payload, end_stream=False)
            q = self._stream_inbox.get(sid)
            if q is None:
                if sid in self._inbox_done:
                    return
                self._stream_inbox[sid] = q = _Inbox()
            q.put_nowait(ev)
        elif evt_type == _EVT_WT_STREAM_FIN:
            if self._session_closed.is_set():
                return
            payload = data if data is not None else memoryview(b"")
            ev = WebTransportStreamDataReceived(
                stream_id=sid, data=payload, end_stream=True)
            q = self._stream_inbox.get(sid)
            if q is None:
                if sid in self._inbox_done:
                    return
                self._stream_inbox[sid] = q = _Inbox()
            q.put_nowait(ev)
            # Peer FINed the stream — no further reads, but we may
            # still be writing on a bidi until our own FIN goes out.
            # Don't drop tx_ctx here; that's owned by the writer side.
        elif evt_type == _EVT_STREAM_TX_DRAINED:
            # Picoquic worker drained bytes from this stream's sc->tx
            # and the edge-trigger CAS won. Wake any blocked writer.
            event = self._stream_tx_drain_events.get(sid)
            if event is None:
                event = asyncio.Event()
                self._stream_tx_drain_events[sid] = event
            event.set()
        elif evt_type == _EVT_WT_SESSION_READY:
            if self._session_ready and not self._session_ready.done():
                self._session_ready.set_result(None)
        elif evt_type == _EVT_WT_SESSION_REFUSED:
            err = WebTransportSessionRefused(error_code=error_code)
            if self._session_ready and not self._session_ready.done():
                # >= 100 is the server's HTTP status; below, a local failure.
                reason = (f"HTTP {error_code}" if error_code >= 100
                          else f"code={error_code}")
                self._session_ready.set_exception(WebTransportError(
                    f"WT CONNECT refused ({reason})"))
            self._event_queue.put_nowait(err)
        elif evt_type == _EVT_WT_SESSION_CLOSED:
            self._on_session_closed(error_code, data, _is_fin)
        elif evt_type == _EVT_WT_CNX_CLOSED:
            if not self.session_closed:
                self._on_session_closed(error_code, None, _is_fin)
            self._cnx_closed.set()
        elif evt_type == _EVT_WT_SESSION_DRAINING:
            self._draining = True
            self._event_queue.put_nowait(WebTransportSessionDraining())
        elif evt_type == _EVT_WT_STREAM_CREATED:
            # Race tail: SESSION_CLOSED may have been processed before
            # the worker finished allocating this stream. In that case
            # the corresponding pending_create future is already errored
            # and _stream_tx_ctxs was cleared; stashing sc_ptr would
            # orphan it. Push a reset so picoquic retires the stream
            # and the callback chain frees the link.
            if self._session_closed.is_set():
                if sc_ptr and error_code == 0 and sid:
                    try:
                        self._state.push_reset_stream(sid, WT_SESSION_GONE)
                    except BufferError:
                        pass
                return
            # Every native reply consumes exactly one submitted request.
            fut = self._pending_creates.popleft() if self._pending_creates else None
            if error_code != 0 or fut is None or fut.done():
                if sid:
                    self._retire_orphan_stream(sid)
                if fut is not None and not fut.done():
                    fut.set_result(0)
                return
            if sc_ptr:
                self._stream_tx_ctxs[sid] = sc_ptr
            fut.set_result(sid)
        elif evt_type == _EVT_WT_STREAM_RESET:
            if self._session_closed.is_set():
                return
            ev = WebTransportStreamReset(stream_id=sid,
                                            error_code=error_code)
            q = self._stream_inbox.get(sid)
            if q is None and sid not in self._inbox_done:
                self._stream_inbox[sid] = q = _Inbox()
            if q is not None:
                q.put_nowait(ev)
            # Peer reset → our tx side is also gone. Drop sc reference.
            self._drop_stream_tx(sid)
        elif evt_type == _EVT_WT_STOP_SENDING:
            self._event_queue.put_nowait(
                WebTransportStopSending(stream_id=sid,
                                          error_code=error_code))
            # Peer told us to stop sending — sc->tx is no longer useful.
            self._drop_stream_tx(sid)
        elif evt_type == _EVT_WT_DATAGRAM:
            payload = data if data is not None else memoryview(b"")
            self._event_queue.put_nowait(
                WebTransportDatagramReceived(data=payload))
        elif evt_type == _EVT_DATAGRAM_TX_DRAINED:
            # The worker popped a record from a ring a writer found full.
            self._dgram_tx_drain_event.set()
            if (self._dgram_mark_owed and self._dgram_ring
                    and not self._session_closed.is_set()):
                if self._state.push_dgram_ready(self._dgram_ring) == 0:
                    self._dgram_mark_owed = False
        elif evt_type == _EVT_WT_NEW_STREAM:
            # Mirror of the _EVT_WT_STREAM_CREATED race: SESSION_CLOSED
            # may have been processed before this peer-initiated NEW
            # event arrived. Without a guard, sc_ptr would be re-stashed
            # into the cleared _stream_tx_ctxs and a NewStream event
            # delivered to an application that no longer has a session.
            if self._session_closed.is_set():
                # The cleanup walk is idempotent: it ends the late stream
                # in its own direction and releases its link.
                if sc_ptr and sid:
                    self._push_or_retry(self._state.push_session_cleanup,
                                        "cleanup")
                return
            # Peer opened a new stream — for bidi we may want to reply,
            # so stash the sc pointer here too.
            if sc_ptr:
                self._stream_tx_ctxs[sid] = sc_ptr
            self._event_queue.put_nowait(
                WebTransportNewStream(stream_id=sid))
        elif evt_type == _EVT_STREAM_DESTROY:
            # Universal raw-QUIC STREAM_DESTROY — fired for raw-QUIC
            # streams that share this transport. WT data streams use
            # the _EVT_WT_STREAM_DESTROY path below.
            self._drop_stream_tx(sid)
            self._stream_inbox.pop(sid, None)
            self._inbox_done.discard(sid)
        elif evt_type == _EVT_WT_STREAM_DESTROY:
            # picohttp_callback_free fired for this WT data stream.
            # The link + sc are still alive at this point (LINK_RELEASE
            # follows in FIFO order and owns the actual free); we just
            # drop our cached sc pointer so _stream_tx_ctxs doesn't
            # accumulate stale entries. Do NOT pop _stream_inbox: a
            # consumer task may not have called receive_stream_data
            # yet — popping the queue races with consumers that hold
            # a deferred reference and would hang them. A reader that
            # has returned released the inbox already.
            self._drop_stream_tx(sid)
            self._inbox_done.discard(sid)
            q = self._stream_inbox.get(sid)
            if q is not None:
                q.destroyed = True


# =====================================================================
# Initiator-side: subclass adds open().
# =====================================================================

# connect_protocol -> AIOPQUIC_WT_CONNECT_* (h3wt_callback.h).
_CONNECT_PROTOCOLS = {None: 0, "webtransport": 1, "webtransport-h3": 2}


def _sf_string_list(items: list[str]) -> str:
    """WT-Available-Protocols value: a Structured Field List of Strings
    (RFC 9651). picoquic sends it verbatim; "" sends no header."""
    return ", ".join(f'"{p}"' for p in items)


class WebTransportClient(WebTransportSession):
    """Initiator-side WT session. Adds open() to drive the
    CONNECT handshake."""

    def __init__(self, transport: TransportContext,
                 host: str, port: int, path: str,
                 sni: str | None = None,
                 wt_available_protocols: list[str] | None = None,
                 connect_protocol: str | None = None):
        if connect_protocol not in _CONNECT_PROTOCOLS:
            raise ValueError(
                f"connect_protocol must be None, 'webtransport' or "
                f"'webtransport-h3', not {connect_protocol!r}")
        super().__init__(transport, role="client")
        self._host = host
        self._port = port
        self._path = path
        self._sni = sni or host
        # WT-Available-Protocols header sent in the H3 CONNECT request
        # (WebTransport spec §3.3). Generic list of subprotocol strings;
        # aiopquic does no interpretation. Higher layers (e.g. aiomoqt)
        # set this to advertise their version namespace (moqt-NN etc.).
        self._wt_protocols = wt_available_protocols or []
        # CONNECT :protocol; see connect_webtransport().
        self._connect_protocol = _CONNECT_PROTOCOLS[connect_protocol]

    async def open(self, timeout: float = 10.0) -> None:
        """Initiate the WT session — push TX_WT_OPEN, await
        SESSION_READY. Picoquic-thread does picowt_prepare_client_cnx
        + picowt_connect."""
        self._loop = asyncio.get_event_loop()
        self._attach_dispatcher()
        self._session_ready = self._loop.create_future()

        addr = await _resolve_host(self._host)
        self._state.push_open(addr, self._port, self._path, self._sni,
                              _sf_string_list(self._wt_protocols),
                              self._connect_protocol)

        try:
            await asyncio.wait_for(self._session_ready, timeout=timeout)
        except asyncio.TimeoutError:
            raise WebTransportError(
                f"WT CONNECT timed out after {timeout}s"
            ) from None


# =====================================================================
# Acceptor-side subclass: the C bridge surfaces WT_NEW_SESSION
# events that construct these.
# =====================================================================

class WebTransportServerSession(WebTransportSession):
    """Acceptor-side WT session. Constructed by the server's accept
    callback when a new H3 CONNECT arrives at a registered path.

    The C-side bridge has already allocated the underlying
    aiopquic_wt_session_t and registered the WT prefix; this Python
    object just wraps it and routes events from the rx_event_ring."""

    def __init__(self, transport: TransportContext,
                 state: WebTransportSessionState):
        super().__init__(transport, role="server", state=state)
        # Server side: session is already open at construction time
        # (the peer sent CONNECT and we accepted it).
        self._loop = asyncio.get_event_loop()
        self._attach_dispatcher()
        self._session_ready = self._loop.create_future()
        self._session_ready.set_result(None)


# =====================================================================
# Shared dispatcher: one add_reader per (loop, transport); routes
# every drained event to the matching session by stream_ctx_ptr.
# =====================================================================

class _Dispatcher:
    def __init__(self, loop: asyncio.AbstractEventLoop,
                 transport: TransportContext):
        self._loop = loop
        self._transport = transport
        self._sessions: dict[int, WebTransportSession] = {}
        # Session ptrs this dispatcher's acceptor created, so the server
        # can retire exactly its own on close and leave a client sharing
        # the same (loop, transport) alone.
        self._spawned: set[int] = set()
        # Acceptor coroutines we started. An accept handler typically runs
        # until its session closes, so without ownership it is still
        # pending at teardown, holding the session and transport while
        # stop() frees the engine under it.
        self._tasks: set[asyncio.Task] = set()
        self._acceptor = None  # callable(session) -> None|coroutine
        set_reader(loop, transport, self._drain, self)

    def add_session(self, session: WebTransportSession) -> None:
        self._sessions[session._state.session_ptr] = session

    def remove_session(self, session: WebTransportSession) -> None:
        self._sessions.pop(session._state.session_ptr, None)

    def set_acceptor(self, acceptor) -> None:
        """Install the server-side handler invoked once per
        EVT_WT_NEW_SESSION. Receives the new WebTransportServerSession."""
        self._acceptor = acceptor

    def _drain(self) -> None:
        drain_and_route(self._transport, self.route_event)

    def route_event(self, ev) -> None:
        """Route one already-drained event (also the entry point for an
        external router that owns the eventfd reader, e.g. single-port
        dual-stack dispatch)."""
        evt_type = ev[0]
        stream_ctx_ptr = ev[6]
        if evt_type == _EVT_WT_NEW_SESSION and self._acceptor is not None:
            self._spawn_server_session(ev)
            return
        session = self._sessions.get(stream_ctx_ptr)
        if session is not None:
            session._on_event(ev)

    def set_session_factory(self, factory) -> None:
        """factory(transport, state) -> WebTransportSession; defaults
        to WebTransportServerSession when unset. Allows callers to
        substitute application-specific session subclasses (e.g.,
        aiomoqt's MOQTSessionWTServer)."""
        self._session_factory = factory

    def _spawn_server_session(self, ev) -> None:
        stream_ctx_ptr = ev[6]
        if stream_ctx_ptr in self._sessions:
            return  # already attached (re-entrancy guard)
        state = WebTransportSessionState(self._transport, session_ptr=stream_ctx_ptr)
        factory = getattr(self, '_session_factory', None)
        if factory is None:
            session = WebTransportServerSession(self._transport, state)
        else:
            session = factory(self._transport, state)
        self._sessions[stream_ctx_ptr] = session
        self._spawned.add(stream_ctx_ptr)
        result = self._acceptor(session)
        if asyncio.iscoroutine(result):
            task = self._loop.create_task(result)
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)

    def cancel_tasks(self) -> list:
        """Cancel the acceptor coroutines this dispatcher started, except
        the caller's own, and return them, so a caller on the loop can
        await the cancellation before the transport is freed."""
        current = asyncio.current_task(self._loop)
        pending = [t for t in self._tasks
                   if not t.done() and t is not current]
        for t in pending:
            t.cancel()
        return pending

    def detach(self) -> None:
        self.cancel_tasks()
        clear_reader(self._loop, self._transport, self)


class _DispatcherRegistry:
    """Process-wide registry keyed by (loop_id, transport_id).
    Lazy-created; one add_reader per pair."""
    def __init__(self):
        self._dispatchers: dict[tuple[int, int], _Dispatcher] = {}

    def _lookup(self, loop: asyncio.AbstractEventLoop,
                transport: TransportContext) -> "_Dispatcher | None":
        """The dispatcher of exactly this (loop, transport); an entry
        filed under the same ids for other objects is not it."""
        d = self._dispatchers.get((id(loop), id(transport)))
        if d is not None and d._loop is loop and d._transport is transport:
            return d
        return None

    def _get_or_create(self, loop: asyncio.AbstractEventLoop,
                       transport: TransportContext) -> "_Dispatcher":
        key = (id(loop), id(transport))
        d = self._dispatchers.get(key)
        if d is not None and (d._loop is not loop
                              or d._transport is not transport):
            # Retired before the new reader is added: the stale wake fd
            # may share its number with this transport's.
            d.detach()
            del self._dispatchers[key]
            d = None
        if d is None:
            d = _Dispatcher(loop, transport)
            self._dispatchers[key] = d
        return d

    def attach(self, loop: asyncio.AbstractEventLoop,
                transport: TransportContext,
                session: WebTransportSession) -> None:
        self._get_or_create(loop, transport).add_session(session)

    def attach_acceptor(self, loop: asyncio.AbstractEventLoop,
                         transport: TransportContext,
                         acceptor) -> "_Dispatcher":
        """Bind a server-side accept handler to (loop, transport).
        Returns the underlying dispatcher so callers can detach."""
        d = self._get_or_create(loop, transport)
        d.set_acceptor(acceptor)
        return d

    def detach_acceptor(self, loop: asyncio.AbstractEventLoop,
                         transport: TransportContext) -> None:
        """Drop a server's acceptor and retire the dispatcher if it holds
        no sessions.

        The entry must go, not just the acceptor: keys are
        (id(loop), id(transport)) and id() is unique only among live
        objects, so a retained entry keeps a dead pair addressable.
        """
        key = (id(loop), id(transport))
        d = self._lookup(loop, transport)
        if d is None:
            return
        d.set_acceptor(None)
        for ptr in d._spawned:
            d._sessions.pop(ptr, None)
        d._spawned.clear()
        if not d._sessions:
            d.detach()
            del self._dispatchers[key]

    def release(self, loop: asyncio.AbstractEventLoop,
                transport: TransportContext,
                session: WebTransportSession) -> None:
        """Drop one session from its dispatcher; the dispatcher stays."""
        d = self._lookup(loop, transport)
        if d is not None:
            d.remove_session(session)

    async def detach_session(self, loop: asyncio.AbstractEventLoop,
                             transport: TransportContext,
                             session: WebTransportSession) -> None:
        """Drop one session. A dispatcher left with no session and no
        acceptor is retired: its tasks cancelled and awaited, then its
        reader removed."""
        key = (id(loop), id(transport))
        d = self._lookup(loop, transport)
        if d is None:
            return
        d.remove_session(session)
        if d._sessions or d._acceptor is not None:
            return
        pending = d.cancel_tasks()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        # A session or an acceptor may have attached during the await.
        if (self._dispatchers.get(key) is d and not d._sessions
                and d._acceptor is None):
            d.detach()
            del self._dispatchers[key]


_REGISTRY: _DispatcherRegistry | None = None


def _get_dispatcher_registry() -> _DispatcherRegistry:
    global _REGISTRY
    if _REGISTRY is None:
        _REGISTRY = _DispatcherRegistry()
    return _REGISTRY


# =====================================================================
# Public client-side entry point.
# =====================================================================

@asynccontextmanager
async def connect_webtransport(
        host: str, port: int, path: str,
        *, sni: str | None = None,
        wt_available_protocols: list[str] | None = None,
        connect_protocol: str | None = None,
        transport: TransportContext | None = None,
        timeout: float = 10.0,
        configuration: QuicConfiguration | None = None,
        verify_peer: bool | None = None,
        ca_file: str | None = None,
) -> AsyncGenerator[WebTransportClient, None]:
    """Open a WebTransport session.

    Usage:
        async with connect_webtransport(host, port, '/moq-relay') as wt:
            sid = await wt.create_stream(bidir=True)
            wt.send_stream_data(sid, b'...')
            ...

    `connect_protocol` is the CONNECT's :protocol: "webtransport" or
    "webtransport-h3". None sends "webtransport", then once
    "webtransport-h3" on the same connection if a server that advertised
    SETTINGS_WT_ENABLED refuses the first.

    `transport` defaults to a fresh TransportContext started in client
    mode (alpn='h3', max_datagram_frame_size=64KB); pass an existing
    one to share rings/threading across multiple sessions.

    The server's certificate is verified unless `verify_peer` is False
    (else `configuration.verify_mode` decides); `ca_file` (else
    `configuration.cafile`, else certifi's bundle) holds the trusted
    roots. Both apply only to a transport created here.

    Empty path "" is normalized to "/" — HTTP/3 root request semantics
    (RFC 9114 §4.3.1). Picoquic's path-match is exact, so registering
    "" on the server side and connecting with "" both fail to route
    against a peer that uses the literal "/". Normalizing here keeps
    consumers from having to think about it.
    """
    if path == "":
        path = "/"
    own_transport = transport is None
    if own_transport:
        if (configuration is not None
                and configuration.event_ring_capacity is not None):
            transport = TransportContext(
                ring_capacity=configuration.event_ring_capacity)
        else:
            transport = TransportContext()
        if verify_peer is None:
            verify_peer = (configuration.verify_peer
                           if configuration is not None else True)
        if ca_file is None and configuration is not None:
            ca_file = configuration.cafile
        start_kwargs = dict(
            is_client=True, alpn="h3",
            verify_peer=verify_peer, ca_file=ca_file,
            max_datagram_frame_size=(
                configuration.max_datagram_frame_size or 64 * 1024
                if configuration is not None else 64 * 1024))
        if configuration is not None:
            # Thread FC sizing, stream caps, idle timeout, and the CC
            # algorithm through to picoquic. Without this the peer
            # advertises picoquic defaults and the connection runs the
            # compile-time CC regardless of configuration.
            start_kwargs.update(
                rx_data_ring_cap=configuration.max_stream_data,
                initial_max_data=configuration.max_data,
                initial_max_streams_uni=configuration.max_streams_uni,
                initial_max_streams_bidi=configuration.max_streams_bidi,
                idle_timeout_ms=int(configuration.idle_timeout * 1000),
                congestion_control_algorithm=(
                    configuration.congestion_control_algorithm),
                congestion_control_options=(
                    configuration.congestion_control_options),
                packet_train_mode=configuration.packet_train_mode,
                keep_alive_interval_ms=int(
                    (configuration.keep_alive_interval or 0) * 1000),
                socket_buffer_size=(
                    configuration.socket_buffer_size or 0),
                qlog_dir=configuration.qlog_dir,
                key_exchange_groups=getattr(
                    configuration, 'key_exchange_groups', None),
                ip_family=(-1 if configuration.ip_family is None
                           else configuration.ip_family),
                pmtud_policy=configuration.pmtud,
            )
        start_kwargs["keylog_filename"] = _keylog_file(configuration)
        transport.start(**start_kwargs)

    client = WebTransportClient(transport, host, port, path, sni=sni,
                                  wt_available_protocols=wt_available_protocols,
                                  connect_protocol=connect_protocol)
    if configuration is not None:
        client.tx_max_queued_bytes = configuration.tx_max_queued_bytes
        client.stream_ring_cap = configuration.stream_ring_cap
    try:
        await client.open(timeout=timeout)
        yield client
    finally:
        try:
            await client.aclose(0, b"")
        except Exception:
            pass
        await client.detach()
        if own_transport:
            try:
                transport.stop()
            except Exception:
                pass


# =====================================================================
# Public server-side entry point.
# =====================================================================

class WebTransportServer:
    """Server handle returned by serve_webtransport. close() tears
    down the engine and detaches the dispatcher."""

    def __init__(self, transport: TransportContext, dispatcher,
                 own_transport: bool):
        self._transport = transport
        self._dispatcher = dispatcher
        self._own_transport = own_transport

    async def aclose(self) -> None:
        """Close every live session, then the server."""
        for session in list(self._dispatcher._sessions.values()):
            if not session.session_closed:
                session.close(0, b"")
        await asyncio.sleep(0)
        self.close()

    def close(self) -> None:
        try:
            _get_dispatcher_registry().detach_acceptor(
                self._dispatcher._loop, self._transport)
        except Exception:
            pass
        if self._own_transport:
            try:
                self._transport.stop()
            except Exception:
                pass


async def serve_webtransport(
        host: str, port: int, path: str,
        *, handler,
        cert_file: str, key_file: str,
        transport: TransportContext | None = None,
        session_factory=None,
        configuration: QuicConfiguration | None = None,
        wt_supported_protocols: list[str] | None = None,
        web_folder: str | None = None,
) -> WebTransportServer:
    """Start a WebTransport server listening on (host, port) at path.

    handler(session) is invoked once per accepted CONNECT.
    session_factory(transport, state) constructs each session;
    defaults to WebTransportServerSession.

    Empty path "" is normalized to "/" — picoquic's path table is
    exact-match (no default route), and HTTP/3 clients send `:path: /`
    for root requests (RFC 9114 §4.3.1). Without normalization, a
    server registered with "" never matches a root-path CONNECT.

    web_folder serves files from that directory to HTTP/3 GET requests
    for paths other than `path`.
    """
    if path == "":
        path = "/"
    own_transport = transport is None
    if own_transport:
        if (configuration is not None
                and configuration.event_ring_capacity is not None):
            transport = TransportContext(
                ring_capacity=configuration.event_ring_capacity)
        else:
            transport = TransportContext()
        start_kwargs = dict(
            port=port,
            host=host,
            cert_file=cert_file, key_file=key_file,
            alpn="h3",
            is_client=False,
            max_datagram_frame_size=(
                configuration.max_datagram_frame_size or 64 * 1024
                if configuration is not None else 64 * 1024),
            wt_path=path,
        )
        if configuration is not None:
            # Thread FC sizing, stream caps, idle timeout, and the CC
            # algorithm through to picoquic. Without this the server
            # advertises picoquic defaults and the connection runs the
            # compile-time CC regardless of configuration.
            start_kwargs.update(
                rx_data_ring_cap=configuration.max_stream_data,
                initial_max_data=configuration.max_data,
                initial_max_streams_uni=configuration.max_streams_uni,
                initial_max_streams_bidi=configuration.max_streams_bidi,
                idle_timeout_ms=int(configuration.idle_timeout * 1000),
                congestion_control_algorithm=(
                    configuration.congestion_control_algorithm),
                congestion_control_options=(
                    configuration.congestion_control_options),
                packet_train_mode=configuration.packet_train_mode,
                keep_alive_interval_ms=int(
                    (configuration.keep_alive_interval or 0) * 1000),
                socket_buffer_size=(
                    configuration.socket_buffer_size or 0),
                qlog_dir=configuration.qlog_dir,
                key_exchange_groups=getattr(
                    configuration, 'key_exchange_groups', None),
                max_connections=getattr(configuration, 'max_connections',
                                        256),
                ip_family=(-1 if configuration.ip_family is None
                           else configuration.ip_family),
                pmtud_policy=configuration.pmtud,
            )
        if web_folder is not None:
            start_kwargs["web_folder"] = web_folder
        if wt_supported_protocols:
            # WT-Protocol allowlist: the server picks the client's first
            # offer that is on it and refuses (400) an offer with no match.
            start_kwargs["wt_supported_protocols"] = ", ".join(
                wt_supported_protocols)
        start_kwargs["keylog_filename"] = _keylog_file(configuration)
        transport.start(**start_kwargs)

    loop = asyncio.get_event_loop()
    dispatcher = _get_dispatcher_registry().attach_acceptor(
        loop, transport, handler)
    if configuration is not None:
        # Stamp the aggregate TX budget on every accepted session —
        # the dispatcher's factory is the only per-session hook on
        # the server side.
        cap = configuration.tx_max_queued_bytes
        inner_factory = session_factory

        ring_cap = configuration.stream_ring_cap

        def _budget_factory(transport_, state):
            if inner_factory is not None:
                session = inner_factory(transport_, state)
            else:
                session = WebTransportServerSession(transport_, state)
            session.tx_max_queued_bytes = cap
            session.stream_ring_cap = ring_cap
            return session

        dispatcher.set_session_factory(_budget_factory)
    elif session_factory is not None:
        dispatcher.set_session_factory(session_factory)
    return WebTransportServer(transport, dispatcher, own_transport)
