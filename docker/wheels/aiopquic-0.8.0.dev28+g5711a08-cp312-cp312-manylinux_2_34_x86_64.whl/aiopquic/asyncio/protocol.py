"""QUIC asyncio protocol — matches qh3.asyncio.protocol API.

Uses eventfd for zero-overhead notification from picoquic's network
thread to the asyncio event loop.
"""

import asyncio
import logging

from aiopquic.asyncio._rxwatch import clear_reader, set_reader
from aiopquic.quic.connection import QuicConnection
logger = logging.getLogger(__name__)

from aiopquic.quic.events import (
    QuicEvent, HandshakeCompleted, ConnectionTerminated,
)


class QuicConnectionProtocol:
    """asyncio protocol for QUIC connections.

    Bridges QuicConnection (picoquic network thread) with the asyncio
    event loop using eventfd for RX notification.

    Subclass and override quic_event_received() to handle events.
    """

    def __init__(self, quic: QuicConnection,
                 stream_handler=None):
        self._quic = quic
        self._stream_handler = stream_handler
        self._loop: asyncio.AbstractEventLoop | None = None
        self._closed = asyncio.Event()
        self._connected_waiter: asyncio.Future | None = None
        # Set when the connection terminates BEFORE the handshake
        # completes (e.g. no mutual ALPN → WRONG_ALPN). Surfaced to
        # wait_connected() so connect() fails promptly instead of
        # hanging until the idle timeout.
        self._handshake_error: Exception | None = None

    @property
    def _transport(self):
        """Access the underlying TransportContext (for compat)."""
        return self._quic._transport

    def _start(self, loop: asyncio.AbstractEventLoop | None = None) -> None:
        """Register eventfd with the event loop."""
        self._loop = loop or asyncio.get_event_loop()
        if self._quic.eventfd >= 0:
            set_reader(self._loop, self._quic._transport, self._on_eventfd, self)

    def _stop(self) -> None:
        """Unregister eventfd from the event loop."""
        if self._loop is not None and self._quic._transport is not None:
            clear_reader(self._loop, self._quic._transport, self)

    def _on_eventfd(self) -> None:
        """Called by asyncio when eventfd is readable (RX events ready)."""
        self._process_events()

    def _process_events(self) -> None:
        """Drain events from QuicConnection and dispatch."""
        event = self._quic.next_event()
        while event is not None:
            if isinstance(event, HandshakeCompleted):
                if self._connected_waiter and not self._connected_waiter.done():
                    self._connected_waiter.set_result(None)

            if isinstance(event, ConnectionTerminated):
                self._closed.set()
                # A termination before the handshake completes (e.g. no
                # mutual ALPN) must fail wait_connected() now, not after
                # the idle timeout. A post-handshake close is a normal
                # teardown and must not raise here.
                if not self._quic._connected:
                    cause = (f"{event.local_reason} (0x{event.local_error:x})"
                             if event.local_error
                             else f"error_code={event.error_code}")
                    exc = ConnectionError(
                        f"connection terminated during handshake ({cause})")
                    self._handshake_error = exc
                    if (self._connected_waiter is not None
                            and not self._connected_waiter.done()):
                        self._connected_waiter.set_exception(exc)

            try:
                self.quic_event_received(event)
            except Exception:
                logger.exception("event %s dropped by its handler",
                                 type(event).__name__)
            event = self._quic.next_event()

    def quic_event_received(self, event: QuicEvent) -> None:
        """Called for each QUIC event. Override in subclass."""
        pass

    def connect(self, addr: tuple[str, int]) -> None:
        """Initiate TLS handshake (client only)."""
        # Clear any handshake error cached from a prior attempt so a fresh
        # connect() isn't shadowed by a stale failure.
        self._handshake_error = None
        self._quic.connect(addr)

    def close(self) -> None:
        """Close the QUIC connection."""
        self._quic.close()

    async def aclose(self, error_code: int = 0, *,
                     timeout: float = 2.0) -> None:
        """Close the connection and wait, bounded by `timeout`, for the
        close to complete, so it reaches the wire before the transport
        stops. Returns at once when no handshake ever completed."""
        if self._closed.is_set():
            return
        self._quic.close(error_code)
        if not self._quic._connected:
            return
        try:
            await asyncio.wait_for(self._closed.wait(), timeout)
        except asyncio.TimeoutError:
            pass

    async def wait_connected(self) -> None:
        """Wait for TLS handshake to complete.

        Raises ConnectionError if the connection terminated during the
        handshake (e.g. no mutual ALPN), rather than hanging until the
        idle timeout.
        """
        if self._quic._connected:
            return
        if self._handshake_error is not None:
            raise self._handshake_error
        if self._connected_waiter is None:
            self._connected_waiter = self._loop.create_future()
        await self._connected_waiter

    async def wait_created(self, timeout: float = 5.0) -> None:
        """Wait until the network thread has created the client
        connection, so stream writes reach it before the handshake."""
        try:
            await asyncio.wait_for(self._quic._created.wait(), timeout)
        except asyncio.TimeoutError:
            raise ConnectionError("client connection was not created") from None

    async def wait_closed(self) -> None:
        """Wait for connection to be fully closed."""
        await self._closed.wait()
        self._stop()
        self._quic.stop()

    async def __aenter__(self) -> "QuicConnectionProtocol":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        self.close()
        try:
            await asyncio.wait_for(self.wait_closed(), timeout=2.0)
        except asyncio.TimeoutError:
            self._stop()
            self._quic.stop()
